var table = {
    "table_5523": {
        "table_title": "可变剪接事件统计表",
        "table_note": "注：(1) AS Type：可变剪切事件类型；(2) Known AS：已发现可变剪切事件数目；(3) Novel AS：新发现可变剪切事件数目；(4) Total ：可变剪切事件总数目。"
    },
    "table_5533": {
        "table_title": "组间差异可变剪切比较分析结果表",
        "table_note": "注：(1) New ID：将不同组别的AS ID，进行统一编号，以便进行比较；(2) Gene ID：基因编号；(3) Gene name：基因名；(4) Gene description：基因的描述信息；(5) *_VS_*(AS_ID)：比较组中的AS事件编号；(6) *_VS_*(diff_significant)：该AS事件在比较组间差异是否显著；(7) *_VS_*(ΔPSI)：两比较组PSI的差值；(8) *_VS_*(Pvalue)：该AS事件在比较组中差异显著性检验结果；(9)  *_VS_*(FDR)：多重检验矫正后的Pvalue值。"
    },
    "table_5543": {
        "table_title": "SNP类型统计表",
        "table_note": "注：第一列Type表示SNP 类型，包括Transition（转换，由一种嘧啶变成另一种嘧啶，或一种嘌呤变成另一种嘌呤）和Transversion（颠换，嘌呤与嘧啶之间的交换），其他列表示该SNP类型在不同样本中的存在数量。"
    },
    "table_5545": {
        "table_title": "SNP发生频率统计表",
        "table_note": "注：第一列Freq表示单个基因具有的SNP位点数目，其他列表示不同样本中具有该SNP频率的基因数目。"
    },
    "table_5547": {
        "table_title": "SNP/Indel测序深度统计表",
        "table_note": "注：第一列Depth表示支持该SNP位点的测序深度（即reads数），其他列表示不同样本中该测序深度下SNP的数目。"
    },
    "table_5601": {
        "table_title": "表达相关性分析表",
        "table_note": "注：(1) gene/transcript id：基因/转录本编号；(2) gene name:基因名；(3) connected gene/transcript id：表达相关的基因/转录本编号；(4) connected gene name：表达相关的基因名；(5) cor：相关性系数；(6) p value：2个基因/转录本相关性检验结果；(7) q value：多重检验矫正后的p value值。"
    },
    "table_5603": {
        "table_title": "组内差异可变剪切事件统计表",
        "table_note": "注：(1) AS type：可变剪切事件类型；(2) JunctionCountOnly(JC)：差异AS事件仅使用inclusion counts进行检测定量；(3) ReadsOnTargetAndJunctionCounts(JCEC)：差异AS事件同时使用Junction Counts和reads on target进行检测定量；(4) A &amp; B：(2)和(3)两种方法的交集；(5) A | B：(2)和(3)两种方法的并集。"
    },
    "table_5605": {
        "table_title": "组内差异可变剪切模式变化统计表",
        "table_note": "注：(1)AS type：可变剪切事件类型；(2) Exclusion (Increase exclusion in case, ΔPSI＜0)： 表示该可变剪切事件发生exon exclusion的情况大于exon inclusion；(3) Inclusion (Increase inclusion in case, ΔPSI＞0)：表示该可变剪切事件发生exon inclusion的情况大于exon exclusion；(4) Total event：可变剪切事件总数。"
    },
    "table_5621": {
        "table_title": "基因组注释表",
        "table_note": "注：（1）Chromosome：染色体名称；（2）Length（Mb）：染色体长度，以Mb为单位；（3）GC%：GC碱基含量百分比；（4）Protein coding gene：编码蛋白基因数目；（5）Pseudogene：假基因数目；（6）Other gene：其他gene数目；（7）Gene：所有基因数目。"
    },
    "table_5623": {
        "table_title": "样本信息表",
        "table_note": "注：展示该项目的样本基本信息，包括样品描述、样本名称以及组名。"
    },
    "table_5625": {
        "table_title": "软件信息表",
        "table_note": "注：展示转录组生信分析中用到的软件名称/数据库、版本及其对应使用的分析项，并给出各软件的来源（点击链接可跳转到相关网页）。"
    },
    "table_5629": {
        "table_title": "新转录本类型统计表",
        "table_note": "注：根据拼接转录本与已知转录本overlap关系进行分类即Class code，Number 为属于该分类的转录本数目。                \r\n=：认为是与参考注释一致的已知转录本；\r\nc：拼装出来的转录本包含于已知转录本中；\r\nj：潜在的新转录本或转录片段，至少有一个junction位点与参考转录本一致；\r\ne：潜在的mRNA前体的片段；\r\ni：完全落入参考转录本内含子区的转录本片段；\r\no：与参考转录本的外显子有一定的交集；\r\np：可能是聚合酶延长产生的转录片段；\r\nr：拼接得到的转录本中50%的碱基处于DNA重复区域；\r\nu：未知的，基因间区的转录本；\r\nx：与参考转录本外显子所处链的反义链有交集；\r\ns：转录片段的内含子与参考转录本内含子所处链的反义链有交集（可能产生于read mapping 错误）；\r\n·：属于复合类型（tracking file only, multiple classifications）；其中‘x’,‘i’,‘j’,‘u’,‘o’几种类型表示潜在的新转录本（‘u’转录本所对应的基因定义为新基因）。"
    },
    "table_5631": {
        "table_title": "转录本长度分布统计表",
        "table_note": "注：不同转录本长度分布。Length：转录本长度范围；Number：该转录本长度范围内的转录本数目。"
    },
    "table_5633": {
        "table_title": "转录组功能分类统计表",
        "table_note": "注：（1）Expre_Gene number（percent）：本项目表达的基因（即至少在一个样本中的表达量不为0）在各数据库的注释情况；（2）Expre_Transcript number（percent）：本项目表达的转录本（即至少在一个样本中的表达量不为0）在各数据库的注释情况；（3）All_Gene number（percent）：该物种所有编码基因（包含本次预测获得的新编码基因）在各数据库的注释情况；（4）All_Transcript number（percent）：该物种所有编码转录本（包含本次预测获得的新编码转录本）在各数据库的注释情况；（5）GO: 注释到GO库的基因/转录本数量；\r\n（6）KEGG: 注释到KEGG库的序列数量；\r\n（7）COG: 注释到COG库的基因/转录本数量；\r\n（8）NR:注释到NR库的基因/转录本数量；\r\n（9）Swiss-Prot:注释到Swiss-Prot库基因/转录本数量；\r\n（10）Pfam:注释到Pfam库基因/转录本数量；（11）Total_anno：注释到数据库的基因/转录本总数目；（12）Total：总基因/转录本数目。"
    },
    "table_5647": {
        "table_title": "GO分类统计表",
        "table_note": "注：(1)Seq Number: 注释上的基因/转录本数目；\r\n(2)GO ID (Lev4): 注释到的第四层级GO ID；\r\n(3)GO Term (Lev4): 注释到的第四层级GO ID对应的GO描述；\r\n(4)GO ID (Lev3): 注释到的第三层级GO ID；\r\n(5)GO Term (Lev3): 注释到的第三层级GO ID对应的GO描述；\r\n(6)GO ID (Lev2): 注释到的第二层级GO ID；\r\n(7)GO Term (Lev2): 注释到的第二层级GO ID对应的GO描述；\r\n(8)Term type: GO三大分类（即BP、CC、MF）。"
    },
    "table_5651": {
        "table_title": "测序数据统计表",
        "table_note": "注：（1）Sample：样品名称；\r\n（2）Raw reads：原始测序数据的总条目数（reads，代表测序读段，一个reads即为一条）；\r\n（3）Raw bases：原始测序总数据量（即Raw reads数目乘以reads读长）；（4）Clean reads：质控后测序数据的总条目数；\r\n（5）Clean bases：质控后测序总数据量（即Clean reads数目乘以reads长度）；（6）Error rate（%）：质控数据对应的测序碱基平均错误率，一般在0.1%以下；（7）Q20（%）、Q30（%）：对质控后测序数据进行质量评估，Q20、Q30分别指测序质量在99%和99.9%以上的碱基占总碱基的百分比，一般Q20在85%以上，Q30在80%以上；\r\n（8）GC content（%）：质控数据对应的G和C碱基总和占总碱基的百分比。"
    },
    "table_5653": {
        "table_title": "原始数据统计表",
        "table_note": "注：（1）Sample：样品名称；\r\n（2）Raw reads：原始测序数据的总条目数（reads，代表测序读段，一个reads即为一条）；\r\n（3）Raw bases：原始测序总数据量（即Raw reads数目乘以reads读长）；\r\n（4）Error rate（%）：原始数据对应的测序碱基平均错误率，一般在0.1%以下；\r\n（5）Q20（%）、Q30（%）：对原始测序数据进行质量评估，Q20、Q30分别指测序质量在99%和99.9%以上的碱基占总碱基的百分比，一般Q20在85%以上，Q30在80%以上；\r\n（6）GC content（%）：原始数据对应的G和C碱基总和占总碱基的百分比。"
    },
    "table_5655": {
        "table_title": "质控数据统计表",
        "table_note": "注：（1）Sample：样品名称；\r\n（2）Clean reads：质控后测序数据的总条目数；\r\n（3）Clean bases：质控后测序总数据量（即Clean reads数目乘以reads长度）；\r\n（4）Error rate（%）：质控数据对应的测序碱基平均错误率，一般在0.1%以下；\r\n（5）Q20（%）、Q30（%）：对质控后测序数据进行质量评估，Q20、Q30分别指测序质量在99%和99.9%以上的碱基占总碱基的百分比，一般Q20在85%以上，Q30在80%以上；\r\n（6）GC content（%）：质控数据对应的G和C碱基总和占总碱基的百分比。"
    },
    "table_5657": {
        "table_title": "比对结果统计表",
        "table_note": "注：（1）Sample：样本名称；\r\n（2）Total reads：测序序列经过过滤后的序列数量统计（即Clean reads）；\r\n（3）Total mapped：能定位到基因组上的Clean reads数目；\r\n（4）Multiple mapped：在参考序列上有多个比对位置的Clean reads数目；\r\n（5）Unique mapped：在参考序列上有唯一比对位置的Clean reads数目。"
    },
    "table_5659": {
        "table_title": "测序饱和度曲线表",
        "table_note": "ff"
    },
    "table_5661": {
        "table_title": "测序覆盖度分布表",
        "table_note": "dd"
    },
    "table_5663": {
        "table_title": "Reads在参考基因组不同区域的分布统计表",
        "table_note": "注：Reads在参考基因组不同区域分布情况。其中CDS：编码区；Intergenic：基因间区；Introns：内含子区；3'UTR、5'UTR：3'或5'端非编码区。"
    },
    "table_5665": {
        "table_title": "Reads在不同染色体分布统计表",
        "table_note": "注：列代表不同的样本，行代表reads 在不同染色体上的分布数目。"
    },
    "table_5669": {
        "table_title": "NR注释信息表",
        "table_note": "注：(1)Gene/Transcript id: 基因/转录本编号；\r\n(2)Hit-Name: 比对到数据库中的序列编号；\r\n(3)Description: 比对到数据库中的序列的功能描述；\r\n(4)HSP-Length: 高分匹配对（HSP）的序列长度；\r\n(5)E-Value: 偶然搜索概率，值越小，越可信；\r\n(6)Score: 比对得分，值越高，两个序列相似性越高；\r\n(7)Identity (%): 两个序列的一致性；\r\n(8)Similarity (%): 两个序列的相似性。"
    },
    "table_5677": {
        "table_title": "表达量分析结果表",
        "table_note": "注：（1）Gene/Transcript id：转录本/基因编号（点击可跳转到mRNA详情页，查看其详细信息）；\r\n（2）Gene name：基因名称；\r\n（3）Gene description：基因描述信息；\r\n（4）其他各列为基因/转录本在各样本/分组中的表达量以及在各大数据库中的注释信息（点击表格右上方的按钮可对展示信息进行勾选排序）。【点击第一列的图形可展示目标基因/转录本在各样本/分组中的表达情况。】"
    },
    "table_5681": {
        "table_title": "表达量分布表",
        "table_note": "表达量分布表"
    },
    "table_5683": {
        "table_title": "表达量venn 表",
        "table_note": "表达量venn 表"
    },
    "table_5685": {
        "table_title": "样本间相关性系数表",
        "table_note": "注：第一行和第一列为样本名，表中数值为两个样本的相关系数，数值越大，表示两个样本的相关性越大，越相近。"
    },
    "table_5687": {
        "table_title": "PCA表",
        "table_note": "注：第一列为各主成分，第二列为主成分所占比例，数值越大代表该主成分越能区分样本。"
    },
    "table_5705": {
        "table_title": "基因集venn表",
        "table_note": "基因集venn表"
    },
    "table_5719": {
        "table_title": "Heatmap分析表",
        "table_note": "注：(1) Gene/Transcripts_id：基因/转录本编号；\r\n (2) Gene_name：基因名称；\r\n (3) Gene description：基因描述信息；\r\n(4) 表中数字为基因在每个样本中标准化处理后的表达量值。"
    },
    "table_5721": {
        "table_title": "子聚类Heatmap分析表",
        "table_note": "注：(1) Gene/Transcripts_id：基因/转录本编号；\r\n (2) Gene_name：基因名称；\r\n (3) Gene description：基因描述信息；\r\n(4) 表中数字为基因在每个样本中标准化处理后的表达量值。"
    },
    "table_5727": {
        "table_title": "GO分类统计表",
        "table_note": "注：(1) GO ID：注释到的GO编号；\r\n(2) Description：GO二级分类术语；\r\n(3) Term Type：GO一级分类名称；\r\n(4) number：注释到该GO二级分类功能的基因或转录本数目；\r\n(5) percent：注释到该GO二级分类功能的基因或转录本数目占总数的百分比。每个基因/转录本具有多种GO功能，因此，所有百分比加在一起的数字会大于1。"
    },
    "table_5745": {
        "table_title": "KEGG分类统计表",
        "table_note": "注：（1）First catergory：KEGG代谢通路的7个分支：代谢（Metabolism），遗传信息处理（Genetic Information Processing），环境信息处理（Environmental Information Processing），细胞过程（Cellular Processes），生物体系统（Organismal Systems），人类疾病（Human Diseases），药物开发（Drug Development）；（2）Second catergory：KEGG代谢通路的名称；（3）Pathway id：代谢通路编号；（4）Description：KEGG通路具体描述；（5）Number：基因集中注释到该通路下的基因/转录本数量。"
    },
    "table_5747": {
        "table_title": "基因集Kegg Pathway统计表",
        "table_note": "注：(1) First Catergory：KEGG代谢通路的7大类：代谢(Metabolism)，遗传信息处理(Genetic Information Processing)，环境信息处理(Environmental Information Processing)，细胞过程(Cellular Processes)，生物体系统(Organismal Systems)，人类疾病(Human Diseases)，药物开发(Drug Development)； (2) Second Catergory：KEGG代谢通路的名称； (3) Number：注释到该通路的基因/转录本数目。 （注：根据具体物种情况，获得的分类数目不同）"
    },
    "table_5751": {
        "table_title": "GO富集分析统计表",
        "table_note": "注：（1） Number：富集到该GO term的基因/转录本数目；\r\n（2） GO ID：GO Term对应的编号；\r\n（3） Term Type：GO三大分类（即BP、CC、MF）；\r\n（4）Description：GO功能描述；\r\n（5）Ratio_in_study：该GO在目标基因集中占有的比例，分子为基因集中富集到该GO的基因/转录本数目，分母为该基因集中具有GO注释的基因/转录本总数目； \r\n（6）Ratio_in_pop：该GO在背景基因/转录本（测序得到的所有基因/转录本）中占有的比例，分子为所有背景基因/转录本中富集到该GO的数目，分母为所有背景基因/转录本中具有GO注释的总数目；\r\n（7） Pvalue：未经校正的p值，p值代表富集出来的结果是否具有统计学上的显著意义，p值越小，在统计学上就越有显著意义； \r\n（8）Padjust：矫正后的Pvalue值。"
    },
    "table_5755": {
        "table_title": "KEGG富集分析统计表",
        "table_note": "注：(1) Num：富集到该通路的基因/转录本数目；\r\n(2) pathway id：通路编号；\r\n(3) Description：通路名称；\r\n(4) Database：数据库(Pathway或Disease)，KEGG数据库中包含两个子库，一个是KEGG PATHWAY，另一个是KEGG DISEASE；\r\n(5) Ratio_in_study：该KEGG在目标基因集中占有的比例，分子为基因集中富集到该KEGG的基因/转录本数目，分母为该基因集中具有KEGG注释的基因/转录本总数目； \r\n(6) Ratio_in_pop：该KEGG在背景基因/转录本（测序得到的所有基因/转录本）中占有的比例，分子为所有背景基因/转录本中富集到该KEGG的数目，分母为所有背景基因/转录本中具有KEGG注释的总数目；\r\n(7) Pvalue_uncorrected：未经校正的p值，p值代表富集出来的结果是否具有统计学上的显著意义，p值越小，在统计学上就越有显著意义，一般p值小于0.05认为该功能为显著富集项；\r\n(8) Pvaule_bonferroni：采用BH方法校正后的p值。"
    },
    "table_5759": {
        "table_title": "富集弦图数据表",
        "table_note": "注：GO富集弦图 (1) Gene/Transcript id：基因/转录本编号；(2) gene name：基因名称；(3) GO term：GO term描述信息；(4) GO ID：GO term的编号；(5) log2FC：该基因/转录本在两样本间差异倍数以2为底的对数值。KEGG pathway富集弦图 (1) Gene/Transcript id：基因/转录本编号；(2) gene name：基因名称；(3)KEGG Pathway：通路描述信息；(4) Pathway ID：通路编号；(5) log2FC：该基因/转录本在两样本间差异倍数以2为底的对数值。"
    },
    "table_5761": {
        "table_title": "GO富集有向无环表",
        "table_note": "ddd"
    },
    "table_5763": {
        "table_title": "不同区域分布统计表",
        "table_note": "注：统计不同区域中SNP/InDel数目分布情况。 \r\n(1) exonic：外显子区域；(2) intronic：内含子区域；(3) intergenic：基因间区域；(4) upstream：转录起始位点上游1000bp以内的区域；(5) downstream：转录终止位点下游1000bp以内的区域；(6) upstream;downstream：上个基因转录起始位点下游1000bp以内的区域同时位于下个基因上游1000bp以内的区域；(7) UTR5：5’端非翻译区域；(8) UTR3：3’端非翻译区域；(9) UTR5;UTR3：在上个基因3’端非翻译区域以及下个基因5’端非翻译区域；(10) splicing：在剪切位点左右2bp的区域；(11) exonic;splicing：位于外显子以及剪切位点区；(12) ncRNA：非编码RNA区域。"
    },
    "table_5765": {
        "table_title": "可变剪接事件详情表",
        "table_note": "注：(1) AS ID：AS事件编号；(2) Gene ID：AS事件所在基因的编号；(3) Gene name：基因名称； (4) Gene description：基因的描述信息；(5) AS type：AS 类型；(6) Novel AS：是否为新发现可变剪切；(7) chr：AS事件所在染色体编号；(8) strand：基因正负链信息；(9) Diff significant：是否发生差异可变剪切；(10) IncLevelDiff (PSI1/PSI2, ΔPSI)  (注：PSI1 为处理组，PSI2为对照组, ΔPSI=PSI1-PSI2）：可变剪切事件在两组中发生的差值；(11) p value JunctionCountOnly：该AS事件在比较组中差异显著性检验结果；(12) FDR JunctionCountOnly：多重检验矫正后的Pvalue值。(注：PS1 为处理组，PS2为对照组）\r\n其他具体参考此链接：http://interact.majorbio.com/discuss/detail/168"
    },
    "table_5795": {
        "table_title": "数据预处理结果统计表",
        "table_note": "注：表达量偏低或者变异系数较小（即基因在各样本中的表达量较一致，变化较小）的基因通常代表噪音，会影响WGCNA分析的准确性，分析前建议对数据进行预处理，表格展示的是预处理前后基因数目变化，利用过滤后的数据进行分析。"
    },
    "table_5837": {
        "table_title": "模块与表型相关性系数表",
        "table_note": "注：第一列为模块（以模块颜色表示），第一行为表型，表中数据，括号外表示模块（模块向量基因）与表型的相关性系数，括号内表示模块与表型的相关性的显著性P值。"
    },
    "table_5839": {
        "table_title": "基因与表型相关性系数表",
        "table_note": "注：(1) gene/transcript id：基因/转录本的编号；(2) name：基因名称；(3) module：基因/转录本所属模块（以模块颜色表示）；其他列为不同的表型，表中数字代表模块内基因与表型的相关性，其中正数代表正相关，负数代表负相关。"
    },
    "table_5841": {
        "table_title": "MS分析结果表",
        "table_note": "注：第一列为模块（以模块颜色表示），第二列为模块显著性值。该值越大表明越重要，即与某表型特征的相关性越大。"
    },
    "table_5843": {
        "table_title": "MM-GS统计表",
        "table_note": "注：(1) gene/transcript id：基因/转录本编号；(2) name: 基因名称；(3) MM：模块内基因的表达模式与模块特征基因之间的相关性，该值越大，表示该基因归属该模块的可能越大；其他列为每个表型对应的GS，该值越大，表示基因与表型特征的相关性越强。"
    },
    "table_5847": {
        "table_title": "可视化网路节点信息表",
        "table_note": "注：(1) gene/transcript id：基因/转录本编号；(2) name：基因名称；(3) degree：节点连通性，越大说明该节点越重要；(4) module：基因/转录本所属模块（以模块颜色表示）。"
    },
    "table_5849": {
        "table_title": "转录因子预测详情表",
        "table_note": "【当数据库选择AnimalTFDB或者PlantTFDB时】注：（1）Gene/Transcript id：基因/转录本编号；（2）Gene name：基因名称；（3）Gene description：基因描述信息；（4）Family：基因/转录本所属的转录因子家族；（5）DNA domain：基因注释到的DNA结合域；（6）Domain description：DNA结构域的描述信息；（7）Evalue：利用Hmmscan 分析基因所属转录因子家族的Evalue，该值越小越好；（8）Score：利用Hmmscan 分析基因所属转录因子家族的得分，该值越大越好；（9）TF id：基因注释到的转录因子ID；（10）Hit pident：利用blast对基因进行转录因子注释，pident（percent of identity）指一致性，即两个序列间完全相同的部分所占的百分比；（11）Hit evalue：利用blast对基因进行转录因子注释的evalue，该值越小越好。\r\n\r\n【当数据库选择JASPAR时】注：（1）Gene/Transcript id：基因/转录本编号；（2）Gene name：基因名称；（3）Gene description：基因描述信息；（4）TF name：基因注释到的转录因子名称；（5）Motif id：基因注释到的转录因子ID；（6）Family：基因/转录本所属的转录因子家族；（7）DBD（%）：DNA结合结构域结合概率，该值越大越好；（8）Evalue：利用Hmmscan分析基因所属转录因子家族的Evalue，该值越小越好。"
    },
    "table_5853": {
        "table_title": "转录因子家族统计表",
        "table_note": "注：(1) TF_family：转录因子家族名称；(2) Gene Number：属于该家族的基因数目；(3) Transcript Number：属于该家族的转录本数目。"
    },
    "table_5859": {
        "table_title": "转录因子靶基因预测详情表",
        "table_note": "注：(1) TF_ID：转录因子 ID；(2) tf_gene_id：编码转录因子对应基因 id；(3) tf_gene_name：编码转录因子对应的基因名称；(4) Motif id：数据库中转录因子对应的结合位点 id；(5) Target_gene_id：预测的转录因子潜在靶基因 id；(6) Target_gene_name：预测的转录因子潜在靶基因名称；(7) p-value：显著性P值；(8) q-value：校正后的P值；(9) start：转录因子在靶基因上结合的起始位置；(10) stop：转录因子在靶基因上结合的终止位置；(11) matched_sequence：转录因子结合靶基因的位点序列信息；(12) Cor：correlation，相关性，通过计算编码转录因子对应基因与靶基因表达的相关性，对靶基因预测结果进行校正，一般认为相关性越大靶向关系越可靠；(13) cor_pvalue：利用表达量对靶基因预测结果进行校正时，对应的显著性P值；(14) cor_padjust：校正后的P值（注：最后三列仅在选择基因表达量对预测结果进行校正时出现。）"
    },
    "table_5861": {
        "table_title": "转录因子靶基因预测统计表",
        "table_note": "注：(1) tf_gene_id：编码转录因子对应基因 id；(2) TF_ID：转录因子 ID；(3) Target_Number：该转录因子对应的靶基因数目。"
    },
    "table_5871": {
        "table_title": "COG分类统计表",
        "table_note": "注：(1)Category: COG功能分类；\r\n(2)Type: COG功能类型；\r\n(3)Functional description: COG功能描述；\r\n(4)Number:注释上各COG功能类型的序列数目。"
    },
    "table_5873": {
        "table_title": "COG分类统计表",
        "table_note": "注：(1) Category: COG功能分类；\r\n(2) Type：COG功能类型；\r\n(3) Functional description：COG功能描述；\r\n(4) *_vs_*_G/T_COG：所选基因集中的基因/转录本注释上各COG功能类型的数量。"
    },
    "table_6273": {
        "table_title": "模块成员详情表",
        "table_note": "注：展示归属到模块的具体基因。(1) gene/transcript_id：基因/转录本对应 id；(2) gene name：基因名称；(3) module：基因/转录本所属模块（以模块颜色表示）；(4) kME：模块基因的表达模式与模块特征基因之间的相关性。该值越大，表示该基因归属该模块的可能越大。"
    },
    "table_6275": {
        "table_title": "模块成员统计表",
        "table_note": "注：各模块包含的成员（基因/转录本）数目统计表，第一列为模块（以模块颜色表示），第二列属于该模块的成员数目。"
    },
    "table_6277": {
        "table_title": "模块相关表",
        "table_note": "注：第一行和第一列都为具体模块（以模块颜色表示），表中数字代表两比较模块间的相关系数。"
    },
    "table_6365": {
        "table_title": "Swiss-Prot 注释信息表",
        "table_note": "注：(1)Gene/Transcript id: 基因/转录本编号；\r\n(2)Hit-Name: 比对到数据库中的序列编号；\r\n(3)Description: 比对到数据库中的序列的功能描述；\r\n(4)HSP-Length: 高分匹配对（HSP）的序列长度；\r\n(5)E-Value: 偶然搜索概率，值越小，越可信；\r\n(6)Score: 比对得分，值越高，两个序列相似性越高；\r\n(7)Identity (%): 两个序列的一致性；\r\n(8)Similarity (%): 两个序列的相似性。"
    },
    "table_6367": {
        "table_title": "Pfam注释结果表",
        "table_note": "注：(1)Gene/Transcript id: 基因/转录本编号；\r\n(2)Pfam id:序列在Pfam数据库中对应的id；\r\n(3)Domain:序列比对到Pfam数据库中的功能域，即Domain；\r\n(4)Domain Description: 序列比对到Pfam数据库中的功能域具体描述；\r\n(5)E-Value: 偶然搜索概率,值越小,越可信；\r\n(6)Length: 高分匹配的序列长度；\r\n(7)Protein start: 蛋白起始位点；\r\n(8)Protein end: 蛋白终止位点；\r\n(9)Pfam start: Pfam功能域的起始位点； \r\n(10)Pfam end: Pfam功能域的终止位点。"
    },
    "table_6371": {
        "table_title": "Pathway分类统计表",
        "table_note": "注：(1)First Catergory: KEGG代谢通路的7个分支：代谢(Metabolism)，遗传信息处理(Genetic Information Processing)，环境信息处理(Environmental Information Processing)，细胞过程(Cellular Processes)，生物体系统(Organismal Systems)，人类疾病(Human Diseases)，药物开发(Drug Development)；\r\n(2)Second Catergory: KEGG代谢通路的名称；\r\n(3)Number: 注释到该通路下的基因/转录本数量。"
    },
    "table_6439": {
        "table_title": "代谢通路数据表",
        "table_note": "注：(1) seq_id：序列编号；(2) KO：KO编号；(3) Colour：颜色代码；(4) Wide：线条粗细。(注：表格左上角的“复制到剪切板”功能指，可将数据复制到iPath官网进行作图，官网链接为:&lt;a target=&quot;_black&quot; href=&quot;https://pathways.embl.de&quot;&gt;https://pathways.embl.de &lt;/a&gt; .)"
    },
    "table_7009": {
        "table_title": "网络属性表",
        "table_note": "注：(1) Num_of_nodes：蛋白互作网络中，节点的数目，节点代表蛋白；(2) Num_of_edges：蛋白互作网络中，边的数目，边代表蛋白与蛋白之间存在相互作用；(3) Average_node_degree：网络中所有节点的平均度；(4) Average_path_length：网络中所有节点之间的平均最短路径；(5) Average_cluster_coefficient：网络中所有节点的平均聚类系数值；(6) Transitivity：可以用于衡量网络中关联性如何，值越大代表节点间交互关系越大，说明网络越复杂，越能放在一起用于聚类。"
    },
    "table_7011": {
        "table_title": "网络节点属性表",
        "table_note": "注：(1) Node：节点比对到STRING数据库中的名称；(2) node_accession_id：该节点对应的基因编号；(3) neighborhood_on_chromosome：染色体邻近性得分；(4) gene fusion：基因融合相关性得分；(5) phylogenetic_cooccurrence：系统发生相关性得分；(6) homolog：同源性相关性得分；(7) coexpression：共表达相关性得分；(8) experimentally_determined_interaction：实验验证相关性得分；(9) database_annotated：数据库注释相关性得分；(10) automated_textmining：文本挖掘相关性得分；(11) combined_score：综合相关性得分重要性越高。\r\n(注：表格左上角的“复制到剪切板”功能指，可将数据复制到stringdatabase官网进行作图，官网链接为：&lt;a href=&quot;https://string-db.org/cgi/input.pl?sessionId=SLJ4TpGaDoRC&amp;input_page_active_form=multiple_identifiers&quot;&gt;https://string-db.org/cgi/input.pl?sessionId=SLJ4TpGaDoRC&amp;input_page_active_form=multiple_identifiers&lt;/a&gt;）"
    },
    "table_7013": {
        "table_title": "网络中心系数表",
        "table_note": "注：(1) Accession ID：基因/转录本编号；\r\n(2) Node ID: 节点编号；\r\n(3) Node Name: 节点（蛋白）名称；\r\n(4) Degree Centrality：度中心性，是在网络分析中刻画节点中心性最直接的度量指标，一个节点的度越大就意味着该节点的度中心性越高，该节点在网络中就越重要；\r\n(5) Closeness Centrality：紧密系数，节点与网络中其它节点的距离，若都很短，则该点是整体的中心，该值越大说明节点越靠近网络的中心位置；\r\n(6) Betweeness Centrality：介数中心性，体现某一个节点在与其他节点连接中所起的作用，该值越大，意味着该节点在保持整个网络紧密连接性中作用越重要。"
    },
    "table_7015": {
        "table_title": "网络节点度统计表",
        "table_note": "注：Node_Degree: 节点的度（即，节点连通性，直接与该节点相连的节点数目）；Node_Num: 对应度上节点的个数。"
    },
    "table_7207": {
        "table_title": "表达量差异详情表",
        "table_note": "注：(1) Gene/Transcripts_id：基因/转录本编号；\r\n(2) Gene name：基因名称；\r\n(3) Gene description：基因描述信息；\r\n(4) FC(s1/s2)：该基因/转录本在两样本间差异倍数；\r\n(5) log2FC(s1/s2)：该基因/转录本在两样本间差异倍数以2为底的对数值，s2为对照；\r\n(6) p value：该基因/转录本在两样本中差异显著性检验结果；\r\n(7) q adjust：多重检验校正后的p值；\r\n(8) Significant：该基因/转录本在两样本间的差异是否显著，yes为显著；\r\n(9) Regulate：上下调情况，s2为对照，up为上调，down为下调；\r\n(10) 其他列表示该基因/转录本在各样本及各组中的表达量(TPM或 FPKM , 具体请看该分析记录所选择的表达量统计表）。"
    },
    "table_7209": {
        "table_title": "表达量差异统计表",
        "table_note": "注：(1) Gene/Transcripts_id：基因/转录本编号；\r\n(2) Gene name：基因名称；\r\n(3) Gene description：基因描述信息；\r\n(4) 其余几列为该基因/转录本在比较组别中是否显著差异,yes为显著；\r\n(5) Sum：该基因/转录本在不同比较组别中显著差异表达的次数。"
    },
    "table_7385": {
        "table_title": "差异可变剪接事件模式分析结果表",
        "table_note": "gg"
    },
    "table_7667": {
        "table_title": "表达量差异火山表",
        "table_note": "xx"
    },
    "table_7669": {
        "table_title": "表达量差异散点表",
        "table_note": "根深蒂固"
    },
    "table_8213": {
        "table_title": "趋势分析统计表",
        "table_note": "注：1）profile ID：趋势ID；2）members：对应趋势中的基因数量；3）趋势所对应的cluster ID( 注, 将所有profile不显著的都会归为 &quot;-1&quot; )。"
    },
    "table_8216": {
        "table_title": "时序差异分析详情表",
        "table_note": "注：（1）Gene/Transcript_id：基因/转录本编号；（2）Gene_name：基因名称；（3）Gene_description：基因描述信息；（4）p-value：显著性水平；（5）p-adjust：校正之后的P值；（6）r.squared：拟合度；（7）cluster：聚类ID。"
    },
    "table_8217": {
        "table_title": "profile详情表",
        "table_note": "注：1)Gene/Transcript_id：基因/转录本编号；2)Gene_name：基因名称；3)Gene_description：基因描述信息；4)其他列为基因/转录本在各个点归一化后表达量值。"
    },
    "table_8218": {
        "table_title": "GSEA分析统计表",
        "table_note": "注：1）size：代表该基因集下的基因总数。2）ES值：enrichment score，反应基因集成员在排序列表的两端富集的程度；3）NES值：标准化富集得分；4）p-value：针对获得的富集得分进行统计学检验；5）p adjust：多重假设检验矫正p-value；6）Rank at MAX：该基因集ES值出现在排序列表中的位置；7）Leading-edge：对富集得分贡献最大的基因成员。(说明：NES 绝对值越大，P adjust 越小，富集越显著，当每组样本数目＜7时，建议选择 p adjust ＜0.05的 gene sets 进行后续分析；当每组样本数＞7时，p adjust 可放宽到＜0.25。）"
    },
    "table_8220": {
        "table_title": "功能注释信息表",
        "table_note": "注：1)Gene/Transcript_id：基因/转录本编号；2)Gene_name：基因名称；3)Gene_description：基因描述信息；4)其他列为基因/转录本在各大数据库的注释情况。。"
    },
    "table_8221": {
        "table_title": "功能注释信息表",
        "table_note": "注：（1）Gene/Transcript id：基因/转录本编号；（2）Gene name：基因名称；（3）Gene description：基因描述信息；（4）其他列为基因/转录本在各大数据库的注释情况。"
    },
    "table_8222": {
        "table_title": "可变剪切事件统计表",
        "table_note": "注：展示各样本中可变剪切事件数目分布情况。(1) SE：外显子跳跃；(2) A5SS：第一个外显子发生可变剪切；(3) A3SS：最后一个外显子发生可变剪切；(4) MXE：外显子选择性跳跃；(5) RI：内含子滞留。"
    },
    "table_8223": {
        "table_title": "聚类统计表",
        "table_note": "注：第一列表示聚类，第二列为聚类的基因数目。"
    },
    "table_8772": {
        "table_title": "可变剪切事件详情表",
        "table_note": "注：（1）AS id: AS事件编号；（2）Type：AS事件类型，（TSS, TTS, SKIP_{ON,OFF}, XSKIP_{ON,OFF}, MSKIP_{ON,OFF}, XMSKIP_{ON,OFF}, IR_{ON ,OFF}, XIR_{ON,OFF}, AE, XAE）；（3）Gene id：AS事件所在基因的编号；（4）Gene name：基因名称；（5）Strand：基因正负链信息（6）Gene description：基因的描述信息；（7）Chrom：染色体编号；（8）Event_start：AS事件起始位置；（9）Event_end： AS事件结束位置；（10）Event_pattern：AS事件特征 。"
    },
    "table_8773": {
        "table_title": "可变剪切事件统计表",
        "table_note": "注：展示各样本中可变剪切事件数目分布情况。（1）SKIP：Skipped exon（SKIP_ON,SKIP_OFF pair）单外显子跳跃；（2）XSKIP：Approximate SKIP （XSKIP_ON,XSKIP_OFF pair）单外显子跳跃（模糊边界）；（3）MSKIP：Multi-exon SKIP （MSKIP_ON,MSKIP_OFF pair）多外显子跳跃；（4）XMSKIP：Approximate MSKIP （XMSKIP_ON,XMSKIP_OFF pair）多外显子跳跃（模糊边界）；（5）IR：Intron retention （IR_ON, IR_OFF pair）单内含子滞留；（6）XIR：Approximate IR（XIR_ON, XIR_OFF pair）单内含子滞留（模糊边界）；（8）MIR：Multi-IR（MIR_ON, MIR_OFF pair）多内含子滞留；（9） XMIR：Approximate MIR（XMIR_ON, XMIR_OFF pair）多内含子滞留（模糊边界）；（10）AE：Alternative exon ends（5', 3', or both）可变5'或3'端剪切；（11）XAE：Approximate AE可变5'或3'端剪切（模糊边界）；（12）TSS：Alternative 5' first exon （transcription start site）第一个外显子可变剪切；（13）TTS：Alternative 3' last exon （transcription terminal site）最后一个外显子可变剪切。"
    },
    "table_8774": {
        "table_title": "基因融合分析详情表",
        "table_note": "注：（1）Fusion name：融合事件名称；（2）JunctionReads：支持融合事件发生的junction reads数目；（3）SpanningFrags：支持融合事件发生的Spanning fragments数目；（4）LeftGene：融合事件的上游基因；（5）LeftBreakpoint：上游基因在基因序列上的断点位置（断点位置是从每个基因序列的5’端开始）；（6）RightGene：融合事件的下游基因；（7）RightBreakpoint：下游基因在基因序列上的断点位置（断点位置是从每个基因序列的5’端开始）；（8）Splice type：鉴定的融合断点是否位于已知基因结构的外显子剪接位点。"
    },
    "table_8775": {
        "table_title": "基因融合分析统计表",
        "table_note": "注：展示每个样本中发生基因融合的事件数目。"
    },
    "table_8776": {
        "table_title": "基因融合Venn分析详情表",
        "table_note": "注：（1）Fusion name：融合事件名称；（2）LeftGene：融合事件的上游基因；（3）LeftBreakpoint：上游基因在基因序列上的断点位置（断点位置是从每个基因序列的5’端开始）；（4）RightGene：融合事件的下游基因；（5）RightBreakpoint：下游基因在基因序列上的断点位置（断点位置是从每个基因序列的5’端开始）；（6）Splice type：鉴定的融合断点是否位于已知基因结构的外显子剪接位点。"
    },
    "table_8777": {
        "table_title": "时序差异热图对应统计表",
        "table_note": "注：（1）Time order：时间顺序；（2）High level transcript：聚类基因/转录本数目。"
    },
    "table_8779": {
        "table_title": "分析记录表",
        "table_note": "注：展示目标分组方案或差异分组方案的所有已分析内容，并可通过筛选表格基于关键词进行检索。（1）Analysis Content：目标分组方案或差异分组方案，对应分析内容（括号中的数字代表分析次数）；（2）Analysis Record：分析记录，点击可跳转到对应模块查看其分析结果；（3）Analysis description：分析记录对应描述，分析记录可在右侧“分析记录”导航栏处进行编辑，方便后续查找和管理；（4）Analysis Status：分析状态；（5）Sample Group：分析记录对应的分组方案；（6）Diff_comparison Group：分析记录对应的差异分组方案。"
    },
    "table_8780": {
        "table_title": "分析记录表",
        "table_note": "注：展示目标基因集的所有已分析内容，并可通过筛选表格基于关键词进行检索。（1）Analysis Content：目标基因集对应分析内容（括号中的数字代表分析次数）；（2）Analysis Record：分析记录，点击可跳转到对应模块查看其分析结果；（3）Analysis description：分析记录对应描述，分析记录可在右侧“分析记录”导航栏处进行编辑，方便后续查找和管理；（4）Analysis Status：分析状态；（5）Notes：该分析记录所对应的基因集。"
    },
    "table_8784": {
        "table_title": "批次效应评估表",
        "table_note": "批次效应评估表"
    },
    "table_8928": {
        "table_title": "可变剪切事件比较详情表",
        "table_note": "注：（1）New AS id: AS事件编号；（2）Type：AS事件类型，（TSS, TTS, SKIP_{ON,OFF}, XSKIP_{ON,OFF}, MSKIP_{ON,OFF}, XMSKIP_{ON,OFF}, IR_{ON ,OFF}, XIR_{ON,OFF}, AE, XAE）；（3）Gene id：AS事件所在基因的编号；（4）Gene name：基因名称；（5）Strand：基因正负链信息（6）Gene description：基因的描述信息；（7）Chrom：染色体编号；（8）Event_start：AS事件起始位置；（9）Event_end： AS事件结束位置；（10）Event_pattern：AS事件特征 。"
    },
    "table_8929": {
        "table_title": "GSEA分析统计表",
        "table_note": "注：1）size：代表该基因集下的基因总数。2）ES值：enrichment score，反应基因集成员在排序列表的两端富集的程度；3）NES值：标准化富集得分；4）p-value：针对获得的富集得分进行统计学检验；5）p adjust：多重假设检验矫正p-value；6）Rank at MAX：该基因集ES值出现在排序列表中的位置；7）Leading-edge：对富集得分贡献最大的基因成员。(说明：NES 绝对值越大，P adjust 越小，富集越显著，当每组样本数目＜7时，建议选择 p adjust ＜0.05的 gene sets 进行后续分析；当每组样本数＞7时，p adjust 可放宽到＜0.25。）"
    },
    "table_9140": {
        "table_title": "序列批量下载表",
        "table_note": "注：选择目标基因集/转录本集，勾选对应的序列类型，点击下载即可投递任务，运行成功后，相应结果到interaction_results--07 Seq_Download（序列下载结果目录）处查看。"
    },
    "table_9141": {
        "table_title": "差异基因数目统计表",
        "table_note": "注：（1）diff_group：差异比较组别；（2）total DEG/DET：差异基因/转录本数目；（3）up：上调差异基因/转录本数目；（4）down：下调差异基因/转录本数目。"
    },
    "table_9204": {
        "table_title": "无尺度容适曲线与平均连通度曲线",
        "table_note": "无尺度容适曲线与平均连通度曲线"
    },
    "table_9811": {
        "table_title": "可变剪接事件详情表",
        "table_note": "注：(1) AS ID：AS事件编号；(2) Gene ID：AS事件所在基因的编号；(3) Gene name：基因名称； (4) Gene description：基因的描述信息；(5) AS type：AS 类型；(6) Novel AS：是否为新发现可变剪切；(7) chr：AS事件所在染色体编号；(8) strand：基因正负链信息；(9) Diff significant：是否发生差异可变剪切；(10) IncLevelDiff (PSI1/PSI2, ΔPSI)  (注：PSI1 为处理组，PSI2为对照组, ΔPSI=PSI1-PSI2）：可变剪切事件在两组中发生的差值；(11) p value JunctionCountOnly：该AS事件在比较组中差异显著性检验结果；(12) FDR JunctionCountOnly：多重检验矫正后的Pvalue值。(注：PS1 为处理组，PS2为对照组）\r\n其他具体参考此链接：http://www.majorbio.com/wenku/info/1554。"
    },
    "table_9812": {
        "table_title": "组内差异可变剪切事件统计表",
        "table_note": "注：(1) AS type：可变剪切事件类型；(2) JunctionCountOnly(JC)：差异AS事件仅使用inclusion counts进行检测定量；(3) ReadsOnTargetAndJunctionCounts(JCEC)：差异AS事件同时使用Junction Counts和reads on target进行检测定量；(4) A &amp; B：(2)和(3)两种方法的交集；(5) A | B：(2)和(3)两种方法的并集。"
    },
    "table_9813": {
        "table_title": "组内差异可变剪切模式变化统计表",
        "table_note": "注：(1)AS type：可变剪切事件类型；(2) Exclusion (Increase exclusion in case, ΔPSI＜0)： 表示该可变剪切事件发生exon exclusion的情况大于exon inclusion；(3) Inclusion (Increase inclusion in case, ΔPSI＞0)：表示该可变剪切事件发生exon inclusion的情况大于exon exclusion；(4) Total event：可变剪切事件总数。"
    },
    "table_9949": {
        "table_title": "SNP/Indel 注释表",
        "table_note": "注：(1) Gene(in or nearby)：SNP所属的基因（附近基因）编号；(2) Gene name：基因名称；(3) Gene description：基因的描述信息；(4) Chrom：染色体编号；(5) Start：SNP位点起始位置；(6) End：SNP位点终止位置；(7) Ref：参考基因上的碱基；(8) Alt：突变之后的碱基；(9) QUAL：检测位点的可信度（即质量值，Q=-10lgP, P表示这个位点发生错误的概率。该值越大，结果越可信，仅多样本时展示）(10) Anno：突变发生的位置；(11) MUT type：SNP导致的突变类型（同义突变或非同义突变）；(12) MUT info：突变的详细信息 (基因:转录本:外显子:核酸:氨基酸)，egg：MS.gene31631:MS.gene31631.t1:exon1:c.A145C:p.I49L    基因编号：转录本编号：外显子：c-编码核酸，对应转录本的第一个外显子的145号位置A>C（A转换成C)：p-蛋白49号位置I>L(I异氨酸转换为亮氨酸L）；(13) *_genotype：样本在该SNP位点的基因型（括号中&quot;/&quot;前指的是该样本测到的参考基因组，即Ref的碱基，&quot;/&quot;后指的是该样本测到的突变后，即Alt的碱基。若二者跟Ref相同，说明该样本没发生突变；若二者跟Alt相同，则说明发生了纯合突变；若此处为空白，说明没有测到该样本此位点信息。）；(14) *_depth：样本在该SNP位点的测序深度（括号中逗号前指的是该样本测到的参考基因组，即Ref支持的reads数，逗号后指的是该样本测到的突变后，即Alt支持的read数）。(注：老版本中 “ *_mut_rate ” 代表支持该突变位点的突变频率，即支持该突变位点的reads 数/ 覆盖到该位点的总reads 数）"
    },
    "table_9950": {
        "table_title": "",
        "table_note": "注：(1) Gene(in or nearby)：SNP所属的基因（附近基因）编号；(2) Gene name：基因名称；(3) Gene description：基因的描述信息；(4) Chrom：染色体编号；(5) Start：SNP位点起始位置；(6) End：SNP位点终止位置；(7) Ref：参考基因上的碱基；(8) Alt：突变之后的碱基；(9) QUAL：检测位点的可信度（即质量值，Q=-10lgP, P表示这个位点发生错误的概率。该值越大，结果越可信，仅多样本时展示）(10) Anno：突变发生的位置；(11) MUT type：SNP导致的突变类型（同义突变或非同义突变）；(12) MUT info：突变的详细信息 (基因:转录本:外显子:核酸:氨基酸)，egg：MS.gene31631:MS.gene31631.t1:exon1:c.A145C:p.I49L    基因编号：转录本编号：外显子：c-编码核酸，对应转录本的第一个外显子的145号位置A>C（A转换成C)：p-蛋白49号位置I>L(I异氨酸转换为亮氨酸L）；(13) *_genotype：样本在该SNP位点的基因型（括号中&quot;/&quot;前指的是该样本测到的参考基因组，即Ref的碱基，&quot;/&quot;后指的是该样本测到的突变后，即Alt的碱基。若二者跟Ref相同，说明该样本没发生突变；若二者跟Alt相同，则说明发生了纯合突变；若此处为空白，说明没有测到该样本此位点信息。）；(14) *_depth：样本在该SNP位点的测序深度（括号中逗号前指的是该样本测到的参考基因组，即Ref支持的reads数，逗号后指的是该样本测到的突变后，即Alt支持的read数）。(注：老版本中 “ *_mut_rate ” 代表支持该突变位点的突变频率，即支持该突变位点的reads 数/ 覆盖到该位点的总reads 数）"
    },
    "table_append_01": {
        "table_title": "分析软件信息"
    },
    "table_append_02": {
        "table_title": "结果目录查看说明"
    }
}