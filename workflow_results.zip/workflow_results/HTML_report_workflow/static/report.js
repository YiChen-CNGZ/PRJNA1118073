var report_data = {
    "category": {
        "category_3691": {
            "path": "", 
            "category_name": "结题报告"
        }, 
        "category_1489": {
            "path": "", 
            "category_name": "转录因子靶基因预测"
        }, 
        "category_1485": {
            "path": "", 
            "category_name": "转录因子预测"
        }, 
        "category_1487": {
            "path": "", 
            "category_name": "转录因子家族统计"
        }, 
        "category_1481": {
            "path": "", 
            "category_name": "模块分析"
        }, 
        "category_1483": {
            "path": "", 
            "category_name": "可视化分析"
        }, 
        "category_1369": {
            "category_name": "转录组组装概览"
        }, 
        "category_1365": {
            "category_name": "比对结果统计"
        }, 
        "category_1367": {
            "category_name": "转录组质量评估"
        }, 
        "category_1361": {
            "category_name": "原始数据统计"
        }, 
        "category_1363": {
            "category_name": "质控数据统计"
        }, 
        "category_1471": {
            "category_name": "差异可变剪切事件模式图"
        }, 
        "category_1473": {
            "path": "workflow_results/09AS/model_vs_control", 
            "path_exists": false, 
            "category_name": "差异可变剪切事件比较"
        }, 
        "category_1477": {
            "path": "", 
            "category_name": "数据预处理"
        }, 
        "category_3450": {
            "path": "", 
            "category_name": "目标SNP/Indel查询"
        }, 
        "category_1479": {
            "path": "", 
            "category_name": "模块识别"
        }, 
        "category_3020": {
            "path": "", 
            "category_name": "无尺度容适曲线与平均连通度曲线"
        }, 
        "category_1405": {
            "path": "workflow_results/08SNP", 
            "path_exists": true, 
            "category_name": "SNP/InDel分析"
        }, 
        "category_1407": {
            "path": "workflow_results/09AS", 
            "path_exists": true, 
            "category_name": "可变剪切分析"
        }, 
        "category_1401": {
            "path": "", 
            "category_name": "功能富集分析"
        }, 
        "category_1403": {
            "path": "workflow_results/06Express/ExpPCA", 
            "path_exists": true, 
            "category_name": "表达相关性分析"
        }, 
        "category_1399": {
            "path": "", 
            "category_name": "功能注释分析"
        }, 
        "category_1409": {
            "category_name": "蛋白互作网络分析"
        }, 
        "category_1359": {
            "category_name": "测序数据统计"
        }, 
        "category_4105": {
            "path": "", 
            "category_name": "差异可变剪切事件详情"
        }, 
        "category_4104": {
            "path": "", 
            "category_name": "差异可变剪切事件统计"
        }, 
        "category_1391": {
            "path": "workflow_results/06Express", 
            "path_exists": true, 
            "category_name": "样本关系分析"
        }, 
        "category_1373": {
            "path": "workflow_results/05Annotation/AnnotStatistics", 
            "path_exists": true, 
            "category_name": "功能注释统计"
        }, 
        "category_1393": {
            "category_name": "表达量差异统计"
        }, 
        "category_1417": {
            "category_name": "参考基因组信息"
        }, 
        "category_1415": {
            "category_name": "转录因子分析"
        }, 
        "category_1413": {
            "category_name": "WGCNA"
        }, 
        "category_1411": {
            "category_name": "iPath代谢通路分析"
        }, 
        "category_1395": {
            "path": "workflow_results/10GeneSet/07_GenesetVenn/", 
            "path_exists": true, 
            "category_name": "Venn分析"
        }, 
        "category_1389": {
            "path": "workflow_results/06Express/ExpAnnalysis", 
            "path_exists": true, 
            "category_name": "表达量统计"
        }, 
        "category_1419": {
            "category_name": "项目样本信息"
        }, 
        "category_1397": {
            "path": "workflow_results/06Express/ExpCorr", 
            "path_exists": true, 
            "category_name": "聚类分析"
        }, 
        "category_1337": {
            "path": "workflow_results/03Align", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "序列比对分析"
        }, 
        "category_1335": {
            "path": "workflow_results/02QC", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "测序数据质控"
        }, 
        "category_1333": {
            "path": "workflow_results/01Background", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "项目背景"
        }, 
        "category_1339": {
            "path": "workflow_results/04Assemble", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "转录本组装"
        }, 
        "category_1423": {
            "category_name": "分组方案管理"
        }, 
        "category_1421": {
            "category_name": "分析软件信息"
        }, 
        "category_1427": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "测序饱和度分析"
        }, 
        "category_1425": {
            "category_name": "基因集管理"
        }, 
        "category_1429": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "测序覆盖度分析"
        }, 
        "category_1439": {
            "path": "workflow_results/06Express/ExpVenn", 
            "path_exists": true, 
            "category_name": "样本间Venn分析"
        }, 
        "category_1435": {
            "path": "workflow_results/06Express/ExpAnnalysis", 
            "path_exists": true, 
            "category_name": "表达量矩阵"
        }, 
        "category_1437": {
            "path": "workflow_results/06Express/ExpAnnalysis", 
            "path_exists": true, 
            "category_name": "表达量分布"
        }, 
        "category_1431": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "不同区域Reads分布"
        }, 
        "category_1433": {
            "path": "workflow_results/03Align/QualityAssessment", 
            "path_exists": true, 
            "category_name": "不同染色体Reads分布"
        }, 
        "category_3007": {
            "path": "", 
            "category_name": "文件获取"
        }, 
        "category_3003": {
            "path": "", 
            "category_name": "项目结果速览"
        }, 
        "category_2989": {
            "path": "", 
            "category_name": "可变剪切事件比较"
        }, 
        "category_2988": {
            "path": "", 
            "category_name": "可变剪切事件统计"
        }, 
        "category_1455": {
            "category_name": "富集弦图"
        }, 
        "category_2985": {
            "path": "", 
            "category_name": "批次效应评估"
        }, 
        "category_1371": {
            "category_name": "新转录本预测"
        }, 
        "category_2987": {
            "path": "", 
            "category_name": "可变剪切事件详情"
        }, 
        "category_2986": {
            "path": "", 
            "category_name": "可变剪切分析-ASprofile"
        }, 
        "category_1449": {
            "path": "workflow_results/10GeneSet/04_KEGG_Annotation", 
            "path_exists": true, 
            "category_name": "KEGG注释分析"
        }, 
        "category_1351": {
            "exists": true, 
            "category_name": "基因结构分析"
        }, 
        "category_3449": {
            "path": "", 
            "category_name": "表达量矩阵"
        }, 
        "category_1353": {
            "path": "", 
            "category_name": "高级分析"
        }, 
        "category_1441": {
            "path": "workflow_results/06Express/ExpCorr", 
            "path_exists": true, 
            "category_name": "样本间相关性分析"
        }, 
        "category_1443": {
            "path": "workflow_results/06Express/ExpPCA", 
            "path_exists": true, 
            "category_name": "样本间PCA分析"
        }, 
        "category_3152": {
            "path": "", 
            "category_name": "GSEA分析"
        }, 
        "category_1445": {
            "path": "workflow_results/10GeneSet/02_COG_Annotation", 
            "path_exists": false, 
            "category_name": "COG注释分析"
        }, 
        "category_1447": {
            "path": "workflow_results/10GeneSet/03_GO_Annotation", 
            "path_exists": true, 
            "category_name": "GO注释分析"
        }, 
        "category_2992": {
            "path": "", 
            "category_name": "基因融合Venn分析"
        }, 
        "category_2990": {
            "path": "", 
            "category_name": "基因融合"
        }, 
        "category_2991": {
            "path": "", 
            "category_name": "基因融合详情"
        }, 
        "category_1347": {
            "path": "workflow_results/07DiffExpress_G", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "表达量差异分析"
        }, 
        "category_1345": {
            "path": "workflow_results/06Express", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "表达量分析"
        }, 
        "category_3384": {
            "path": "", 
            "category_name": "序列批量下载"
        }, 
        "category_1453": {
            "path": "workflow_results/10GeneSet/06_KEGG_Enrich", 
            "path_exists": true, 
            "category_name": "KEGG富集分析"
        }, 
        "category_1451": {
            "path": "workflow_results/10GeneSet/05_GO_Enrich", 
            "path_exists": true, 
            "category_name": "GO富集分析"
        }, 
        "category_1457": {
            "category_name": "GO富集有向无环图"
        }, 
        "category_1349": {
            "path": "workflow_results/10GeneSet", 
            "path_exists": true, 
            "exists": true, 
            "category_name": "基因集分析"
        }, 
        "category_2361": {
            "path": "", 
            "category_name": "时序表达趋势分析"
        }, 
        "category_2360": {
            "path": "", 
            "category_name": "时序分析"
        }, 
        "category_2363": {
            "path": "", 
            "category_name": "GSEA分析"
        }, 
        "category_2362": {
            "path": "", 
            "category_name": "时序差异分析"
        }, 
        "category_2367": {
            "path": "", 
            "category_name": "功能注释与查询"
        }, 
        "category_1459": {
            "category_name": "SNP/InDel注释详情"
        }, 
        "category_1467": {
            "category_name": "可变剪切事件统计"
        }, 
        "category_1465": {
            "path": "workflow_results/09AS", 
            "path_exists": true, 
            "category_name": "差异可变剪切事件详情"
        }, 
        "category_1463": {
            "category_name": "SNP统计"
        }, 
        "category_1461": {
            "category_name": "SNP/InDel不同区域分布"
        }, 
        "category_1469": {
            "category_name": "差异可变剪切事件统计"
        }, 
        "category_2373": {
            "path": "", 
            "category_name": "功能查询"
        }, 
        "category_2370": {
            "path": "", 
            "category_name": "功能注释详情"
        }, 
        "category_2371": {
            "path": "", 
            "category_name": "功能注释统计"
        }, 
        "category_2376": {
            "path": "", 
            "category_name": "GSEA分析-详情"
        }, 
        "category_2377": {
            "path": "", 
            "category_name": "可变剪切事件统计"
        }, 
        "category_2374": {
            "path": "", 
            "category_name": "功能查询"
        }, 
        "category_2375": {
            "path": "", 
            "category_name": "时序表达趋势分析-详情"
        }, 
        "category_2378": {
            "path": "", 
            "category_name": "kegg注释"
        }, 
        "category_2379": {
            "path": "", 
            "category_name": "kegg注释"
        }
    }, 
    "group_dict": {
        "HF": [
            "HF1", 
            "HF2", 
            "HF3"
        ], 
        "NF": [
            "NF1", 
            "NF2", 
            "NF3"
        ]
    }, 
    "dir_data": [
        {
            "text": "01Background           项目背景结果目录", 
            "opened": true, 
            "dir": "01Background", 
            "children": [
                {
                    "text": ".*.genome_info.xls        基因组注释信息表", 
                    "opened": true, 
                    "dir": "01Background/.*.genome_info.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "sample_info.xls        样本信息表", 
                    "opened": true, 
                    "dir": "01Background/sample_info.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "software_info.xls        软件信息表", 
                    "opened": true, 
                    "dir": "01Background/software_info.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "run_parameter.txt        分析参数日志", 
                    "opened": true, 
                    "dir": "01Background/run_parameter.txt", 
                    "icon": "fa fa-file-text"
                }
            ]
        }, 
        {
            "text": "02QC           测序数据质控结果目录", 
            "opened": true, 
            "dir": "02QC", 
            "children": [
                {
                    "text": ".*raw_qc_qual.box.pdf        原始数据碱基质量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*raw_qc_qual.box.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*raw_qc_error.line.pdf        原始数据碱基错误率分布图", 
                    "opened": true, 
                    "dir": "02QC/.*raw_qc_error.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*raw_qc_base.line.pdf        原始数据碱基含量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*raw_qc_base.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*clean_qc_qual.box.pdf        质控数据碱基质量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*clean_qc_qual.box.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*clean_qc_error.line.pdf        质控数据碱基错误率分布图", 
                    "opened": true, 
                    "dir": "02QC/.*clean_qc_error.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*clean_qc_base.line.pdf        质控数据碱基含量分布图", 
                    "opened": true, 
                    "dir": "02QC/.*clean_qc_base.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "qc_pdf.tar.gz        测序数据统计图", 
                    "opened": true, 
                    "dir": "02QC/qc_pdf.tar.gz", 
                    "icon": "fa fa-file-zip-o"
                }, 
                {
                    "text": "rawdata_statistics.xls        原始数据统计表", 
                    "opened": true, 
                    "dir": "02QC/rawdata_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "cleandata_statistics.xls        质控数据统计表", 
                    "opened": true, 
                    "dir": "02QC/cleandata_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "qc_data_statistics.xls        质控数据统计表", 
                    "opened": true, 
                    "dir": "02QC/qc_data_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }
            ]
        }, 
        {
            "text": "03Align           序列比对结果目录", 
            "opened": true, 
            "dir": "03Align", 
            "children": [
                {
                    "text": "align_stat.xls        比对结果统计表", 
                    "opened": true, 
                    "dir": "03Align/align_stat.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "QualityAssessment        比对结果整体评估", 
                    "opened": true, 
                    "dir": "03Align/QualityAssessment", 
                    "children": [
                        {
                            "text": ".*align.satu.*.pdf        测序饱和度曲线图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align.satu.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*align_pos_dist.*.pdf        不同区域Reads分布统计饼图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align_pos_dist.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*align_coverage.*.pdf        测序覆盖度分布图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align_coverage.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*align_chr_dist.*.pdf        不同染色体Reads分布统计柱状图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/.*align_chr_dist.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "align_pdf.tar.gz        转录组质量评估图", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/align_pdf.tar.gz", 
                            "icon": "fa fa-file-zip-o"
                        }, 
                        {
                            "text": "chr_distribution.xls        不同染色体Reads分布统计表", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/chr_distribution.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "region_distribution.xls        不同区域Reads分布统计表", 
                            "opened": true, 
                            "dir": "03Align/QualityAssessment/region_distribution.xls", 
                            "icon": "fa fa-file-excel-o"
                        }
                    ]
                }
            ]
        }, 
        {
            "text": "04Assemble           组装结果目录", 
            "opened": true, 
            "dir": "04Assemble", 
            "children": [
                {
                    "text": "all.assemble.*.column.pdf        转录本长度分布柱状图", 
                    "opened": true, 
                    "dir": "04Assemble/all.assemble.*.column.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "all.assemble.*.pie.pdf        转录本长度分布饼图", 
                    "opened": true, 
                    "dir": "04Assemble/all.assemble.*.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*assemble_relation.*.columns.pdf        基因与转录本关系柱状图", 
                    "opened": true, 
                    "dir": "04Assemble/.*assemble_relation.*.columns.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*assemble_relation.*.line.pdf        外显子与转录本关系曲线图", 
                    "opened": true, 
                    "dir": "04Assemble/.*assemble_relation.*.line.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "length_distribution.200.xls        转录本长度分布表-步长200", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.200.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "length_distribution.300.xls        转录本长度分布表-步长300", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.300.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "length_distribution.600.xls        转录本长度分布表-步长600", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.600.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "length_distribution.1000.xls        转录本长度分布表-步长1000", 
                    "opened": true, 
                    "dir": "04Assemble/length_distribution.1000.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "classcode_statistics.xls        新转录本类型统计表", 
                    "opened": true, 
                    "dir": "04Assemble/classcode_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "Sequence        转录本序列文件", 
                    "opened": true, 
                    "dir": "04Assemble/Sequence", 
                    "children": [
                        {
                            "text": "all_transcripts.fa        组装结果序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_transcripts.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "new_transcripts.fa        新转录本序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/new_transcripts.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "all_cds.fa        CDS序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_cds.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "all_pep.fa        蛋白序列文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_pep.fa", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "all_id.xls        基因转录本蛋白ID对应关系文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_id.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "all_transcripts.gtf        组装结果GTF文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/all_transcripts.gtf", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "new_transcripts.gtf        新转录本GTF文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/new_transcripts.gtf", 
                            "icon": "fa fa-file-text"
                        }, 
                        {
                            "text": "trans2gene.txt        转录本与基因的对应关系文件", 
                            "opened": true, 
                            "dir": "04Assemble/Sequence/trans2gene.txt", 
                            "icon": "fa fa-file-text"
                        }
                    ]
                }
            ]
        }, 
        {
            "text": "06Express           表达量分析结果目录", 
            "opened": true, 
            "dir": "06Express", 
            "children": [
                {
                    "text": "ExpAnnalysis        表达定量结果", 
                    "opened": true, 
                    "dir": "06Express/ExpAnnalysis", 
                    "children": [
                        {
                            "text": ".*exp_distribution.box.pdf        表达量分布盒型图", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/.*exp_distribution.box.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*exp_distribution.density.pdf        表达量分布密度图", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/.*exp_distribution.density.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*exp_distribution.violin.pdf        表达量分布小提琴图", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/.*exp_distribution.violin.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "gene.count.matrix.xls        基因count表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.count.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.tpm.matrix.xls        基因tpm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.tpm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.fpkm.matrix.xls        基因fpkm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.fpkm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.count.matrix.xls        转录本count表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.count.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.tpm.matrix.xls        转录本tpm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.tpm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.fpkm.matrix.xls        转录本fpkm表达定量结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.fpkm.matrix.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.tpm.matrix.annot.xls        基因tpm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.tpm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.fpkm.matrix.annot.xls        基因fpkm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.fpkm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "gene.count.matrix.annot.xls        基因count表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/gene.count.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.tpm.matrix.annot.xls        转录本tpm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.tpm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.fpkm.matrix.annot.xls        转录本fpkm表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.fpkm.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "transcript.count.matrix.annot.xls        转录本count表达定量注释结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpAnnalysis/transcript.count.matrix.annot.xls", 
                            "icon": "fa fa-file-excel-o"
                        }
                    ]
                }, 
                {
                    "text": "ExpVenn        样本间Venn分析", 
                    "opened": true, 
                    "dir": "06Express/ExpVenn", 
                    "children": [
                        {
                            "text": ".*.venn.pdf        样本间venn图", 
                            "opened": true, 
                            "dir": "06Express/ExpVenn/.*.venn.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*.upset.pdf        样本间upset图", 
                            "opened": true, 
                            "dir": "06Express/ExpVenn/.*.upset.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }
                    ]
                }, 
                {
                    "text": "ExpCor        样本间相关性分析", 
                    "opened": true, 
                    "dir": "06Express/ExpCor"
                }, 
                {
                    "text": "ExpPCA        样本间PCA分析", 
                    "opened": true, 
                    "dir": "06Express/ExpPCA", 
                    "children": [
                        {
                            "text": ".*all.exp_relation.*.pdf        样本间PCA图", 
                            "opened": true, 
                            "dir": "06Express/ExpPCA/.*all.exp_relation.*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "PCA.xls        样本间PCA分析结果表", 
                            "opened": true, 
                            "dir": "06Express/ExpPCA/PCA.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "Explained_variance_ratio.xls        样本间PCA主成分解释表", 
                            "opened": true, 
                            "dir": "06Express/ExpPCA/Explained_variance_ratio.xls", 
                            "icon": "fa fa-file-excel-o"
                        }
                    ]
                }
            ]
        }, 
        {
            "text": "07DiffExpress_G           表达量差异分析结果目录", 
            "opened": true, 
            "dir": "07DiffExpress_G", 
            "children": [
                {
                    "text": ".*_vs_.*.xls        差异分析结果表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*_vs_.*.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": ".*.DE.list        差异基因列表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*.DE.list"
                }, 
                {
                    "text": ".*summary.*.xls        差异表达基因统计表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*summary.*.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": ".*total_diff_stat.*.xls        差异表达基因详情总表", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*total_diff_stat.*.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "all.diffexp.*.pdf        表达量差异统计图", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/all.diffexp.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*diffexp.volcano.*.pdf        表达量差异火山图", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*diffexp.volcano.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*diffexp.scatter.*.pdf        表达量差异散点图", 
                    "opened": true, 
                    "dir": "07DiffExpress_G/.*diffexp.scatter.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }
            ]
        }, 
        {
            "text": "08SNP           SNP/InDel分析结果目录", 
            "opened": true, 
            "dir": "08SNP", 
            "children": [
                {
                    "text": ".*snp.pos_stat.pie.pdf        SNP不同区域分布饼图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.pos_stat.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.type_stat.column.pdf        SNP类型统计图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.type_stat.column.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.type_stat.pie.pdf        SNP类型饼图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.type_stat.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.depth_stat.column.pdf        SNP深度统计图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.depth_stat.column.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": ".*snp.depth_stat.pie.pdf        SNP深度饼图", 
                    "opened": true, 
                    "dir": "08SNP/.*snp.depth_stat.pie.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "SNP_vcf        SNP鉴定vcf结果目录", 
                    "opened": true, 
                    "dir": "08SNP/SNP_vcf"
                }, 
                {
                    "text": "snp_pdf.tar.gz        SNP统计图", 
                    "opened": true, 
                    "dir": "08SNP/snp_pdf.tar.gz", 
                    "icon": "fa fa-file-zip-o"
                }, 
                {
                    "text": "snp_anno.xls        SNP分析结果注释详情表", 
                    "opened": true, 
                    "dir": "08SNP/snp_anno.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "indel_anno.xls        InDel分析结果注释详情表", 
                    "opened": true, 
                    "dir": "08SNP/indel_anno.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_transition_tranversion_statistics.xls        SNP类型统计结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_transition_tranversion_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_freq_statistics.xls        SNP频率统计结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_freq_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_depth_statistics.xls        SNP深度统计结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_depth_statistics.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "snp_position_distribution.xls        SNP不同区域布析结果表", 
                    "opened": true, 
                    "dir": "08SNP/snp_position_distribution.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "indel_position_distribution.xls        InDel不同区域布析结果表", 
                    "opened": true, 
                    "dir": "08SNP/indel_position_distribution.xls", 
                    "icon": "fa fa-file-excel-o"
                }
            ]
        }, 
        {
            "text": "09AS           可变剪切分析结果目录", 
            "opened": true, 
            "dir": "09AS", 
            "children": [
                {
                    "text": ".*_vs_.*        差异组别", 
                    "opened": true, 
                    "dir": "09AS/.*_vs_.*", 
                    "children": [
                        {
                            "text": "JC        JC定量", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/JC", 
                            "children": [
                                {
                                    "text": "SE.detail.xls        SE可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/SE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "MXE.detail.xls        MXE可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/MXE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A3SS.detail.xls        A3SS可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/A3SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A5SS.detail.xls        A5SS可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/A5SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "RI.detail.xls        RI可变剪切事件详情表（JC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JC/RI.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }
                            ]
                        }, 
                        {
                            "text": "JCEC        JCEC定量", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/JCEC", 
                            "children": [
                                {
                                    "text": "SE.detail.xls        SE可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/SE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "MXE.detail.xls        MXE可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/MXE.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A3SS.detail.xls        A3SS可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/A3SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "A5SS.detail.xls        A5SS可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/A5SS.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "RI.detail.xls        RI可变剪切事件详情表（JCEC）", 
                                    "opened": true, 
                                    "dir": "09AS/.*_vs_.*/JCEC/RI.detail.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }
                            ]
                        }, 
                        {
                            "text": "diff_event_stats.xls        组内差异可变剪切事件统计表", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/diff_event_stats.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "diff_pattern_stats.JC.xls        组内差异可变剪切模式变化统计表（JC）", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/diff_pattern_stats.JC.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": "diff_pattern_stats.JCEC.xls        组内差异可变剪切模式变化统计表（JCEC）", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/diff_pattern_stats.JCEC.xls", 
                            "icon": "fa fa-file-excel-o"
                        }, 
                        {
                            "text": ".*splice_stat.*pie.pdf        组内差异可变剪切事件统计饼状图", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/.*splice_stat.*pie.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": ".*splice_stat.*column.pdf        组内差异可变剪切事件统计柱状图", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/.*splice_stat.*column.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }, 
                        {
                            "text": "rmats_pdf.tar.gz        差异可变剪切事件统计图", 
                            "opened": true, 
                            "dir": "09AS/.*_vs_.*/rmats_pdf.tar.gz", 
                            "icon": "fa fa-file-zip-o"
                        }
                    ]
                }, 
                {
                    "text": ".*splice_stat.*.pdf        可变剪切事件统计图", 
                    "opened": true, 
                    "dir": "09AS/.*splice_stat.*.pdf", 
                    "icon": "fa fa-file-pdf-o"
                }, 
                {
                    "text": "event_type.JC.xls        可变剪切事件统计表（JC）", 
                    "opened": true, 
                    "dir": "09AS/event_type.JC.xls", 
                    "icon": "fa fa-file-excel-o"
                }, 
                {
                    "text": "event_type.JCEC.xls        可变剪切事件统计表（JCEC）", 
                    "opened": true, 
                    "dir": "09AS/event_type.JCEC.xls", 
                    "icon": "fa fa-file-excel-o"
                }
            ]
        }, 
        {
            "text": "10GeneSet           基因集分析结果目录", 
            "opened": true, 
            "dir": "10GeneSet", 
            "children": [
                {
                    "text": "07_GenesetVenn        差异基因集venn分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/07_GenesetVenn", 
                    "children": [
                        {
                            "text": "*.pdf        差异基因集venn图", 
                            "opened": true, 
                            "dir": "10GeneSet/07_GenesetVenn/*.pdf", 
                            "icon": "fa fa-file-pdf-o"
                        }
                    ]
                }, 
                {
                    "text": "01_Cluster_Analysis        基因集聚类分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/01_Cluster_Analysis", 
                    "children": [
                        {
                            "text": "*        基因集聚类分析结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/01_Cluster_Analysis/*", 
                            "children": [
                                {
                                    "text": "subcluster_xls.tar.gz        聚类详情表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/subcluster_xls.tar.gz", 
                                    "icon": "fa fa-file-zip-o"
                                }, 
                                {
                                    "text": "seq.cluster_tree.txt        基因/转录本聚类树文件", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/seq.cluster_tree.txt", 
                                    "icon": "fa fa-file-text"
                                }, 
                                {
                                    "text": "seq.kmeans_cluster.txt        基因/转录本聚类树文件", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/seq.kmeans_cluster.txt", 
                                    "icon": "fa fa-file-text"
                                }, 
                                {
                                    "text": "sample.cluster_tree.txt        样本聚类树文件", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/sample.cluster_tree.txt", 
                                    "icon": "fa fa-file-text"
                                }, 
                                {
                                    "text": "expression_matrix.xls        聚类热图分析表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/expression_matrix.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "seq.subcluster_*.xls        子聚类分析表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/seq.subcluster_*.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "heatmap.pdf        聚类热图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/heatmap.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*heat_corr.pdf        聚类热图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/*heat_corr.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*.line.pdf        子聚类折线图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/01_Cluster_Analysis/*/*.line.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "02_COG_Annotation        基因集聚COG分类结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/02_COG_Annotation", 
                    "children": [
                        {
                            "text": "*        基因集聚COG分类结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/02_COG_Annotation/*", 
                            "children": [
                                {
                                    "text": "cog_class_stat.xls        COG分类统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/02_COG_Annotation/*/cog_class_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*.pdf        COG分类统计图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/02_COG_Annotation/*/*.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "03_GO_Annotation        基因集GO分类结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/03_GO_Annotation", 
                    "children": [
                        {
                            "text": "*        基因集GO分类结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/03_GO_Annotation/*", 
                            "children": [
                                {
                                    "text": "go_class_stat.xls        GO分类统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/03_GO_Annotation/*/go_class_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*.pdf        GO分类统计图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/03_GO_Annotation/*/*.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "04_KEGG_Annotation        基因集KEGG分类结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/04_KEGG_Annotation", 
                    "children": [
                        {
                            "text": "*        基因集KEGG分类结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/04_KEGG_Annotation/*", 
                            "children": [
                                {
                                    "text": "pathways.tar.gz        KEGG通路图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/04_KEGG_Annotation/*/pathways.tar.gz", 
                                    "icon": "fa fa-file-zip-o"
                                }, 
                                {
                                    "text": "kegg_class_stat.xls        Pathway分类统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/04_KEGG_Annotation/*/kegg_class_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*.pdf        KEGG分类统计图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/04_KEGG_Annotation/*/*.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "05_GO_Enrich        基因集GO富集分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/05_GO_Enrich", 
                    "children": [
                        {
                            "text": "*        基因集GO富集分析结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/05_GO_Enrich/*", 
                            "children": [
                                {
                                    "text": "go_enrich_stat.xls        GO富集分析统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/go_enrich_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "*bar.pdf        GO富集分析柱形图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*bar.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*bar_line.pdf        GO富集分析柱形图(带折线)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*bar_line.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble.pdf        GO富集分析气泡图(单基因集)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*buble.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble2.pdf        GO富集分析气泡图(分散型)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/05_GO_Enrich/*/*buble2.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }, 
                {
                    "text": "06_KEGG_Enrich        基因集KEGG富集分析结果目录", 
                    "opened": true, 
                    "dir": "10GeneSet/06_KEGG_Enrich", 
                    "children": [
                        {
                            "text": "*        基因集KEGG富集分析结果目录", 
                            "opened": true, 
                            "dir": "10GeneSet/06_KEGG_Enrich/*", 
                            "children": [
                                {
                                    "text": "kegg_enrich_stat.xls        KEGG富集分析统计表", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/kegg_enrich_stat.xls", 
                                    "icon": "fa fa-file-excel-o"
                                }, 
                                {
                                    "text": "pathways.tar.gz        KEGG富集通路图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/pathways.tar.gz", 
                                    "icon": "fa fa-file-zip-o"
                                }, 
                                {
                                    "text": "*bar.pdf        KEGG富集分析柱形图", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*bar.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*bar_line.pdf        KEGG富集分析柱形图(带折线)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*bar_line.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble.pdf        KEGG富集分析气泡图(单基因集)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*buble.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }, 
                                {
                                    "text": "*buble2.pdf        KEGG富集分析气泡图(分散型)", 
                                    "opened": true, 
                                    "dir": "10GeneSet/06_KEGG_Enrich/*/*buble2.pdf", 
                                    "icon": "fa fa-file-pdf-o"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ], 
    "image": {
        "image_5883": {
            "image_file": {
                "NF1": "workflow_results/08SNP/NF1.snp.type_stat.column.jpg", 
                "NF2": "workflow_results/08SNP/NF2.snp.type_stat.column.jpg", 
                "NF3": "workflow_results/08SNP/NF3.snp.type_stat.column.jpg", 
                "HF1": "workflow_results/08SNP/HF1.snp.type_stat.column.jpg", 
                "HF2": "workflow_results/08SNP/HF2.snp.type_stat.column.jpg", 
                "HF3": "workflow_results/08SNP/HF3.snp.type_stat.column.jpg"
            }, 
            "image_title": "SNP类型统计柱状图"
        }, 
        "image_7661": {
            "image_file": {
                "HF_vs_NF": "workflow_results/07DiffExpress_G/HF_vs_NF.diffexp.volcano.jpg"
            }, 
            "image_title": "表达量差异火山图"
        }, 
        "image_6055": {
            "image_file": "workflow_results/06Express/ExpPCA/all.exp_relation_pca.scatter.jpg", 
            "image_title": "PCA图"
        }, 
        "image_6095": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/03_GO_Annotation/HF_vs_NF_G/HF_vs_NF_G.go_annot.gene_set.column.jpg"
            }, 
            "image_title": "GO分类统计柱形图"
        }, 
        "image_5987": {
            "image_file": "workflow_results/04Assemble/all.assemble_new.pie.jpg", 
            "image_title": "新转录本类型分布饼状图"
        }, 
        "image_5989": {
            "image_file": "workflow_results/04Assemble/all.assemble_len.column.jpg", 
            "image_title": "转录本长度分布柱状图"
        }, 
        "image_6019": {
            "image_file": {
                "NF1": "workflow_results/02QC/NF1.clean_qc_base.line.jpg", 
                "NF2": "workflow_results/02QC/NF2.clean_qc_base.line.jpg", 
                "NF3": "workflow_results/02QC/NF3.clean_qc_base.line.jpg", 
                "HF1": "workflow_results/02QC/HF1.clean_qc_base.line.jpg", 
                "HF2": "workflow_results/02QC/HF2.clean_qc_base.line.jpg", 
                "HF3": "workflow_results/02QC/HF3.clean_qc_base.line.jpg"
            }, 
            "image_title": "碱基（组成）分布图"
        }, 
        "image_6009": {
            "image_file": {
                "NF1": "workflow_results/02QC/NF1.raw_qc_qual.curve.jpg", 
                "NF2": "workflow_results/02QC/NF2.raw_qc_qual.curve.jpg", 
                "NF3": "workflow_results/02QC/NF3.raw_qc_qual.curve.jpg", 
                "HF1": "workflow_results/02QC/HF1.raw_qc_qual.curve.jpg", 
                "HF2": "workflow_results/02QC/HF2.raw_qc_qual.curve.jpg", 
                "HF3": "workflow_results/02QC/HF3.raw_qc_qual.curve.jpg"
            }, 
            "image_title": "碱基质量分布图"
        }, 
        "image_10234": {
            "image_file": {
                "HF_vs_NF": "workflow_results/09AS/HF_vs_NF/HF_vs_NF_JC.diff_splice_stat.column.jpg"
            }, 
            "image_title": "差异可变剪接模式变化统计柱形图"
        }, 
        "image_10233": {
            "image_file": {
                "HF_vs_NF": "workflow_results/09AS/HF_vs_NF/HF_vs_NF_JC.diff_splice_stat.pie.jpg"
            }, 
            "image_title": "差异可变剪切事件统计饼状图"
        }, 
        "image_6053": {
            "image_file": "workflow_results/06Express/ExpCorr/all.exp.heat_corr.jpg", 
            "image_title": "样本间相关性热图"
        }, 
        "image_6011": {
            "image_file": {
                "NF1": "workflow_results/02QC/NF1.raw_qc_error.line.jpg", 
                "NF2": "workflow_results/02QC/NF2.raw_qc_error.line.jpg", 
                "NF3": "workflow_results/02QC/NF3.raw_qc_error.line.jpg", 
                "HF1": "workflow_results/02QC/HF1.raw_qc_error.line.jpg", 
                "HF2": "workflow_results/02QC/HF2.raw_qc_error.line.jpg", 
                "HF3": "workflow_results/02QC/HF3.raw_qc_error.line.jpg"
            }, 
            "image_title": "碱基错误率分布图"
        }, 
        "image_6051": {
            "image_file": "workflow_results/06Express/ExpVenn/all.exp.venn.jpg", 
            "image_title": "样本表达基因Venn图"
        }, 
        "image_6013": {
            "image_file": {
                "NF1": "workflow_results/02QC/NF1.raw_qc_base.line.jpg", 
                "NF2": "workflow_results/02QC/NF2.raw_qc_base.line.jpg", 
                "NF3": "workflow_results/02QC/NF3.raw_qc_base.line.jpg", 
                "HF1": "workflow_results/02QC/HF1.raw_qc_base.line.jpg", 
                "HF2": "workflow_results/02QC/HF2.raw_qc_base.line.jpg", 
                "HF3": "workflow_results/02QC/HF3.raw_qc_base.line.jpg"
            }, 
            "image_title": "碱基（组成）分布图"
        }, 
        "image_6015": {
            "image_file": {
                "NF1": "workflow_results/02QC/NF1.clean_qc_qual.curve.jpg", 
                "NF2": "workflow_results/02QC/NF2.clean_qc_qual.curve.jpg", 
                "NF3": "workflow_results/02QC/NF3.clean_qc_qual.curve.jpg", 
                "HF1": "workflow_results/02QC/HF1.clean_qc_qual.curve.jpg", 
                "HF2": "workflow_results/02QC/HF2.clean_qc_qual.curve.jpg", 
                "HF3": "workflow_results/02QC/HF3.clean_qc_qual.curve.jpg"
            }, 
            "image_title": "碱基质量分布图"
        }, 
        "image_6137": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/06_KEGG_Enrich/HF_vs_NF_G/HF_vs_NF_G.kegg_enrich.gene_set.buble.jpg"
            }, 
            "image_title": "KEGG富集分析气泡图"
        }, 
        "image_6017": {
            "image_file": {
                "NF1": "workflow_results/02QC/NF1.clean_qc_error.line.jpg", 
                "NF2": "workflow_results/02QC/NF2.clean_qc_error.line.jpg", 
                "NF3": "workflow_results/02QC/NF3.clean_qc_error.line.jpg", 
                "HF1": "workflow_results/02QC/HF1.clean_qc_error.line.jpg", 
                "HF2": "workflow_results/02QC/HF2.clean_qc_error.line.jpg", 
                "HF3": "workflow_results/02QC/HF3.clean_qc_error.line.jpg"
            }, 
            "image_title": "碱基错误率分布图"
        }, 
        "image_6135": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/06_KEGG_Enrich/HF_vs_NF_G/HF_vs_NF_G.kegg_enrich.gene_set.bar.jpg"
            }, 
            "image_title": "KEGG富集分析柱状图"
        }, 
        "image_5997": {
            "image_file": "workflow_results/05Annotation/AnnotStatistics/annot_gene_stat.column.jpg", 
            "image_title": "转录组功能分类统计柱状图"
        }, 
        "image_8576": {
            "image_file": "workflow_results/09AS/all_JCsplice_stat.column.jpg", 
            "image_title": "可变剪切事件统计图"
        }, 
        "image_6087": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/01_Cluster_Analysis/HF_vs_NF_G/geneset.cluster.heat_corr.jpg"
            }, 
            "image_title": "聚类热图"
        }, 
        "image_5891": {
            "image_file": {
                "NF1": "workflow_results/08SNP/NF1.snp.depth_stat.column.jpg", 
                "NF2": "workflow_results/08SNP/NF2.snp.depth_stat.column.jpg", 
                "NF3": "workflow_results/08SNP/NF3.snp.depth_stat.column.jpg", 
                "HF1": "workflow_results/08SNP/HF1.snp.depth_stat.column.jpg", 
                "HF2": "workflow_results/08SNP/HF2.snp.depth_stat.column.jpg", 
                "HF3": "workflow_results/08SNP/HF3.snp.depth_stat.column.jpg"
            }, 
            "image_title": "SNP深度统计柱状图"
        }, 
        "image_5991": {
            "image_file": "workflow_results/04Assemble/new.assemble_relation_g2t.columns.jpg", 
            "image_title": "基因与转录本关系柱状图"
        }, 
        "image_5993": {
            "image_file": "workflow_results/04Assemble/new.assemble_relation_t2e.line.jpg", 
            "image_title": "外显子与转录本关系曲线图"
        }, 
        "image_6027": {
            "image_file": {
                "NF1": "workflow_results/03Align/QualityAssessment/NF1.align_chr_dist.bar.jpg", 
                "NF2": "workflow_results/03Align/QualityAssessment/NF2.align_chr_dist.bar.jpg", 
                "NF3": "workflow_results/03Align/QualityAssessment/NF3.align_chr_dist.bar.jpg", 
                "HF1": "workflow_results/03Align/QualityAssessment/HF1.align_chr_dist.bar.jpg", 
                "HF2": "workflow_results/03Align/QualityAssessment/HF2.align_chr_dist.bar.jpg", 
                "HF3": "workflow_results/03Align/QualityAssessment/HF3.align_chr_dist.bar.jpg"
            }, 
            "image_title": "Reads在不同染色体分布柱状图"
        }, 
        "image_8570": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/05_GO_Enrich/HF_vs_NF_G/HF_vs_NF_G.go_enrich.gene_set.bar_line.jpg"
            }, 
            "image_title": "GO富集分析柱状图（带折线））"
        }, 
        "image_8571": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/06_KEGG_Enrich/HF_vs_NF_G/HF_vs_NF_G.kegg_enrich.gene_set.bar_line.jpg"
            }, 
            "image_title": "KEGG富集分析柱形图（带折线））"
        }, 
        "image_9571": {
            "image_file": "workflow_results/07DiffExpress_G/all.diffexp_summary.bar2.jpg", 
            "image_title": "表达量差异统计图"
        }, 
        "image_9570": {
            "image_file": "workflow_results/07DiffExpress_G/all.diffexp_summary.bar.jpg", 
            "image_title": "表达量差异统计图"
        }, 
        "image_6147": {
            "image_file": {
                "NF1": "workflow_results/08SNP/NF1.snp.pos_stat.pie.jpg", 
                "NF2": "workflow_results/08SNP/NF2.snp.pos_stat.pie.jpg", 
                "NF3": "workflow_results/08SNP/NF3.snp.pos_stat.pie.jpg", 
                "HF1": "workflow_results/08SNP/HF1.snp.pos_stat.pie.jpg", 
                "HF2": "workflow_results/08SNP/HF2.snp.pos_stat.pie.jpg", 
                "HF3": "workflow_results/08SNP/HF3.snp.pos_stat.pie.jpg"
            }, 
            "image_title": "不同区域分布饼图"
        }, 
        "image_6089": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/01_Cluster_Analysis/HF_vs_NF_G/cluster.10.line.jpg"
            }, 
            "image_title": "子聚类趋势图"
        }, 
        "image_7659": {
            "image_file": {
                "HF_vs_NF": "workflow_results/07DiffExpress_G/HF_vs_NF.diffexp.scatter.jpg"
            }, 
            "image_title": "表达量差异散点图"
        }, 
        "image_6047": {
            "image_file": {
                "samples": "workflow_results/06Express/ExpAnnalysis/G_samples.exp_distribution.box.jpg", 
                "groups": "workflow_results/06Express/ExpAnnalysis/G_groups.exp_distribution.box.jpg"
            }, 
            "image_title": "表达量分布盒形图"
        }, 
        "image_6045": {
            "image_file": {
                "samples": "workflow_results/06Express/ExpAnnalysis/G_samples.exp_distribution.density.jpg", 
                "groups": "workflow_results/06Express/ExpAnnalysis/G_groups.exp_distribution.density.jpg"
            }, 
            "image_title": "表达量分布密度图"
        }, 
        "image_6139": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/06_KEGG_Enrich/HF_vs_NF_G/HF_vs_NF_G.kegg_enrich.gene_set.buble2.jpg"
            }, 
            "image_title": "KEGG富集分析气泡图（分散型）"
        }, 
        "image_6025": {
            "image_file": {
                "NF1": "workflow_results/03Align/QualityAssessment/NF1.align_pos_dist.pie.jpg", 
                "NF2": "workflow_results/03Align/QualityAssessment/NF2.align_pos_dist.pie.jpg", 
                "NF3": "workflow_results/03Align/QualityAssessment/NF3.align_pos_dist.pie.jpg", 
                "HF1": "workflow_results/03Align/QualityAssessment/HF1.align_pos_dist.pie.jpg", 
                "HF2": "workflow_results/03Align/QualityAssessment/HF2.align_pos_dist.pie.jpg", 
                "HF3": "workflow_results/03Align/QualityAssessment/HF3.align_pos_dist.pie.jpg"
            }, 
            "image_title": "Reads在参考基因组不同区域的分布饼状图"
        }, 
        "image_6123": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/05_GO_Enrich/HF_vs_NF_G/HF_vs_NF_G.go_enrich.gene_set.bar.jpg"
            }, 
            "image_title": "GO富集分析柱状图"
        }, 
        "image_6049": {
            "image_file": {
                "samples": "workflow_results/06Express/ExpAnnalysis/G_samples.exp_distribution.violin.jpg", 
                "groups": "workflow_results/06Express/ExpAnnalysis/G_groups.exp_distribution.violin.jpg"
            }, 
            "image_title": "表达量分布小提琴图"
        }, 
        "image_6125": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/05_GO_Enrich/HF_vs_NF_G/HF_vs_NF_G.go_enrich.gene_set.buble.jpg"
            }, 
            "image_title": "GO富集分析气泡图"
        }, 
        "image_6021": {
            "image_file": {
                "NF1": "workflow_results/03Align/QualityAssessment/NF1.align.satu.line.jpg", 
                "NF2": "workflow_results/03Align/QualityAssessment/NF2.align.satu.line.jpg", 
                "NF3": "workflow_results/03Align/QualityAssessment/NF3.align.satu.line.jpg", 
                "HF1": "workflow_results/03Align/QualityAssessment/HF1.align.satu.line.jpg", 
                "HF2": "workflow_results/03Align/QualityAssessment/HF2.align.satu.line.jpg", 
                "HF3": "workflow_results/03Align/QualityAssessment/HF3.align.satu.line.jpg"
            }, 
            "image_title": "测序饱和度曲线图"
        }, 
        "image_6127": {
            "image_file": {
                "HF_vs_NF": "workflow_results/10GeneSet/05_GO_Enrich/HF_vs_NF_G/HF_vs_NF_G.go_enrich.gene_set.buble2.jpg"
            }, 
            "image_title": "GO富集分析气泡图（分散型）"
        }, 
        "image_6023": {
            "image_file": {
                "NF1": "workflow_results/03Align/QualityAssessment/NF1.align_coverage.line.jpg", 
                "NF2": "workflow_results/03Align/QualityAssessment/NF2.align_coverage.line.jpg", 
                "NF3": "workflow_results/03Align/QualityAssessment/NF3.align_coverage.line.jpg", 
                "HF1": "workflow_results/03Align/QualityAssessment/HF1.align_coverage.line.jpg", 
                "HF2": "workflow_results/03Align/QualityAssessment/HF2.align_coverage.line.jpg", 
                "HF3": "workflow_results/03Align/QualityAssessment/HF3.align_coverage.line.jpg"
            }, 
            "image_title": "测序覆盖度分布图"
        }
    }, 
    "database_list": [
        {
            "software_database": "TransDecoder", 
            "source": "http://transdecoder.github.io/", 
            "version": "Version 5.5.0", 
            "usage": "多类数据库注释比较分析等"
        }, 
        {
            "software_database": "SeqPrep", 
            "source": "https://github.com/jstjohn/SeqPrep", 
            "version": "--", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "edgeR", 
            "source": "http://bioconductor.org/packages/stats/bioc/edgeR/", 
            "version": "Version 3.24.3", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "GATK", 
            "source": "https://software.broadinstitute.org/gatk/download/", 
            "version": "Version 3.8", 
            "usage": "SNP/Indel分析"
        }, 
        {
            "software_database": "WGCNA", 
            "source": "https://cran.r-project.org/web/packages/WGCNA/index.html", 
            "version": "Version 1.63", 
            "usage": "WGCNA分析"
        }, 
        {
            "software_database": "STRING 数据库", 
            "source": "https://string-db.org/", 
            "version": "v12.0", 
            "usage": "靶基因蛋白互作网络"
        }, 
        {
            "software_database": "sva", 
            "source": "http://www.bioconductor.org/packages/release/bioc/html/sva.html", 
            "version": "Version 3.20.0", 
            "usage": "移除批次效应影响"
        }, 
        {
            "software_database": "kallisto", 
            "source": "https://pachterlab.github.io/kallisto/download", 
            "version": "Version 0.46.2", 
            "usage": "表达量分析"
        }, 
        {
            "software_database": "PlantTFDB", 
            "source": "http://planttfdb.gao-lab.org/", 
            "version": "Version 5.0", 
            "usage": "转录因子预测"
        }, 
        {
            "software_database": "fastx_toolkit", 
            "source": "http://hannonlab.cshl.edu/fastx_toolkit/", 
            "version": "Version 0.0.14", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "NOISeq", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/NOISeq.html", 
            "version": "Version 2.18.0", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "Salmon", 
            "source": "https://github.com/COMBINE-lab/salmon", 
            "version": "Version 1.3.0", 
            "usage": "表达量分析"
        }, 
        {
            "software_database": "cufflinks", 
            "source": "http://cole-trapnell-lab.github.io/cufflinks/", 
            "version": "Version 2.2.1", 
            "usage": "转录本组装"
        }, 
        {
            "software_database": "Blast2go", 
            "source": "https://www.blast2go.com/", 
            "version": "Version 2.5", 
            "usage": "GO注释"
        }, 
        {
            "software_database": "STEM", 
            "source": "http://www.cs.cmu.edu/~jernst/stem/", 
            "version": "Version 1.3.11", 
            "usage": "时序表达趋势分析"
        }, 
        {
            "software_database": "MSigDB 数据库", 
            "source": "http://software.broadinstitute.org/gsea/downloads.jsp", 
            "version": "Version 6.2", 
            "usage": "GSEA分析"
        }, 
        {
            "software_database": "star_fusion", 
            "source": "https://github.com/STAR-Fusion/STAR-Fusion/wiki", 
            "version": "Version 1.8.1", 
            "usage": "基因融合鉴定"
        }, 
        {
            "software_database": "Sickle", 
            "source": "https://github.com/najoshi/sickle", 
            "version": "--", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "KOBAS", 
            "source": "http://kobas.cbi.pku.edu.cn/download.php", 
            "version": "Version 2.1.1", 
            "usage": "功能注释分类（KEGG）"
        }, 
        {
            "software_database": "GSEA", 
            "source": "http://software.broadinstitute.org/gsea/index.jsp", 
            "version": "Version 4.3.2", 
            "usage": "GSEA分析"
        }, 
        {
            "software_database": "Ipath 数据库", 
            "source": "https://pathways.embl.de/", 
            "version": "Version 3", 
            "usage": "iPath代谢通路分析"
        }, 
        {
            "software_database": "stringtie", 
            "source": "https://ccb.jhu.edu/software/stringtie/", 
            "version": "Version 2.1.2", 
            "usage": "转录本组装"
        }, 
        {
            "software_database": "fastp", 
            "source": "https://github.com/OpenGene/fastp", 
            "version": "0.19.5", 
            "usage": "测序数据质控"
        }, 
        {
            "software_database": "TopHat", 
            "source": "http://ccb.jhu.edu/software/tophat/index.shtml", 
            "version": "Version v2.1.1", 
            "usage": "序列比对分析"
        }, 
        {
            "software_database": "DEGSeq", 
            "source": "http://bioconductor.org/packages/stats/bioc/DEGSeq/", 
            "version": "Version 1.38.0", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "Bowtie2", 
            "source": "http://downloads.sourceforge.net/project/bowtie-bio/bowtie2/2.4.1", 
            "version": "Version 2.4.1", 
            "usage": "序列比对"
        }, 
        {
            "software_database": "Diamond", 
            "source": "https://github.com/bbuchfink/diamond", 
            "version": "Version 0.9.24", 
            "usage": "多类数据库注释比较分析等"
        }, 
        {
            "software_database": "RSEM", 
            "source": "http://deweylab.biostat.wisc.edu/rsem/", 
            "version": "Version 1.3.3", 
            "usage": "表达量分析"
        }, 
        {
            "software_database": "ASprofile", 
            "source": "http://ccb.jhu.edu/software/ASprofile/", 
            "version": "Version 1.0", 
            "usage": "可变剪切分析"
        }, 
        {
            "software_database": "hisat2", 
            "source": "http://ccb.jhu.edu/software/hisat2/index.shtml", 
            "version": "Version 2.1.0", 
            "usage": "序列比对分析"
        }, 
        {
            "software_database": "JASPAR", 
            "source": "https://jaspar2022.genereg.net/", 
            "version": "Version 2022", 
            "usage": "转录因子预测"
        }, 
        {
            "software_database": "samtools", 
            "source": "https://github.com/samtools/samtools.git ", 
            "version": "Version 1.9", 
            "usage": "SNP/Indel分析"
        }, 
        {
            "software_database": "Limma", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/limma.html", 
            "version": "Version 3.38.3", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "HMMER", 
            "source": "ftp://selab.janelia.org/pub/software/hmmer3/3.0/hmmer-3.0.tar.gz", 
            "version": "Version 3.2.1", 
            "usage": "功能注释"
        }, 
        {
            "software_database": "DESeq2", 
            "source": "http://bioconductor.org/packages/stats/bioc/DESeq2/", 
            "version": "Version 1.24.0", 
            "usage": "表达量差异分析"
        }, 
        {
            "software_database": "BLAST+", 
            "source": "ftp://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/2.9.0/", 
            "version": "Version 2.9.0", 
            "usage": "多类数据库注释比较分析等"
        }, 
        {
            "software_database": "bedtools", 
            "source": "https://bedtools.readthedocs.io/en/latest/", 
            "version": "Version 2.27.1", 
            "usage": "序列提取"
        }, 
        {
            "software_database": "goatools", 
            "source": "https://files.pythonhosted.org/packages/bb/7b/0c76e3511a79879606672e0741095a891dfb98cd63b1530ed8c51d406cda/goatools-0.8.9.tar.gz", 
            "version": "Version 0.6.5", 
            "usage": "基因集分析（GO富集）"
        }, 
        {
            "software_database": "maSigPro", 
            "source": "http://www.bioconductor.org/packages/release/bioc/html/maSigPro.html", 
            "version": "Version 1.56.0", 
            "usage": "时序差异聚类"
        }, 
        {
            "software_database": "AnimalTFDB", 
            "source": "http://bioinfo.life.hust.edu.cn/AnimalTFDB4/#/", 
            "version": "Version 4.0", 
            "usage": "转录因子预测"
        }, 
        {
            "software_database": "STAR", 
            "source": "http://code.google.com/p/rna-star/", 
            "version": "Version 2.7.1a", 
            "usage": "序列比对分析"
        }, 
        {
            "software_database": "Mfuzz", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
            "version": "Version 2.6.0", 
            "usage": "Mfuzz时序分析"
        }, 
        {
            "software_database": "Pfam 数据库", 
            "source": "http://pfam.xfam.org/", 
            "version": "Version 35.0", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "KEGG 数据库", 
            "source": "http://www.genome.jp/kegg/", 
            "version": "Version 2022.10", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "eggNOG 数据库", 
            "source": "http://eggnogdb.embl.de/#/app/home", 
            "version": "Version 2020.06", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "Rfam 数据库", 
            "source": "http://rfam.janelia.org/", 
            "version": "Version 14.8", 
            "usage": "核糖体比例评估"
        }, 
        {
            "software_database": "Swiss-prot 数据库", 
            "source": "ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz", 
            "version": "Version 2022.10", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "GO 数据库", 
            "source": "http://www.geneontology.org/", 
            "version": "Version 2022.0915", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "NR 数据库", 
            "source": "https://www.ncbi.nlm.nih.gov/public/", 
            "version": "Version 2022.10", 
            "usage": "基因注释"
        }, 
        {
            "software_database": "Mfuzz", 
            "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
            "version": "Version 2.6.0", 
            "usage": "Mfuzz时序分析"
        }
    ], 
    "genesets": [
        "HF_vs_NF_G"
    ], 
    "user_info": {
        "sale_mail": "yuanyuan.yue@majorbio.com", 
        "group_name": "韩雨哲老师", 
        "sale_phone": "18516656225", 
        "project_mail": "17685270905@163.com", 
        "project_type": "有参转录组结题报告", 
        "primer_info": "组织样品", 
        "group_phone": "17685270905", 
        "fx_id": 269196, 
        "group_mail": "17685270905@163.com", 
        "sale_name": "岳媛媛", 
        "project_delivery_ts": "Novaseq", 
        "end_ts": "0000-00-00", 
        "sale_id": 10847, 
        "created_by": "rna", 
        "tech_support_mail": "rna@majorbio.com", 
        "company_name": "大连海洋大学", 
        "contract_sn": "MJ20240129522", 
        "sequencing_platform": "Novaseq", 
        "tech_support_name": "顾义平", 
        "start_ts": "0000-00-00", 
        "update_ts": "2024-02-26 09:34:08", 
        "project_people": "陈毅", 
        "address": "辽宁省大连市", 
        "tech_support_phone": "021-20725055", 
        "contract_id": 252020, 
        "customer": "陈毅", 
        "is_default": 0, 
        "created_ts": "2024-02-26 09:34:08", 
        "is_deleted": 0, 
        "project_phone": "17685270905", 
        "project_contract_id": 215730, 
        "created_id": 8955, 
        "project_sn": "g55cneff7426msq2vphhepkni7", 
        "source_origin": "大菱鲆"
    }, 
    "samples": [
        "NF1", 
        "NF2", 
        "NF3", 
        "HF1", 
        "HF2", 
        "HF3"
    ], 
    "cmp_list": [
        [
            "HF", 
            "NF"
        ]
    ], 
    "table": {
        "table_5663": {
            "table_header": [
                {
                    "field": "Sample", 
                    "label": "Sample"
                }, 
                {
                    "field": "CDS", 
                    "label": "CDS"
                }, 
                {
                    "field": "5'UTR", 
                    "label": "5'UTR"
                }, 
                {
                    "field": "3'UTR", 
                    "label": "3'UTR"
                }, 
                {
                    "field": "Introns", 
                    "label": "Introns"
                }, 
                {
                    "field": "Intergenic", 
                    "label": "Intergenic"
                }
            ], 
            "table": [
                {
                    "Introns": "1617470.0(2.33%)", 
                    "Intergenic": "560922.0(0.81%)", 
                    "Sample": "HF1", 
                    "CDS": "48164110.0(69.5%)", 
                    "3'UTR": "14870637.0(21.46%)", 
                    "5'UTR": "4090089.0(5.9%)"
                }, 
                {
                    "Introns": "1620919.0(2.67%)", 
                    "Intergenic": "512908.0(0.84%)", 
                    "Sample": "HF2", 
                    "CDS": "41635225.0(68.51%)", 
                    "3'UTR": "13139515.0(21.62%)", 
                    "5'UTR": "3864708.0(6.36%)"
                }, 
                {
                    "Introns": "2296328.0(3.16%)", 
                    "Intergenic": "646439.0(0.89%)", 
                    "Sample": "HF3", 
                    "CDS": "48826508.0(67.18%)", 
                    "3'UTR": "16217499.0(22.31%)", 
                    "5'UTR": "4698140.0(6.46%)"
                }, 
                {
                    "Introns": "1807456.0(2.45%)", 
                    "Intergenic": "659855.0(0.9%)", 
                    "Sample": "NF1", 
                    "CDS": "49752572.0(67.48%)", 
                    "3'UTR": "16263030.0(22.06%)", 
                    "5'UTR": "5242021.0(7.11%)"
                }, 
                {
                    "Introns": "2794796.0(4.14%)", 
                    "Intergenic": "601725.0(0.89%)", 
                    "Sample": "NF2", 
                    "CDS": "45229944.0(67.08%)", 
                    "3'UTR": "14241343.0(21.12%)", 
                    "5'UTR": "4562861.0(6.77%)"
                }, 
                {
                    "Introns": "1617723.0(2.65%)", 
                    "Intergenic": "520953.0(0.85%)", 
                    "Sample": "NF3", 
                    "CDS": "41383220.0(67.74%)", 
                    "3'UTR": "13492672.0(22.09%)", 
                    "5'UTR": "4079649.0(6.68%)"
                }
            ]
        }, 
        "table_5523": {
            "table_header": [
                {
                    "field": "SAMPLE", 
                    "label": "SAMPLE"
                }, 
                {
                    "field": "A3SS", 
                    "label": "A3SS"
                }, 
                {
                    "field": "A5SS", 
                    "label": "A5SS"
                }, 
                {
                    "field": "MXE", 
                    "label": "MXE"
                }, 
                {
                    "field": "RI", 
                    "label": "RI"
                }, 
                {
                    "field": "SE", 
                    "label": "SE"
                }, 
                {
                    "field": "TOTAL", 
                    "label": "TOTAL"
                }
            ], 
            "table": [
                {
                    "TOTAL": 24864, 
                    "A5SS": 3153, 
                    "SAMPLE": "HF1", 
                    "SE": 13506, 
                    "MXE": 1527, 
                    "RI": 2186, 
                    "A3SS": 4492
                }, 
                {
                    "TOTAL": 24771, 
                    "A5SS": 3139, 
                    "SAMPLE": "HF3", 
                    "SE": 13415, 
                    "MXE": 1523, 
                    "RI": 2211, 
                    "A3SS": 4483
                }, 
                {
                    "TOTAL": 24498, 
                    "A5SS": 3122, 
                    "SAMPLE": "HF2", 
                    "SE": 13318, 
                    "MXE": 1509, 
                    "RI": 2135, 
                    "A3SS": 4414
                }, 
                {
                    "TOTAL": 21627, 
                    "A5SS": 2605, 
                    "SAMPLE": "NF3", 
                    "SE": 12141, 
                    "MXE": 1347, 
                    "RI": 1688, 
                    "A3SS": 3846
                }, 
                {
                    "TOTAL": 22219, 
                    "A5SS": 2714, 
                    "SAMPLE": "NF2", 
                    "SE": 12391, 
                    "MXE": 1366, 
                    "RI": 1782, 
                    "A3SS": 3966
                }, 
                {
                    "TOTAL": 22039, 
                    "A5SS": 2661, 
                    "SAMPLE": "NF1", 
                    "SE": 12334, 
                    "MXE": 1380, 
                    "RI": 1719, 
                    "A3SS": 3945
                }
            ]
        }, 
        "table_5755": {
            "table_header": [
                {
                    "field": "Num", 
                    "label": "Num"
                }, 
                {
                    "field": "Description", 
                    "label": "Description"
                }, 
                {
                    "field": "Database", 
                    "label": "Database"
                }, 
                {
                    "field": "pathway_id", 
                    "label": "pathway_id"
                }, 
                {
                    "field": "Ratio_in_study", 
                    "label": "Ratio_in_study"
                }, 
                {
                    "field": "Ratio_in_pop", 
                    "label": "Ratio_in_pop"
                }, 
                {
                    "field": "P-Value", 
                    "label": "P-Value"
                }, 
                {
                    "field": "Corrected P-Value", 
                    "label": "Corrected P-Value"
                }, 
                {
                    "field": "Genes", 
                    "label": "Genes"
                }, 
                {
                    "field": "typeII", 
                    "label": "typeII"
                }, 
                {
                    "field": "typeI", 
                    "label": "typeI"
                }
            ], 
            "table": [
                {
                    "pathway_id": "map04972", 
                    "P-Value": 1.61562025784e-05, 
                    "Corrected P-Value": 0.00407136304975, 
                    "Description": "Pancreatic secretion", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-atp1b2b|gene-LOC118301998|gene-LOC118313215|gene-LOC118317479|gene-atp2b3b|gene-LOC118303251|gene-LOC118314424|gene-LOC118313152|gene-ela3l|gene-LOC118284976", 
                    "typeII": "Digestive system", 
                    "Ratio_in_study": "10/205", 
                    "Num": 10, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "168/18790"
                }, 
                {
                    "pathway_id": "map00900", 
                    "P-Value": 0.000145413524739, 
                    "Corrected P-Value": 0.012214736078000001, 
                    "Description": "Terpenoid backbone biosynthesis", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-hmgcs1|gene-hmgcra|gene-fdps|gene-acat2", 
                    "typeII": "Metabolism of terpenoids and polyketides", 
                    "Ratio_in_study": "4/205", 
                    "Num": 4, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "25/18790"
                }, 
                {
                    "pathway_id": "map00100", 
                    "P-Value": 0.000198324673301, 
                    "Corrected P-Value": 0.012494454417900001, 
                    "Description": "Steroid biosynthesis", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-tm7sf2|gene-LOC118291669|gene-LOC118316714|gene-hsd17b7", 
                    "typeII": "Lipid metabolism", 
                    "Ratio_in_study": "4/205", 
                    "Num": 4, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "27/18790"
                }, 
                {
                    "pathway_id": "map04974", 
                    "P-Value": 0.00011149112836599999, 
                    "Corrected P-Value": 0.014047882174200001, 
                    "Description": "Protein digestion and absorption", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-atp1b2b|gene-LOC118301998|gene-LOC118313215|gene-LOC118317479|gene-LOC118303251|gene-LOC118314424|gene-LOC118313152|gene-ela3l|gene-slc7a9", 
                    "typeII": "Digestive system", 
                    "Ratio_in_study": "9/205", 
                    "Num": 9, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "171/18790"
                }, 
                {
                    "pathway_id": "map00280", 
                    "P-Value": 0.00042182634021599994, 
                    "Corrected P-Value": 0.0212600475469, 
                    "Description": "Valine, leucine and isoleucine degradation", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-agxt2|gene-acat2|gene-hmgcs1|gene-aacs|gene-il4i1", 
                    "typeII": "Amino acid metabolism", 
                    "Ratio_in_study": "5/205", 
                    "Num": 5, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "58/18790"
                }, 
                {
                    "pathway_id": "map04913", 
                    "P-Value": 0.0008788340154039999, 
                    "Corrected P-Value": 0.036911028647, 
                    "Description": "Ovarian steroidogenesis", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC118284036|gene-hsd17b1|gene-LOC118283412|gene-hsd17b7|gene-LOC118289297", 
                    "typeII": "Endocrine system", 
                    "Ratio_in_study": "5/205", 
                    "Num": 5, 
                    "typeI": "Organismal Systems", 
                    "Ratio_in_pop": "68/18790"
                }, 
                {
                    "pathway_id": "map00260", 
                    "P-Value": 0.0024738447328600003, 
                    "Corrected P-Value": 0.07792610908520001, 
                    "Description": "Glycine, serine and threonine metabolism", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-agxt2|gene-gatm|gene-gamt|gene-LOC118316584", 
                    "typeII": "Amino acid metabolism", 
                    "Ratio_in_study": "4/205", 
                    "Num": 4, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "52/18790"
                }, 
                {
                    "pathway_id": "map00650", 
                    "P-Value": 0.00246575381488, 
                    "Corrected P-Value": 0.08876713733560002, 
                    "Description": "Butanoate metabolism", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-hmgcs1|gene-aacs|gene-acat2", 
                    "typeII": "Carbohydrate metabolism", 
                    "Ratio_in_study": "3/205", 
                    "Num": 3, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "25/18790"
                }, 
                {
                    "pathway_id": "map00592", 
                    "P-Value": 0.00418198943677, 
                    "Corrected P-Value": 0.105386133807, 
                    "Description": "alpha-Linolenic acid metabolism", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-LOC118284976|gene-LOC118289297|gene-LOC118314794", 
                    "typeII": "Lipid metabolism", 
                    "Ratio_in_study": "3/205", 
                    "Num": 3, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "30/18790"
                }, 
                {
                    "pathway_id": "map00330", 
                    "P-Value": 0.0039200331831399995, 
                    "Corrected P-Value": 0.10976092912799999, 
                    "Description": "Arginine and proline metabolism", 
                    "Database": "KEGG PATHWAY", 
                    "Genes": "gene-nos1|gene-gatm|gene-prodhb|gene-gamt", 
                    "typeII": "Amino acid metabolism", 
                    "Ratio_in_study": "4/205", 
                    "Num": 4, 
                    "typeI": "Metabolism", 
                    "Ratio_in_pop": "59/18790"
                }
            ]
        }, 
        "table_5665": {
            "table_header": [
                {
                    "field": "Chromosome", 
                    "label": "Chromosome"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": 1027396, 
                    "HF3": 872534, 
                    "HF2": 962140, 
                    "NF3": 708572, 
                    "NF2": 765493, 
                    "NF1": 746731, 
                    "Chromosome": "NC_013183.1"
                }, 
                {
                    "HF1": 3235876, 
                    "HF3": 3271127, 
                    "HF2": 2660574, 
                    "NF3": 2731296, 
                    "NF2": 2964794, 
                    "NF1": 3244362, 
                    "Chromosome": "NC_061515.1"
                }, 
                {
                    "HF1": 2420712, 
                    "HF3": 2796253, 
                    "HF2": 2246195, 
                    "NF3": 2220827, 
                    "NF2": 2508462, 
                    "NF1": 2739243, 
                    "Chromosome": "NC_061516.1"
                }, 
                {
                    "HF1": 3027599, 
                    "HF3": 3548762, 
                    "HF2": 2675905, 
                    "NF3": 2618155, 
                    "NF2": 2752363, 
                    "NF1": 3063069, 
                    "Chromosome": "NC_061517.1"
                }, 
                {
                    "HF1": 1887409, 
                    "HF3": 2025481, 
                    "HF2": 1636700, 
                    "NF3": 1752030, 
                    "NF2": 1876807, 
                    "NF1": 2208105, 
                    "Chromosome": "NC_061518.1"
                }, 
                {
                    "HF1": 2326988, 
                    "HF3": 2449241, 
                    "HF2": 1961922, 
                    "NF3": 2003842, 
                    "NF2": 2286700, 
                    "NF1": 2435939, 
                    "Chromosome": "NC_061519.1"
                }, 
                {
                    "HF1": 2643220, 
                    "HF3": 2428288, 
                    "HF2": 1983695, 
                    "NF3": 2026266, 
                    "NF2": 2283559, 
                    "NF1": 2497012, 
                    "Chromosome": "NC_061520.1"
                }, 
                {
                    "HF1": 1833325, 
                    "HF3": 1689252, 
                    "HF2": 1369734, 
                    "NF3": 1415085, 
                    "NF2": 1625331, 
                    "NF1": 1666472, 
                    "Chromosome": "NC_061521.1"
                }, 
                {
                    "HF1": 2414570, 
                    "HF3": 2520499, 
                    "HF2": 1945522, 
                    "NF3": 2120245, 
                    "NF2": 2487897, 
                    "NF1": 2729778, 
                    "Chromosome": "NC_061522.1"
                }, 
                {
                    "HF1": 1927003, 
                    "HF3": 2047646, 
                    "HF2": 1683718, 
                    "NF3": 1707831, 
                    "NF2": 1875108, 
                    "NF1": 2058816, 
                    "Chromosome": "NC_061523.1"
                }, 
                {
                    "HF1": 1677157, 
                    "HF3": 2028082, 
                    "HF2": 1575484, 
                    "NF3": 1664394, 
                    "NF2": 1892617, 
                    "NF1": 2015013, 
                    "Chromosome": "NC_061524.1"
                }, 
                {
                    "HF1": 3341808, 
                    "HF3": 3614501, 
                    "HF2": 2875231, 
                    "NF3": 3128365, 
                    "NF2": 3004815, 
                    "NF1": 3880732, 
                    "Chromosome": "NC_061525.1"
                }, 
                {
                    "HF1": 2532712, 
                    "HF3": 2793621, 
                    "HF2": 2299328, 
                    "NF3": 2757752, 
                    "NF2": 2962272, 
                    "NF1": 3078131, 
                    "Chromosome": "NC_061526.1"
                }, 
                {
                    "HF1": 1666351, 
                    "HF3": 1912789, 
                    "HF2": 1506851, 
                    "NF3": 1563753, 
                    "NF2": 1984570, 
                    "NF1": 1904647, 
                    "Chromosome": "NC_061527.1"
                }, 
                {
                    "HF1": 1492138, 
                    "HF3": 1524917, 
                    "HF2": 1213719, 
                    "NF3": 1252615, 
                    "NF2": 1534090, 
                    "NF1": 1489163, 
                    "Chromosome": "NC_061528.1"
                }, 
                {
                    "HF1": 1557199, 
                    "HF3": 1685623, 
                    "HF2": 1326531, 
                    "NF3": 1345435, 
                    "NF2": 1582691, 
                    "NF1": 1636752, 
                    "Chromosome": "NC_061529.1"
                }, 
                {
                    "HF1": 2289881, 
                    "HF3": 2712150, 
                    "HF2": 2940693, 
                    "NF3": 2324999, 
                    "NF2": 2220612, 
                    "NF1": 2778482, 
                    "Chromosome": "NC_061530.1"
                }, 
                {
                    "HF1": 3289660, 
                    "HF3": 3215286, 
                    "HF2": 3003978, 
                    "NF3": 2692627, 
                    "NF2": 2953956, 
                    "NF1": 3215814, 
                    "Chromosome": "NC_061531.1"
                }, 
                {
                    "HF1": 1332417, 
                    "HF3": 1564898, 
                    "HF2": 1270102, 
                    "NF3": 1244046, 
                    "NF2": 1473130, 
                    "NF1": 1499104, 
                    "Chromosome": "NC_061532.1"
                }, 
                {
                    "HF1": 1334889, 
                    "HF3": 1516979, 
                    "HF2": 1246933, 
                    "NF3": 1270933, 
                    "NF2": 1508822, 
                    "NF1": 1515077, 
                    "Chromosome": "NC_061533.1"
                }, 
                {
                    "HF1": 1415809, 
                    "HF3": 1509798, 
                    "HF2": 1306521, 
                    "NF3": 1329495, 
                    "NF2": 1448382, 
                    "NF1": 1523027, 
                    "Chromosome": "NC_061534.1"
                }, 
                {
                    "HF1": 867280, 
                    "HF3": 953972, 
                    "HF2": 780404, 
                    "NF3": 787069, 
                    "NF2": 923407, 
                    "NF1": 928708, 
                    "Chromosome": "NC_061535.1"
                }, 
                {
                    "HF1": 2751407, 
                    "HF3": 3329072, 
                    "HF2": 2623639, 
                    "NF3": 2701757, 
                    "NF2": 3135912, 
                    "NF1": 3508348, 
                    "Chromosome": "NC_061536.1"
                }, 
                {
                    "HF1": 9180, 
                    "HF3": 6952, 
                    "HF2": 1374, 
                    "NF3": 2016, 
                    "NF2": 16879, 
                    "NF1": 4077, 
                    "Chromosome": "NW_025917010.1"
                }, 
                {
                    "HF1": 13556, 
                    "HF3": 18765, 
                    "HF2": 14959, 
                    "NF3": 16891, 
                    "NF2": 21758, 
                    "NF1": 24410, 
                    "Chromosome": "NW_025917011.1"
                }, 
                {
                    "HF1": 1039, 
                    "HF3": 530, 
                    "HF2": 170, 
                    "NF3": 565, 
                    "NF2": 1569, 
                    "NF1": 569, 
                    "Chromosome": "NW_025917012.1"
                }, 
                {
                    "HF1": 0, 
                    "HF3": 117, 
                    "HF2": 0, 
                    "NF3": 0, 
                    "NF2": 110, 
                    "NF1": 27, 
                    "Chromosome": "NW_025917013.1"
                }
            ]
        }, 
        "table_5685": {
            "table_header": [
                {
                    "field": "sample", 
                    "label": "sample"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": 1.0, 
                    "HF3": 0.829983164148, 
                    "HF2": 0.596007694527, 
                    "sample": "HF1", 
                    "NF3": 0.8629238735250001, 
                    "NF2": 0.8799489775489999, 
                    "NF1": 0.800553342414
                }, 
                {
                    "HF1": 0.596007694527, 
                    "HF3": 0.8577341944329999, 
                    "HF2": 1.0, 
                    "sample": "HF2", 
                    "NF3": 0.839118252095, 
                    "NF2": 0.7936867989990001, 
                    "NF1": 0.909309879891
                }, 
                {
                    "HF1": 0.829983164148, 
                    "HF3": 1.0, 
                    "HF2": 0.8577341944329999, 
                    "sample": "HF3", 
                    "NF3": 0.9723701459370001, 
                    "NF2": 0.951310020692, 
                    "NF1": 0.9617554595550001
                }, 
                {
                    "HF1": 0.800553342414, 
                    "HF3": 0.9617554595550001, 
                    "HF2": 0.909309879891, 
                    "sample": "NF1", 
                    "NF3": 0.974741233628, 
                    "NF2": 0.954164363625, 
                    "NF1": 1.0
                }, 
                {
                    "HF1": 0.8799489775489999, 
                    "HF3": 0.951310020692, 
                    "HF2": 0.7936867989990001, 
                    "sample": "NF2", 
                    "NF3": 0.973060798832, 
                    "NF2": 1.0, 
                    "NF1": 0.954164363625
                }, 
                {
                    "HF1": 0.8629238735250001, 
                    "HF3": 0.9723701459370001, 
                    "HF2": 0.839118252095, 
                    "sample": "NF3", 
                    "NF3": 1.0, 
                    "NF2": 0.973060798832, 
                    "NF1": 0.974741233628
                }
            ]
        }, 
        "table_5687": {
            "table_header": [
                {
                    "field": "PC", 
                    "label": "PC"
                }, 
                {
                    "field": "Proportion of Variance", 
                    "label": "Proportion of Variance"
                }
            ], 
            "table": [
                {
                    "PC": "PC1", 
                    "Proportion of Variance": 0.41054156256700003
                }, 
                {
                    "PC": "PC2", 
                    "Proportion of Variance": 0.224033069567
                }, 
                {
                    "PC": "PC3", 
                    "Proportion of Variance": 0.136215721789
                }, 
                {
                    "PC": "PC4", 
                    "Proportion of Variance": 0.123327563055
                }, 
                {
                    "PC": "PC5", 
                    "Proportion of Variance": 0.105882083022
                }
            ]
        }, 
        "table_5719": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": -1.03378668299, 
                    "HF3": -0.965160469515, 
                    "HF2": -0.912994082096, 
                    "NF3": 0.49507574006800004, 
                    "NF2": 1.2238075719900001, 
                    "NF1": 1.19305792254, 
                    "Gene id": "gene-LOC118284682"
                }, 
                {
                    "HF1": -0.8966812035289999, 
                    "HF3": -1.06124242254, 
                    "HF2": -0.9211411559430001, 
                    "NF3": 0.779831249292, 
                    "NF2": 0.597013838385, 
                    "NF1": 1.50221969434, 
                    "Gene id": "gene-nos1"
                }, 
                {
                    "HF1": -1.43815919333, 
                    "HF3": -0.427905311753, 
                    "HF2": -0.925694587797, 
                    "NF3": 0.816845976847, 
                    "NF2": 1.3577985966100001, 
                    "NF1": 0.617114519421, 
                    "Gene id": "gene-LOC118284036"
                }, 
                {
                    "HF1": -0.7774856261900001, 
                    "HF3": -0.9038982736810001, 
                    "HF2": -1.05605220659, 
                    "NF3": 1.56248958257, 
                    "NF2": 0.9946675560070001, 
                    "NF1": 0.180278967881, 
                    "Gene id": "gene-LOC118313990"
                }, 
                {
                    "HF1": -1.62221734351, 
                    "HF3": -0.538868740274, 
                    "HF2": -0.650977753009, 
                    "NF3": 0.891522014666, 
                    "NF2": 0.8730717472700001, 
                    "NF1": 1.04747007486, 
                    "Gene id": "gene-LOC118302248"
                }, 
                {
                    "HF1": -1.20069730459, 
                    "HF3": -0.344163791877, 
                    "HF2": -1.2874190819700002, 
                    "NF3": 0.9461560614899999, 
                    "NF2": 0.7101608030490001, 
                    "NF1": 1.17596331389, 
                    "Gene id": "gene-LOC118289297"
                }, 
                {
                    "HF1": -1.11289196326, 
                    "HF3": -0.415866351854, 
                    "HF2": -1.29001045639, 
                    "NF3": 1.23172652969, 
                    "NF2": 1.06545667883, 
                    "NF1": 0.521585562987, 
                    "Gene id": "gene-hmgcra"
                }, 
                {
                    "HF1": -1.14010525937, 
                    "HF3": -0.258182505504, 
                    "HF2": -1.3786200556600001, 
                    "NF3": 0.966981982245, 
                    "NF2": 1.18775136438, 
                    "NF1": 0.622174473907, 
                    "Gene id": "gene-LOC118318042"
                }, 
                {
                    "HF1": -0.969653160794, 
                    "HF3": -0.442246710195, 
                    "HF2": -1.33731267545, 
                    "NF3": 1.03000445801, 
                    "NF2": 1.37779223107, 
                    "NF1": 0.341415857356, 
                    "Gene id": "gene-hmgcs1"
                }, 
                {
                    "HF1": -1.24922300965, 
                    "HF3": -0.201768072095, 
                    "HF2": -1.32450425818, 
                    "NF3": 0.717187773319, 
                    "NF2": 0.9525161106450001, 
                    "NF1": 1.10579145596, 
                    "Gene id": "gene-gmds"
                }
            ]
        }, 
        "table_9813": {
            "table_header": [
                {
                    "field": "AS type", 
                    "label": "AS type"
                }, 
                {
                    "field": "Exclusion (Increase exclusion in case，ΔPSI<0)", 
                    "label": "Exclusion (Increase exclusion in case，ΔPSI<0)"
                }, 
                {
                    "field": "Inclusion (Increase inclusion in case, ΔPSI>0)", 
                    "label": "Inclusion (Increase inclusion in case, ΔPSI>0)"
                }, 
                {
                    "field": "Total events", 
                    "label": "Total events"
                }
            ], 
            "table": [
                {
                    "Total events": 327, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 181, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 146, 
                    "AS type": "SE"
                }, 
                {
                    "Total events": 140, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 56, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 84, 
                    "AS type": "MXE"
                }, 
                {
                    "Total events": 240, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 136, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 104, 
                    "AS type": "A3SS"
                }, 
                {
                    "Total events": 184, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 103, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 81, 
                    "AS type": "A5SS"
                }, 
                {
                    "Total events": 162, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 87, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 75, 
                    "AS type": "RI"
                }, 
                {
                    "Total events": 1053, 
                    "Inclusion (Increase inclusion in case, ΔPSI>0)": 563, 
                    "Exclusion (Increase exclusion in case，ΔPSI<0)": 490, 
                    "AS type": "TOTAL"
                }
            ]
        }, 
        "table_9812": {
            "table_header": [
                {
                    "field": "AS type", 
                    "label": "AS type"
                }, 
                {
                    "field": "JunctionCountOnly(JC)", 
                    "label": "JunctionCountOnly(JC)"
                }, 
                {
                    "field": "ReadsOnTargetAndJunctionCounts(JCEC)", 
                    "label": "ReadsOnTargetAndJunctionCounts(JCEC)"
                }, 
                {
                    "field": "JC&JCEC", 
                    "label": "JC&JCEC"
                }, 
                {
                    "field": "JC|JCEC", 
                    "label": "JC|JCEC"
                }
            ], 
            "table": [
                {
                    "JunctionCountOnly(JC)": 327, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 339, 
                    "JC&JCEC": 320, 
                    "JC|JCEC": 346, 
                    "AS type": "SE"
                }, 
                {
                    "JunctionCountOnly(JC)": 140, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 144, 
                    "JC&JCEC": 139, 
                    "JC|JCEC": 145, 
                    "AS type": "MXE"
                }, 
                {
                    "JunctionCountOnly(JC)": 240, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 241, 
                    "JC&JCEC": 231, 
                    "JC|JCEC": 250, 
                    "AS type": "A3SS"
                }, 
                {
                    "JunctionCountOnly(JC)": 184, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 185, 
                    "JC&JCEC": 179, 
                    "JC|JCEC": 190, 
                    "AS type": "A5SS"
                }, 
                {
                    "JunctionCountOnly(JC)": 162, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 159, 
                    "JC&JCEC": 151, 
                    "JC|JCEC": 170, 
                    "AS type": "RI"
                }, 
                {
                    "JunctionCountOnly(JC)": 1053, 
                    "ReadsOnTargetAndJunctionCounts(JCEC)": 1068, 
                    "JC&JCEC": 1020, 
                    "JC|JCEC": 1101, 
                    "AS type": "TOTAL"
                }
            ]
        }, 
        "table_5677": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "Gene name", 
                    "label": "Gene name"
                }, 
                {
                    "field": "Gene description", 
                    "label": "Gene description"
                }, 
                {
                    "field": "length", 
                    "label": "length"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }, 
                {
                    "field": "HF", 
                    "label": "HF"
                }, 
                {
                    "field": "NF", 
                    "label": "NF"
                }, 
                {
                    "field": "nr", 
                    "label": "nr"
                }, 
                {
                    "field": "go", 
                    "label": "go"
                }, 
                {
                    "field": "KO_id", 
                    "label": "KO_id"
                }, 
                {
                    "field": "KO_name", 
                    "label": "KO_name"
                }, 
                {
                    "field": "paths", 
                    "label": "paths"
                }, 
                {
                    "field": "cog", 
                    "label": "cog"
                }, 
                {
                    "field": "cog_description", 
                    "label": "cog_description"
                }, 
                {
                    "field": "pfam", 
                    "label": "pfam"
                }, 
                {
                    "field": "swissprot", 
                    "label": "swissprot"
                }, 
                {
                    "field": "entrez", 
                    "label": "entrez"
                }
            ], 
            "table": [
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "GO:0016021(cellular_component:integral component of membrane)", 
                    "HF": 787.0, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 1139.6667, 
                    "swissprot": "", 
                    "NF3": 972.0, 
                    "NF2": 1159.0, 
                    "NF1": 1288.0, 
                    "nr": "AWO98999.1(Hypothetical protein SMAX5B_013391 [Scophthalmus maximus])", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 551.0, 
                    "HF3": 1029.0, 
                    "HF2": 781.0, 
                    "length": 1789, 
                    "cog": "", 
                    "Gene id": "MSTRG.10008"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 14.3333, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 1.3333, 
                    "swissprot": "", 
                    "NF3": 1.0, 
                    "NF2": 2.0, 
                    "NF1": 1.0, 
                    "nr": "KAF0022028.1(hypothetical protein F2P81_025720 [Scophthalmus maximus])", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 34.0, 
                    "HF3": 2.0, 
                    "HF2": 7.0, 
                    "length": 769, 
                    "cog": "", 
                    "Gene id": "MSTRG.10011"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 9.1267, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 9.8033, 
                    "swissprot": "", 
                    "NF3": 5.0, 
                    "NF2": 19.41, 
                    "NF1": 5.0, 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 11.22, 
                    "HF3": 6.11, 
                    "HF2": 10.05, 
                    "length": 471, 
                    "cog": "", 
                    "Gene id": "MSTRG.10362"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 3.6667, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 4.6667, 
                    "swissprot": "", 
                    "NF3": 8.0, 
                    "NF2": 0.0, 
                    "NF1": 6.0, 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 10.0, 
                    "HF3": 1.0, 
                    "HF2": 0.0, 
                    "length": 430, 
                    "cog": "", 
                    "Gene id": "MSTRG.10390"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 1.08, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 0.3867, 
                    "swissprot": "", 
                    "NF3": 1.16, 
                    "NF2": 0.0, 
                    "NF1": 0.0, 
                    "nr": "XP_047192259.1(mucin-2-like [Scophthalmus maximus])", 
                    "entrez": "", 
                    "pfam": "PF01390.23(SEA:SEA domain)", 
                    "HF1": 0.0, 
                    "HF3": 3.24, 
                    "HF2": 0.0, 
                    "length": 257, 
                    "cog": "", 
                    "Gene id": "MSTRG.10472"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 1.0, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 2.3533, 
                    "swissprot": "", 
                    "NF3": 1.06, 
                    "NF2": 0.0, 
                    "NF1": 6.0, 
                    "nr": "XP_047192259.1(mucin-2-like [Scophthalmus maximus])", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 1.0, 
                    "HF3": 2.0, 
                    "HF2": 0.0, 
                    "length": 338, 
                    "cog": "", 
                    "Gene id": "MSTRG.10473"
                }, 
                {
                    "cog_description": "ENOG4110SSA(-)", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 27.84, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 46.2, 
                    "swissprot": "", 
                    "NF3": 16.0, 
                    "NF2": 59.31, 
                    "NF1": 63.29, 
                    "nr": "XP_047192259.1(mucin-2-like [Scophthalmus maximus])", 
                    "entrez": "", 
                    "pfam": "PF01390.23(SEA:SEA domain)", 
                    "HF1": 13.0, 
                    "HF3": 57.22, 
                    "HF2": 13.3, 
                    "length": 1439, 
                    "cog": "ENOG4110SSA(S:Function unknown)", 
                    "Gene id": "MSTRG.10474"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 1074.3333, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 1598.0, 
                    "swissprot": "", 
                    "NF3": 2322.0, 
                    "NF2": 1162.0, 
                    "NF1": 1310.0, 
                    "nr": "XP_028461914.1(uncharacterized protein LOC114573901 isoform X2 [Perca flavescens])", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 696.0, 
                    "HF3": 1631.0, 
                    "HF2": 896.0, 
                    "length": 774, 
                    "cog": "", 
                    "Gene id": "MSTRG.10488"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 4.6667, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 10.0, 
                    "swissprot": "", 
                    "NF3": 16.0, 
                    "NF2": 0.0, 
                    "NF1": 14.0, 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 12.0, 
                    "HF3": 0.0, 
                    "HF2": 2.0, 
                    "length": 378, 
                    "cog": "", 
                    "Gene id": "MSTRG.10530"
                }, 
                {
                    "cog_description": "", 
                    "Gene description": "", 
                    "Gene name": "", 
                    "go": "", 
                    "HF": 1.3333, 
                    "KO_name": "", 
                    "paths": "", 
                    "KO_id": "", 
                    "NF": 7.0, 
                    "swissprot": "", 
                    "NF3": 2.0, 
                    "NF2": 18.0, 
                    "NF1": 1.0, 
                    "nr": "", 
                    "entrez": "", 
                    "pfam": "", 
                    "HF1": 2.0, 
                    "HF3": 1.0, 
                    "HF2": 1.0, 
                    "length": 312, 
                    "cog": "", 
                    "Gene id": "MSTRG.1060"
                }
            ]
        }, 
        "table_8221": {
            "table_header": [
                {
                    "field": "Gene ID", 
                    "label": "Gene ID"
                }, 
                {
                    "field": "Gene Name", 
                    "label": "Gene Name"
                }, 
                {
                    "field": "Gene Description", 
                    "label": "Gene Description"
                }, 
                {
                    "field": "GO_id", 
                    "label": "GO_id"
                }, 
                {
                    "field": "GO_term", 
                    "label": "GO_term"
                }, 
                {
                    "field": "Go_description", 
                    "label": "Go_description"
                }, 
                {
                    "field": "KO_id", 
                    "label": "KO_id"
                }, 
                {
                    "field": "KO_name", 
                    "label": "KO_name"
                }, 
                {
                    "field": "Pathway_id", 
                    "label": "Pathway_id"
                }, 
                {
                    "field": "Pathway_definition", 
                    "label": "Pathway_definition"
                }, 
                {
                    "field": "EggNOG_id", 
                    "label": "EggNOG_id"
                }, 
                {
                    "field": "EggNOG_Functional_Categories", 
                    "label": "EggNOG_Functional_Categories"
                }, 
                {
                    "field": "NR_hit-name", 
                    "label": "NR_hit-name"
                }, 
                {
                    "field": "NR_description", 
                    "label": "NR_description"
                }, 
                {
                    "field": "Swiss-Prot_hit-name", 
                    "label": "Swiss-Prot_hit-name"
                }, 
                {
                    "field": "Swiss-Prot_description", 
                    "label": "Swiss-Prot_description"
                }, 
                {
                    "field": "Pfam_id", 
                    "label": "Pfam_id"
                }, 
                {
                    "field": "Domain", 
                    "label": "Domain"
                }, 
                {
                    "field": "Domain_description", 
                    "label": "Domain_description"
                }
            ], 
            "table": [
                {
                    "Pathway_id": "", 
                    "Domain": "Pkinase;PK_Tyr_Ser-Thr;Pkinase_fungal", 
                    "KO_id": "", 
                    "EggNOG_id": "ENOG410YA63", 
                    "Pathway_definition": "", 
                    "Gene Description": "serine_threonine-protein kinase Nek8, transcript variant X8", 
                    "Pfam_id": "PF00069.28;PF07714.20;PF17667.4", 
                    "GO_term": "", 
                    "Domain_description": "Protein kinase domain;Protein tyrosine and serine/threonine kinase;Fungal protein kinase", 
                    "NR_description": "serine/threonine-protein kinase Nek8 [Scophthalmus maximus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "Serine/threonine-protein kinase Nek8 OS=Danio rerio OX=7955 GN=nek8 PE=2 SV=1", 
                    "Go_description": "", 
                    "Gene Name": "zmp_0000000881", 
                    "EggNOG_Functional_Categories": "T:Signal transduction mechanisms", 
                    "NR_hit-name": "XP_035499186.2", 
                    "Gene ID": "gene-zmp_0000000881", 
                    "Swiss-Prot_hit-name": "sp|Q90XC2|NEK8_DANRE", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "", 
                    "KO_id": "K06549;K06749", 
                    "EggNOG_id": "ENOG410YUKT", 
                    "Pathway_definition": "", 
                    "Gene Description": "uncharacterized LOC118299272, transcript variant X1", 
                    "Pfam_id": "", 
                    "GO_term": "", 
                    "Domain_description": "", 
                    "NR_description": "uncharacterized protein LOC118299272 [Scophthalmus maximus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "", 
                    "Go_description": "", 
                    "Gene Name": "LOC118299272", 
                    "EggNOG_Functional_Categories": "S:Function unknown", 
                    "NR_hit-name": "XP_035478752.2", 
                    "Gene ID": "gene-LOC118299272", 
                    "Swiss-Prot_hit-name": "", 
                    "KO_name": "SIGLEC5, CD170;SIGLEC10"
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "SAGA-Tad1", 
                    "KO_id": "K11317", 
                    "EggNOG_id": "ENOG4111F9I", 
                    "Pathway_definition": "", 
                    "Gene Description": "transcriptional adaptor 1", 
                    "Pfam_id": "PF12767.10", 
                    "GO_term": "cellular_component", 
                    "Domain_description": "Transcriptional regulator of RNA polII, SAGA, subunit", 
                    "NR_description": "transcriptional adapter 1 [Scophthalmus maximus]", 
                    "GO_id": "GO:0070461", 
                    "Swiss-Prot_description": "Transcriptional adapter 1 OS=Danio rerio OX=7955 GN=tada1 PE=2 SV=1", 
                    "Go_description": "CC:SAGA-type complex", 
                    "Gene Name": "tada1", 
                    "EggNOG_Functional_Categories": "K:Transcription", 
                    "NR_hit-name": "XP_035489925.1", 
                    "Gene ID": "gene-tada1", 
                    "Swiss-Prot_hit-name": "sp|Q6NWA8|TADA1_DANRE", 
                    "KO_name": "TADA1, STAF42"
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "HMG_box;HMG_box_5;HMG_box_2", 
                    "KO_id": "K09273", 
                    "EggNOG_id": "COG5648", 
                    "Pathway_definition": "", 
                    "Gene Description": "upstream binding transcription factor, transcript variant X2", 
                    "Pfam_id": "PF00505.22;PF14887.9;PF09011.13", 
                    "GO_term": "cellular_component;biological_process;cellular_component;molecular_function;cellular_component;molecular_function;molecular_function;biological_process", 
                    "Domain_description": "HMG (high mobility group) box;HMG (high mobility group) box 5;HMG-box domain", 
                    "NR_description": "nucleolar transcription factor 1 isoform X2 [Scophthalmus maximus]", 
                    "GO_id": "GO:0000124;GO:0006325;GO:0005634;GO:0003713;GO:0071819;GO:0008270;GO:0003677;GO:0016578", 
                    "Swiss-Prot_description": "Nucleolar transcription factor 1 OS=Rattus norvegicus OX=10116 GN=Ubtf PE=1 SV=1", 
                    "Go_description": "CC:SAGA complex;BP:chromatin organization;CC:nucleus;MF:transcription coactivator activity;CC:DUBm complex;MF:zinc ion binding;MF:DNA binding;BP:histone deubiquitination", 
                    "Gene Name": "ubtf", 
                    "EggNOG_Functional_Categories": "B:Chromatin structure and dynamics", 
                    "NR_hit-name": "XP_047184055.1", 
                    "Gene ID": "gene-ubtf", 
                    "Swiss-Prot_hit-name": "sp|P25977|UBF1_RAT", 
                    "KO_name": "UBTF"
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "zf-H2C2_2;zf-C2H2;zf-C2H2_4;PilZ", 
                    "KO_id": "K09192", 
                    "EggNOG_id": "COG5048", 
                    "Pathway_definition": "", 
                    "Gene Description": "sp2 transcription factor, transcript variant X1", 
                    "Pfam_id": "PF13465.9;PF00096.29;PF13894.9;PF07238.17", 
                    "GO_term": "cellular_component;molecular_function;molecular_function;biological_process", 
                    "Domain_description": "Zinc-finger double domain;Zinc finger, C2H2 type;C2H2-type zinc finger;PilZ domain", 
                    "NR_description": "transcription factor Sp2 isoform X1 [Scophthalmus maximus]", 
                    "GO_id": "GO:0016021;GO:0140359;GO:0005524;GO:0035264", 
                    "Swiss-Prot_description": "Transcription factor Sp2 OS=Mus musculus OX=10090 GN=Sp2 PE=2 SV=2", 
                    "Go_description": "CC:integral component of membrane;MF:ABC-type transmembrane transporter activity;MF:ATP binding;BP:multicellular organism growth", 
                    "Gene Name": "sp2", 
                    "EggNOG_Functional_Categories": "S:Function unknown", 
                    "NR_hit-name": "XP_035491971.1", 
                    "Gene ID": "gene-sp2", 
                    "Swiss-Prot_hit-name": "sp|Q9D2H6|SP2_MOUSE", 
                    "KO_name": "SP2"
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "WD40;ANAPC4_WD40;NBCH_WD40", 
                    "KO_id": "K24739", 
                    "EggNOG_id": "ENOG410Y3SD", 
                    "Pathway_definition": "", 
                    "Gene Description": "WD repeat domain 13", 
                    "Pfam_id": "PF00400.35;PF12894.10;PF20426.1", 
                    "GO_term": "", 
                    "Domain_description": "WD domain, G-beta repeat;Anaphase-promoting complex subunit 4 WD40 domain;Neurobeachin beta propeller domain", 
                    "NR_description": "WD repeat-containing protein 13 [Solea senegalensis]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "WD repeat-containing protein 13 OS=Pan troglodytes OX=9598 GN=WDR13 PE=3 SV=1", 
                    "Go_description": "", 
                    "Gene Name": "wdr13", 
                    "EggNOG_Functional_Categories": "S:Function unknown", 
                    "NR_hit-name": "KAG7519896.1", 
                    "Gene ID": "gene-wdr13", 
                    "Swiss-Prot_hit-name": "sp|Q6DKP5|WDR13_PANTR", 
                    "KO_name": "WDR13"
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "", 
                    "KO_id": "", 
                    "EggNOG_id": "ENOG410ZTQY", 
                    "Pathway_definition": "", 
                    "Gene Description": "basic immunoglobulin-like variable motif-containing protein", 
                    "Pfam_id": "", 
                    "GO_term": "", 
                    "Domain_description": "", 
                    "NR_description": "basic immunoglobulin-like variable motif-containing protein [Scophthalmus maximus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "Basic immunoglobulin-like variable motif-containing protein OS=Xenopus tropicalis OX=8364 GN=bivm PE=2 SV=1", 
                    "Go_description": "", 
                    "Gene Name": "LOC118317921", 
                    "EggNOG_Functional_Categories": "S:Function unknown", 
                    "NR_hit-name": "XP_035502955.2", 
                    "Gene ID": "gene-LOC118317921", 
                    "Swiss-Prot_hit-name": "sp|Q0V9T8|BIVM_XENTR", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "AhpC-TSA_2;AhpC-TSA", 
                    "KO_id": "", 
                    "EggNOG_id": "ENOG410YFY9", 
                    "Pathway_definition": "", 
                    "Gene Description": "peroxiredoxin-like 2A, transcript variant X1", 
                    "Pfam_id": "PF13911.9;PF00578.24", 
                    "GO_term": "", 
                    "Domain_description": "AhpC/TSA antioxidant enzyme;AhpC/TSA family", 
                    "NR_description": "peroxiredoxin-like 2A isoform X1 [Scophthalmus maximus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "Peroxiredoxin-like 2A OS=Danio rerio OX=7955 GN=prxl2a PE=2 SV=2", 
                    "Go_description": "", 
                    "Gene Name": "LOC118283339", 
                    "EggNOG_Functional_Categories": "O:Posttranslational modification, protein turnover, chaperones", 
                    "NR_hit-name": "XP_035461090.1", 
                    "Gene ID": "gene-LOC118283339", 
                    "Swiss-Prot_hit-name": "sp|Q6PBP3|PXL2A_DANRE", 
                    "KO_name": ""
                }, 
                {
                    "Pathway_id": "", 
                    "Domain": "LRR_8;LRR_4;LRR_5;LRR_9", 
                    "KO_id": "K16660", 
                    "EggNOG_id": "COG4886", 
                    "Pathway_definition": "", 
                    "Gene Description": "reticulon-4 receptor-like 1", 
                    "Pfam_id": "PF13855.9;PF12799.10;PF13306.9;PF14580.9", 
                    "GO_term": "", 
                    "Domain_description": "Leucine rich repeat;Leucine Rich repeats (2 copies;BspA type Leucine rich repeat region (6 copies;Leucine-rich repeat", 
                    "NR_description": "reticulon-4 receptor-like 1 [Scophthalmus maximus]", 
                    "GO_id": "", 
                    "Swiss-Prot_description": "Reticulon-4 receptor-like 1 OS=Homo sapiens OX=9606 GN=RTN4RL1 PE=1 SV=1", 
                    "Go_description": "", 
                    "Gene Name": "LOC118300823", 
                    "EggNOG_Functional_Categories": "S:Function unknown", 
                    "NR_hit-name": "XP_035481529.2", 
                    "Gene ID": "gene-LOC118300823", 
                    "Swiss-Prot_hit-name": "sp|Q86UN2|R4RL1_HUMAN", 
                    "KO_name": "RTN4RL1, NGR3"
                }, 
                {
                    "Pathway_id": "map04934;map05202", 
                    "Domain": "Menin", 
                    "KO_id": "K14970", 
                    "EggNOG_id": "ENOG410ZNZF", 
                    "Pathway_definition": "Cushing syndrome;Transcriptional misregulation in cancer", 
                    "Gene Description": "multiple endocrine neoplasia I, transcript variant X6", 
                    "Pfam_id": "PF05053.16", 
                    "GO_term": "cellular_component;biological_process;molecular_function", 
                    "Domain_description": "Menin", 
                    "NR_description": "menin [Scophthalmus maximus]", 
                    "GO_id": "GO:0005634;GO:0045892;GO:0003677", 
                    "Swiss-Prot_description": "Menin OS=Mus musculus OX=10090 GN=Men1 PE=1 SV=2", 
                    "Go_description": "CC:nucleus;BP:negative regulation of transcription, DNA-templated;MF:DNA binding", 
                    "Gene Name": "men1", 
                    "EggNOG_Functional_Categories": "K:Transcription", 
                    "NR_hit-name": "XP_035464188.2", 
                    "Gene ID": "gene-men1", 
                    "Swiss-Prot_hit-name": "sp|O88559|MEN1_MOUSE", 
                    "KO_name": "MEN1, MNN1"
                }
            ]
        }, 
        "table_append_01": {
            "table_header": [
                {
                    "field": "software_database", 
                    "label": "Soft/Database"
                }, 
                {
                    "field": "version", 
                    "label": "Version"
                }, 
                {
                    "field": "usage", 
                    "label": "Analysis"
                }, 
                {
                    "field": "source", 
                    "label": "Source"
                }
            ], 
            "table": [
                {
                    "software_database": "TransDecoder", 
                    "source": "http://transdecoder.github.io/", 
                    "version": "Version 5.5.0", 
                    "usage": "多类数据库注释比较分析等"
                }, 
                {
                    "software_database": "SeqPrep", 
                    "source": "https://github.com/jstjohn/SeqPrep", 
                    "version": "--", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "edgeR", 
                    "source": "http://bioconductor.org/packages/stats/bioc/edgeR/", 
                    "version": "Version 3.24.3", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "GATK", 
                    "source": "https://software.broadinstitute.org/gatk/download/", 
                    "version": "Version 3.8", 
                    "usage": "SNP/Indel分析"
                }, 
                {
                    "software_database": "WGCNA", 
                    "source": "https://cran.r-project.org/web/packages/WGCNA/index.html", 
                    "version": "Version 1.63", 
                    "usage": "WGCNA分析"
                }, 
                {
                    "software_database": "STRING 数据库", 
                    "source": "https://string-db.org/", 
                    "version": "v12.0", 
                    "usage": "靶基因蛋白互作网络"
                }, 
                {
                    "software_database": "sva", 
                    "source": "http://www.bioconductor.org/packages/release/bioc/html/sva.html", 
                    "version": "Version 3.20.0", 
                    "usage": "移除批次效应影响"
                }, 
                {
                    "software_database": "kallisto", 
                    "source": "https://pachterlab.github.io/kallisto/download", 
                    "version": "Version 0.46.2", 
                    "usage": "表达量分析"
                }, 
                {
                    "software_database": "PlantTFDB", 
                    "source": "http://planttfdb.gao-lab.org/", 
                    "version": "Version 5.0", 
                    "usage": "转录因子预测"
                }, 
                {
                    "software_database": "fastx_toolkit", 
                    "source": "http://hannonlab.cshl.edu/fastx_toolkit/", 
                    "version": "Version 0.0.14", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "NOISeq", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/NOISeq.html", 
                    "version": "Version 2.18.0", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "Salmon", 
                    "source": "https://github.com/COMBINE-lab/salmon", 
                    "version": "Version 1.3.0", 
                    "usage": "表达量分析"
                }, 
                {
                    "software_database": "cufflinks", 
                    "source": "http://cole-trapnell-lab.github.io/cufflinks/", 
                    "version": "Version 2.2.1", 
                    "usage": "转录本组装"
                }, 
                {
                    "software_database": "Blast2go", 
                    "source": "https://www.blast2go.com/", 
                    "version": "Version 2.5", 
                    "usage": "GO注释"
                }, 
                {
                    "software_database": "STEM", 
                    "source": "http://www.cs.cmu.edu/~jernst/stem/", 
                    "version": "Version 1.3.11", 
                    "usage": "时序表达趋势分析"
                }, 
                {
                    "software_database": "MSigDB 数据库", 
                    "source": "http://software.broadinstitute.org/gsea/downloads.jsp", 
                    "version": "Version 6.2", 
                    "usage": "GSEA分析"
                }, 
                {
                    "software_database": "star_fusion", 
                    "source": "https://github.com/STAR-Fusion/STAR-Fusion/wiki", 
                    "version": "Version 1.8.1", 
                    "usage": "基因融合鉴定"
                }, 
                {
                    "software_database": "Sickle", 
                    "source": "https://github.com/najoshi/sickle", 
                    "version": "--", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "KOBAS", 
                    "source": "http://kobas.cbi.pku.edu.cn/download.php", 
                    "version": "Version 2.1.1", 
                    "usage": "功能注释分类（KEGG）"
                }, 
                {
                    "software_database": "GSEA", 
                    "source": "http://software.broadinstitute.org/gsea/index.jsp", 
                    "version": "Version 4.3.2", 
                    "usage": "GSEA分析"
                }, 
                {
                    "software_database": "Ipath 数据库", 
                    "source": "https://pathways.embl.de/", 
                    "version": "Version 3", 
                    "usage": "iPath代谢通路分析"
                }, 
                {
                    "software_database": "stringtie", 
                    "source": "https://ccb.jhu.edu/software/stringtie/", 
                    "version": "Version 2.1.2", 
                    "usage": "转录本组装"
                }, 
                {
                    "software_database": "fastp", 
                    "source": "https://github.com/OpenGene/fastp", 
                    "version": "0.19.5", 
                    "usage": "测序数据质控"
                }, 
                {
                    "software_database": "TopHat", 
                    "source": "http://ccb.jhu.edu/software/tophat/index.shtml", 
                    "version": "Version v2.1.1", 
                    "usage": "序列比对分析"
                }, 
                {
                    "software_database": "DEGSeq", 
                    "source": "http://bioconductor.org/packages/stats/bioc/DEGSeq/", 
                    "version": "Version 1.38.0", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "Bowtie2", 
                    "source": "http://downloads.sourceforge.net/project/bowtie-bio/bowtie2/2.4.1", 
                    "version": "Version 2.4.1", 
                    "usage": "序列比对"
                }, 
                {
                    "software_database": "Diamond", 
                    "source": "https://github.com/bbuchfink/diamond", 
                    "version": "Version 0.9.24", 
                    "usage": "多类数据库注释比较分析等"
                }, 
                {
                    "software_database": "RSEM", 
                    "source": "http://deweylab.biostat.wisc.edu/rsem/", 
                    "version": "Version 1.3.3", 
                    "usage": "表达量分析"
                }, 
                {
                    "software_database": "ASprofile", 
                    "source": "http://ccb.jhu.edu/software/ASprofile/", 
                    "version": "Version 1.0", 
                    "usage": "可变剪切分析"
                }, 
                {
                    "software_database": "hisat2", 
                    "source": "http://ccb.jhu.edu/software/hisat2/index.shtml", 
                    "version": "Version 2.1.0", 
                    "usage": "序列比对分析"
                }, 
                {
                    "software_database": "JASPAR", 
                    "source": "https://jaspar2022.genereg.net/", 
                    "version": "Version 2022", 
                    "usage": "转录因子预测"
                }, 
                {
                    "software_database": "samtools", 
                    "source": "https://github.com/samtools/samtools.git ", 
                    "version": "Version 1.9", 
                    "usage": "SNP/Indel分析"
                }, 
                {
                    "software_database": "Limma", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/limma.html", 
                    "version": "Version 3.38.3", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "HMMER", 
                    "source": "ftp://selab.janelia.org/pub/software/hmmer3/3.0/hmmer-3.0.tar.gz", 
                    "version": "Version 3.2.1", 
                    "usage": "功能注释"
                }, 
                {
                    "software_database": "DESeq2", 
                    "source": "http://bioconductor.org/packages/stats/bioc/DESeq2/", 
                    "version": "Version 1.24.0", 
                    "usage": "表达量差异分析"
                }, 
                {
                    "software_database": "BLAST+", 
                    "source": "ftp://ftp.ncbi.nlm.nih.gov/blast/executables/blast+/2.9.0/", 
                    "version": "Version 2.9.0", 
                    "usage": "多类数据库注释比较分析等"
                }, 
                {
                    "software_database": "bedtools", 
                    "source": "https://bedtools.readthedocs.io/en/latest/", 
                    "version": "Version 2.27.1", 
                    "usage": "序列提取"
                }, 
                {
                    "software_database": "goatools", 
                    "source": "https://files.pythonhosted.org/packages/bb/7b/0c76e3511a79879606672e0741095a891dfb98cd63b1530ed8c51d406cda/goatools-0.8.9.tar.gz", 
                    "version": "Version 0.6.5", 
                    "usage": "基因集分析（GO富集）"
                }, 
                {
                    "software_database": "maSigPro", 
                    "source": "http://www.bioconductor.org/packages/release/bioc/html/maSigPro.html", 
                    "version": "Version 1.56.0", 
                    "usage": "时序差异聚类"
                }, 
                {
                    "software_database": "AnimalTFDB", 
                    "source": "http://bioinfo.life.hust.edu.cn/AnimalTFDB4/#/", 
                    "version": "Version 4.0", 
                    "usage": "转录因子预测"
                }, 
                {
                    "software_database": "STAR", 
                    "source": "http://code.google.com/p/rna-star/", 
                    "version": "Version 2.7.1a", 
                    "usage": "序列比对分析"
                }, 
                {
                    "software_database": "Mfuzz", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
                    "version": "Version 2.6.0", 
                    "usage": "Mfuzz时序分析"
                }, 
                {
                    "software_database": "Pfam 数据库", 
                    "source": "http://pfam.xfam.org/", 
                    "version": "Version 35.0", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "KEGG 数据库", 
                    "source": "http://www.genome.jp/kegg/", 
                    "version": "Version 2022.10", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "eggNOG 数据库", 
                    "source": "http://eggnogdb.embl.de/#/app/home", 
                    "version": "Version 2020.06", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "Rfam 数据库", 
                    "source": "http://rfam.janelia.org/", 
                    "version": "Version 14.8", 
                    "usage": "核糖体比例评估"
                }, 
                {
                    "software_database": "Swiss-prot 数据库", 
                    "source": "ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz", 
                    "version": "Version 2022.10", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "GO 数据库", 
                    "source": "http://www.geneontology.org/", 
                    "version": "Version 2022.0915", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "NR 数据库", 
                    "source": "https://www.ncbi.nlm.nih.gov/public/", 
                    "version": "Version 2022.10", 
                    "usage": "基因注释"
                }, 
                {
                    "software_database": "Mfuzz", 
                    "source": "https://www.bioconductor.org/packages/release/bioc/html/Mfuzz.html", 
                    "version": "Version 2.6.0", 
                    "usage": "Mfuzz时序分析"
                }
            ]
        }, 
        "table_5651": {
            "table_header": [
                {
                    "field": "Sample", 
                    "label": "Sample"
                }, 
                {
                    "field": "Raw_reads", 
                    "label": "Raw_reads"
                }, 
                {
                    "field": "Raw_bases", 
                    "label": "Raw_bases"
                }, 
                {
                    "field": "Clean_reads", 
                    "label": "Clean_reads"
                }, 
                {
                    "field": "Clean_Bases", 
                    "label": "Clean_Bases"
                }, 
                {
                    "field": "Error%", 
                    "label": "Error%"
                }, 
                {
                    "field": "Q20%", 
                    "label": "Q20%"
                }, 
                {
                    "field": "Q30%", 
                    "label": "Q30%"
                }, 
                {
                    "field": "GC%", 
                    "label": "GC%"
                }
            ], 
            "table": [
                {
                    "GC%": 49.0, 
                    "Raw_reads": 50117782, 
                    "Sample": "NF1", 
                    "Q30%": 95.44, 
                    "Clean_reads": 49551692, 
                    "Error%": 0.0124, 
                    "Clean_Bases": 7379803919, 
                    "Q20%": 98.45, 
                    "Raw_bases": 7567785082
                }, 
                {
                    "GC%": 49.2, 
                    "Raw_reads": 46213382, 
                    "Sample": "HF1", 
                    "Q30%": 95.23, 
                    "Clean_reads": 45665400, 
                    "Error%": 0.0125, 
                    "Clean_Bases": 6835479031, 
                    "Q20%": 98.39, 
                    "Raw_bases": 6978220682
                }, 
                {
                    "GC%": 48.96, 
                    "Raw_reads": 41588006, 
                    "Sample": "NF3", 
                    "Q30%": 95.31, 
                    "Clean_reads": 41108390, 
                    "Error%": 0.0124, 
                    "Clean_Bases": 6145401342, 
                    "Q20%": 98.41, 
                    "Raw_bases": 6279788906
                }, 
                {
                    "GC%": 48.94, 
                    "Raw_reads": 49767590, 
                    "Sample": "HF3", 
                    "Q30%": 95.31, 
                    "Clean_reads": 49176156, 
                    "Error%": 0.0124, 
                    "Clean_Bases": 7351344082, 
                    "Q20%": 98.41, 
                    "Raw_bases": 7514906090
                }, 
                {
                    "GC%": 49.16, 
                    "Raw_reads": 41231890, 
                    "Sample": "HF2", 
                    "Q30%": 95.11, 
                    "Clean_reads": 40748810, 
                    "Error%": 0.0125, 
                    "Clean_Bases": 6102161352, 
                    "Q20%": 98.35, 
                    "Raw_bases": 6226015390
                }, 
                {
                    "GC%": 48.82, 
                    "Raw_reads": 46291554, 
                    "Sample": "NF2", 
                    "Q30%": 95.2, 
                    "Clean_reads": 45758398, 
                    "Error%": 0.0125, 
                    "Clean_Bases": 6853429307, 
                    "Q20%": 98.39, 
                    "Raw_bases": 6990024654
                }
            ]
        }, 
        "table_5763": {
            "table_header": [
                {
                    "field": "Region", 
                    "label": "Region"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": 0, 
                    "Region": ".", 
                    "HF2": 0, 
                    "NF3": 0, 
                    "NF2": 0, 
                    "NF1": 0, 
                    "HF3": 0
                }, 
                {
                    "HF1": 47234, 
                    "Region": "UTR3", 
                    "HF2": 44426, 
                    "NF3": 44379, 
                    "NF2": 44961, 
                    "NF1": 45424, 
                    "HF3": 45691
                }, 
                {
                    "HF1": 9362, 
                    "Region": "UTR5", 
                    "HF2": 8771, 
                    "NF3": 8863, 
                    "NF2": 9845, 
                    "NF1": 9319, 
                    "HF3": 9688
                }, 
                {
                    "HF1": 48, 
                    "Region": "UTR5;UTR3", 
                    "HF2": 32, 
                    "NF3": 39, 
                    "NF2": 40, 
                    "NF1": 36, 
                    "HF3": 33
                }, 
                {
                    "HF1": 5178, 
                    "Region": "downstream", 
                    "HF2": 4690, 
                    "NF3": 4856, 
                    "NF2": 5241, 
                    "NF1": 5352, 
                    "HF3": 5323
                }, 
                {
                    "HF1": 38291, 
                    "Region": "exonic", 
                    "HF2": 35906, 
                    "NF3": 36179, 
                    "NF2": 37313, 
                    "NF1": 36791, 
                    "HF3": 37292
                }, 
                {
                    "HF1": 5, 
                    "Region": "exonic;splicing", 
                    "HF2": 4, 
                    "NF3": 10, 
                    "NF2": 6, 
                    "NF1": 9, 
                    "HF3": 9
                }, 
                {
                    "HF1": 3667, 
                    "Region": "intergenic", 
                    "HF2": 3181, 
                    "NF3": 3222, 
                    "NF2": 4303, 
                    "NF1": 3565, 
                    "HF3": 3754
                }, 
                {
                    "HF1": 42535, 
                    "Region": "intronic", 
                    "HF2": 43290, 
                    "NF3": 43480, 
                    "NF2": 74443, 
                    "NF1": 47088, 
                    "HF3": 59195
                }, 
                {
                    "HF1": 754, 
                    "Region": "ncRNA_UTR3", 
                    "HF2": 689, 
                    "NF3": 698, 
                    "NF2": 693, 
                    "NF1": 698, 
                    "HF3": 748
                }
            ]
        }, 
        "table_5631": {
            "table_header": [
                {
                    "field": "Length", 
                    "label": "Length"
                }, 
                {
                    "field": "Number", 
                    "label": "Number"
                }
            ], 
            "table": [
                {
                    "Length": "0~200", 
                    "Number": 2313
                }, 
                {
                    "Length": "201~400", 
                    "Number": 470
                }, 
                {
                    "Length": "401~600", 
                    "Number": 954
                }, 
                {
                    "Length": "601~800", 
                    "Number": 1256
                }, 
                {
                    "Length": "801~1000", 
                    "Number": 1718
                }, 
                {
                    "Length": "1001~1200", 
                    "Number": 1891
                }, 
                {
                    "Length": "1201~1400", 
                    "Number": 2278
                }, 
                {
                    "Length": "1401~1600", 
                    "Number": 2782
                }, 
                {
                    "Length": "1601~1800", 
                    "Number": 2784
                }, 
                {
                    "Length": ">1800", 
                    "Number": 55222
                }
            ]
        }, 
        "table_5633": {
            "table_header": [
                {
                    "field": "Unnamed: 0", 
                    "label": "Unnamed: 0"
                }, 
                {
                    "field": "Expre_Gene number(percent)", 
                    "label": "Expre_Gene number(percent)"
                }, 
                {
                    "field": "Expre_Transcript number(percent)", 
                    "label": "Expre_Transcript number(percent)"
                }, 
                {
                    "field": "All_Gene number(percent)", 
                    "label": "All_Gene number(percent)"
                }, 
                {
                    "field": "All_Transcript number(percent)", 
                    "label": "All_Transcript number(percent)"
                }
            ], 
            "table": [
                {
                    "Expre_Gene number(percent)": "16836(0.7365)", 
                    "Expre_Transcript number(percent)": "41651(0.7079)", 
                    "Unnamed: 0": "GO", 
                    "All_Transcript number(percent)": "48885(0.6821)", 
                    "All_Gene number(percent)": "18370(0.6832)"
                }, 
                {
                    "Expre_Gene number(percent)": "17227(0.7536)", 
                    "Expre_Transcript number(percent)": "45747(0.7775)", 
                    "Unnamed: 0": "KEGG", 
                    "All_Transcript number(percent)": "53919(0.7523)", 
                    "All_Gene number(percent)": "18790(0.6988)"
                }, 
                {
                    "Expre_Gene number(percent)": "21074(0.9218)", 
                    "Expre_Transcript number(percent)": "55471(0.9428)", 
                    "Unnamed: 0": "EggNOG", 
                    "All_Transcript number(percent)": "64661(0.9022)", 
                    "All_Gene number(percent)": "22308(0.8296)"
                }, 
                {
                    "Expre_Gene number(percent)": "22236(0.9727)", 
                    "Expre_Transcript number(percent)": "57753(0.9816)", 
                    "Unnamed: 0": "NR", 
                    "All_Transcript number(percent)": "69304(0.967)", 
                    "All_Gene number(percent)": "25215(0.9377)"
                }, 
                {
                    "Expre_Gene number(percent)": "20307(0.8883)", 
                    "Expre_Transcript number(percent)": "53800(0.9144)", 
                    "Unnamed: 0": "Swiss-Prot", 
                    "All_Transcript number(percent)": "62469(0.8716)", 
                    "All_Gene number(percent)": "21252(0.7903)"
                }, 
                {
                    "Expre_Gene number(percent)": "19734(0.8632)", 
                    "Expre_Transcript number(percent)": "51557(0.8763)", 
                    "Unnamed: 0": "Pfam", 
                    "All_Transcript number(percent)": "59237(0.8265)", 
                    "All_Gene number(percent)": "20477(0.7615)"
                }, 
                {
                    "Expre_Gene number(percent)": "22242(0.9729)", 
                    "Expre_Transcript number(percent)": "57770(0.9819)", 
                    "Unnamed: 0": "Total_anno", 
                    "All_Transcript number(percent)": "69330(0.9674)", 
                    "All_Gene number(percent)": "25230(0.9383)"
                }, 
                {
                    "Expre_Gene number(percent)": "22861(1)", 
                    "Expre_Transcript number(percent)": "58837(1)", 
                    "Unnamed: 0": "Total", 
                    "All_Transcript number(percent)": "71668(1.0)", 
                    "All_Gene number(percent)": "26890(1.0)"
                }
            ]
        }, 
        "table_5721": {
            "table_header": [
                {
                    "field": "seq_id", 
                    "label": "seq_id"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": 0.173031996063, 
                    "seq_id": "gene-LOC118302737", 
                    "HF3": -0.150887659645, 
                    "HF2": 2.03040802717, 
                    "NF3": -1.15295142758, 
                    "NF2": -0.662871077583, 
                    "NF1": -0.23672985841699998
                }, 
                {
                    "HF1": -0.065702441669, 
                    "seq_id": "gene-LOC118299367", 
                    "HF3": -0.065702441669, 
                    "HF2": 2.1518809930700002, 
                    "NF3": -0.673492036576, 
                    "NF2": -0.673492036576, 
                    "NF1": -0.673492036576
                }, 
                {
                    "HF1": 0.422846969849, 
                    "seq_id": "gene-LOC118300680", 
                    "HF3": -0.694823861658, 
                    "HF2": 1.9413574413900003, 
                    "NF3": -1.2096651084999999, 
                    "NF2": -0.24707265626699998, 
                    "NF1": -0.212642784812
                }, 
                {
                    "HF1": 0.963970057832, 
                    "seq_id": "gene-LOC118315664", 
                    "HF3": -0.27599928395999995, 
                    "HF2": 1.65718029653, 
                    "NF3": -0.545789362603, 
                    "NF2": -1.30686771615, 
                    "NF1": -0.49249399164200003
                }, 
                {
                    "HF1": 0.866095550947, 
                    "seq_id": "gene-LOC118283619", 
                    "HF3": -0.172907235134, 
                    "HF2": 1.7402951333099996, 
                    "NF3": -1.17263206754, 
                    "NF2": -0.5269477593649999, 
                    "NF1": -0.7339036222249999
                }, 
                {
                    "HF1": 0.9173380957539999, 
                    "seq_id": "gene-LOC118309129", 
                    "HF3": -0.492388551812, 
                    "HF2": 1.7753706742500002, 
                    "NF3": -0.416895941748, 
                    "NF2": -0.8917121382200002, 
                    "NF1": -0.8917121382200002
                }
            ]
        }, 
        "table_5727": {
            "table_header": [
                {
                    "field": "Term type", 
                    "label": "Term type"
                }, 
                {
                    "field": "Description", 
                    "label": "Description"
                }, 
                {
                    "field": "GO ID", 
                    "label": "GO ID"
                }, 
                {
                    "field": "HF_vs_NF_G num", 
                    "label": "HF_vs_NF_G num"
                }, 
                {
                    "field": "HF_vs_NF_G percent", 
                    "label": "HF_vs_NF_G percent"
                }, 
                {
                    "field": "HF_vs_NF_G list", 
                    "label": "HF_vs_NF_G list"
                }
            ], 
            "table": [
                {
                    "HF_vs_NF_G num": 3, 
                    "Description": "immune system process", 
                    "GO ID": "GO:0002376", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-LOC118284582;gene-LOC118314440;gene-LOC118312169", 
                    "HF_vs_NF_G percent": "0.0(3/304)"
                }, 
                {
                    "HF_vs_NF_G num": 31, 
                    "Description": "biological regulation", 
                    "GO ID": "GO:0065007", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-LOC118309129;gene-dab2ipa;gene-arr3b;gene-scn1ba;gene-LOC118314679;gene-gck;gene-uxt;gene-gap43;gene-hsd17b1;gene-plch1;gene-LOC118311080;gene-fgf23;gene-LOC118288865;gene-gng3;gene-abrab;gene-gucy2cb;gene-sntg2;gene-LOC118282761;gene-LOC118283762;gene-LOC118283761;gene-cacna1da;gene-fgf3;gene-LOC118290077;gene-grb7;gene-acat2;gene-LOC124850005;gene-LOC118283923;gene-LOC118310653;gene-LOC118284036;gene-LOC118312169;gene-asb11", 
                    "HF_vs_NF_G percent": "0.0(31/304)"
                }, 
                {
                    "HF_vs_NF_G num": 76, 
                    "Description": "metabolic process", 
                    "GO ID": "GO:0008152", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-tnni3k;gene-mei4;gene-aacs;gene-frem2a;gene-LOC118302117;gene-plch1;gene-ela3l;gene-nt5c1aa;gene-acat2;gene-LOC118284959;gene-gck;gene-LOC118300680;gene-LOC118316584;gene-LOC118284976;gene-tm7sf2;gene-sik1;gene-LOC118301035;gene-LOC118299414;gene-LOC118284960;gene-LOC118310934;gene-hsd17b1;gene-LOC118313215;gene-hsd17b7;gene-zgc_123217;gene-plcxd3;gene-prdm1c;gene-LOC118292229;gene-LOC118289297;gene-LOC118316996;gene-gatm;gene-LOC124850057;gene-gmds;gene-aldh1l1;gene-asb11;gene-LOC118318472;gene-gcna;gene-gamt;gene-LOC118301998;gene-LOC118286429;gene-LOC118316714;gene-itih2;gene-LOC118318725;gene-LOC118291669;gene-LOC118302737;gene-mapk15;gene-camkk1b;gene-LOC118309980;gene-camk2a;gene-gucy2cb;gene-LOC118301225;gene-LOC118290667;gene-sntg2;gene-LOC118282761;gene-LOC118313990;gene-erg28;gene-LOC118311709;gene-LOC118313691;gene-LOC118284767;gene-hmgcra;gene-LOC118290077;gene-prodhb;gene-LOC118292268;gene-LOC118317479;gene-nos1;gene-fdps;gene-LOC118319393;gene-LOC118314424;gene-LOC118314794;gene-LOC118284036;gene-hmgcs1;gene-gtf2a1l;gene-LOC118318042;gene-pgm2l1;gene-LOC118313152;gene-pck1;gene-LOC118315681", 
                    "HF_vs_NF_G percent": "0.0(76/304)"
                }, 
                {
                    "HF_vs_NF_G num": 4, 
                    "Description": "reproductive process", 
                    "GO ID": "GO:0022414", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-mei4;gene-terb1;gene-mapk15;gene-LOC118316584", 
                    "HF_vs_NF_G percent": "0.0(4/304)"
                }, 
                {
                    "HF_vs_NF_G num": 84, 
                    "Description": "cellular process", 
                    "GO ID": "GO:0009987", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-tnni3k;gene-mei4;gene-dab2ipa;gene-fdps;gene-snx20;gene-frem2a;gene-arr3b;gene-plch1;gene-LOC118314679;gene-nt5c1aa;gene-acat2;gene-terb1;gene-gck;gene-LOC118300680;gene-gmds;gene-sik1;gene-camk2a;gene-gap43;gene-hmgcra;gene-LOC118290667;gene-LOC118286429;gene-LOC118284960;gene-LOC118310934;gene-hsd17b1;gene-LOC118301035;gene-LOC118292268;gene-LOC118316584;gene-LOC118284959;gene-aldh1l1;gene-prdm1c;gene-LOC118292229;gene-LOC118289297;gene-gatm;gene-LOC124850057;gene-LOC118311080;gene-LOC118290901;gene-bco1;gene-gabrg2;gene-LOC118318472;gene-tmem38a;gene-gcna;gene-gamt;gene-fgf23;gene-LOC118318725;gene-fgf3;gene-aacs;gene-LOC118302737;gene-mapk15;gene-camkk1b;gene-LOC118317870;gene-LOC118319859;gene-gucy2cb;gene-lyve1a;gene-gng3;gene-LOC118282761;gene-LOC118313990;gene-calr;gene-LOC118284976;gene-LOC118283762;gene-LOC118283761;gene-LOC118315248;gene-nefma;gene-LOC118311709;gene-LOC118317382;gene-LOC118317380;gene-LOC118299414;gene-slc1a4;gene-prodhb;gene-hmgcs1;gene-grb7;gene-LOC118319393;gene-LOC124850005;gene-LOC118314794;gene-LOC118283923;gene-LOC118284036;gene-asb11;gene-LOC118311660;gene-gtf2a1l;gene-sntg2;gene-LOC118318042;gene-nos1;gene-map1b;gene-pck1;gene-LOC118311872", 
                    "HF_vs_NF_G percent": "0.0(84/304)"
                }, 
                {
                    "HF_vs_NF_G num": 18, 
                    "Description": "developmental process", 
                    "GO ID": "GO:0032502", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-LOC118291637;gene-fgf3;gene-tmem38a;gene-bco1;gene-hmgcs1;gene-LOC118317870;gene-abrab;gene-map1b;gene-prdm1c;gene-LOC118318827;gene-LOC118282761;gene-uxt;gene-LOC118284036;gene-gap43;gene-LOC118315463;gene-bag3;gene-LOC118286673;gene-LOC118291644", 
                    "HF_vs_NF_G percent": "0.0(18/304)"
                }, 
                {
                    "HF_vs_NF_G num": 6, 
                    "Description": "multicellular organismal process", 
                    "GO ID": "GO:0032501", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-fgf3;gene-arr3b;gene-si_ch211-103a14.5;gene-LOC118282761;gene-LOC118309262;gene-bag3", 
                    "HF_vs_NF_G percent": "0.0(6/304)"
                }, 
                {
                    "HF_vs_NF_G num": 1, 
                    "Description": "biological process involved in interspecies interaction between organisms", 
                    "GO ID": "GO:0044419", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-LOC124850005", 
                    "HF_vs_NF_G percent": "0.0(1/304)"
                }, 
                {
                    "HF_vs_NF_G num": 8, 
                    "Description": "localization", 
                    "GO ID": "GO:0051179", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-snx20;gene-LOC118292229;gene-terb1;gene-gtf2a1l;gene-LOC118284976;gene-LOC118301035;gene-calhm6;gene-slc1a4", 
                    "HF_vs_NF_G percent": "0.0(8/304)"
                }, 
                {
                    "HF_vs_NF_G num": 1, 
                    "Description": "detoxification", 
                    "GO ID": "GO:0098754", 
                    "Term type": "biological_process", 
                    "HF_vs_NF_G list": "gene-LOC118301035", 
                    "HF_vs_NF_G percent": "0.0(1/304)"
                }
            ]
        }, 
        "table_9949": {
            "table_header": [
                {
                    "field": "GENE(in or nearby)", 
                    "label": "GENE(in or nearby)"
                }, 
                {
                    "field": "Gene name", 
                    "label": "Gene name"
                }, 
                {
                    "field": "Gene description", 
                    "label": "Gene description"
                }, 
                {
                    "field": "Chrom", 
                    "label": "Chrom"
                }, 
                {
                    "field": "Start", 
                    "label": "Start"
                }, 
                {
                    "field": "End", 
                    "label": "End"
                }, 
                {
                    "field": "Ref", 
                    "label": "Ref"
                }, 
                {
                    "field": "Alt", 
                    "label": "Alt"
                }, 
                {
                    "field": "Total depth", 
                    "label": "Total depth"
                }, 
                {
                    "field": "QUAL", 
                    "label": "QUAL"
                }, 
                {
                    "field": "Anno", 
                    "label": "Anno"
                }, 
                {
                    "field": "MUT type", 
                    "label": "MUT type"
                }, 
                {
                    "field": "MUT info", 
                    "label": "MUT info"
                }, 
                {
                    "field": "HF1_sampledepth", 
                    "label": "HF1_sampledepth"
                }, 
                {
                    "field": "HF1genotype", 
                    "label": "HF1genotype"
                }, 
                {
                    "field": "HF2_sampledepth", 
                    "label": "HF2_sampledepth"
                }, 
                {
                    "field": "HF2genotype", 
                    "label": "HF2genotype"
                }, 
                {
                    "field": "HF3_sampledepth", 
                    "label": "HF3_sampledepth"
                }, 
                {
                    "field": "HF3genotype", 
                    "label": "HF3genotype"
                }, 
                {
                    "field": "NF1_sampledepth", 
                    "label": "NF1_sampledepth"
                }, 
                {
                    "field": "NF1genotype", 
                    "label": "NF1genotype"
                }, 
                {
                    "field": "NF2_sampledepth", 
                    "label": "NF2_sampledepth"
                }, 
                {
                    "field": "NF2genotype", 
                    "label": "NF2genotype"
                }, 
                {
                    "field": "NF3_sampledepth", 
                    "label": "NF3_sampledepth"
                }, 
                {
                    "field": "NF3genotype", 
                    "label": "NF3genotype"
                }, 
                {
                    "field": "type", 
                    "label": "type"
                }
            ], 
            "table": [
                {
                    "End": 4896, 
                    "HF1genotype": "A/A", 
                    "Gene description": "-;;fibrillarin", 
                    "NF2genotype": "T/T", 
                    "Anno": "intergenic", 
                    "Start": 4896, 
                    "Gene name": "-;;fbl", 
                    "Ref": "T", 
                    "Total depth": 3, 
                    "HF1_sampledepth": "0,2", 
                    "HF3genotype": "./.", 
                    "NF2_sampledepth": "1,0", 
                    "MUT info": ".", 
                    "NF1genotype": "./.", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "0,0", 
                    "HF2genotype": "./.", 
                    "HF2_sampledepth": "0,0", 
                    "QUAL": 65.9, 
                    "NF3_sampledepth": "0,0", 
                    "GENE(in or nearby)": "NONE(dist=NONE),gene-fbl(dist=1293)", 
                    "NF1_sampledepth": "0,0", 
                    "NF3genotype": "./.", 
                    "type": "snp", 
                    "Alt": "A", 
                    "MUT type": "."
                }, 
                {
                    "End": 7303, 
                    "HF1genotype": "./.", 
                    "Gene description": "fibrillarin", 
                    "NF2genotype": "A/A", 
                    "Anno": "intronic", 
                    "Start": 7303, 
                    "Gene name": "fbl", 
                    "Ref": "A", 
                    "Total depth": 7, 
                    "HF1_sampledepth": "0,0", 
                    "HF3genotype": "A/A", 
                    "NF2_sampledepth": "2,0", 
                    "MUT info": ".", 
                    "NF1genotype": "A/A", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "1,0", 
                    "HF2genotype": "A/T", 
                    "HF2_sampledepth": "1,2", 
                    "QUAL": 36.05, 
                    "NF3_sampledepth": "0,0", 
                    "GENE(in or nearby)": "gene-fbl", 
                    "NF1_sampledepth": "1,0", 
                    "NF3genotype": "./.", 
                    "type": "snp", 
                    "Alt": "T", 
                    "MUT type": "."
                }, 
                {
                    "End": 7814, 
                    "HF1genotype": "C/C", 
                    "Gene description": "fibrillarin", 
                    "NF2genotype": "C/C", 
                    "Anno": "intronic", 
                    "Start": 7814, 
                    "Gene name": "fbl", 
                    "Ref": "C", 
                    "Total depth": 14, 
                    "HF1_sampledepth": "1,0", 
                    "HF3genotype": "C/C", 
                    "NF2_sampledepth": "4,0", 
                    "MUT info": ".", 
                    "NF1genotype": "C/C", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "3,0", 
                    "HF2genotype": "T/T", 
                    "HF2_sampledepth": "0,3", 
                    "QUAL": 57.53, 
                    "NF3_sampledepth": "2,0", 
                    "GENE(in or nearby)": "gene-fbl", 
                    "NF1_sampledepth": "1,0", 
                    "NF3genotype": "C/C", 
                    "type": "snp", 
                    "Alt": "T", 
                    "MUT type": "."
                }, 
                {
                    "End": 12230, 
                    "HF1genotype": "C/C", 
                    "Gene description": "fibrillarin", 
                    "NF2genotype": "C/C", 
                    "Anno": "intronic", 
                    "Start": 12230, 
                    "Gene name": "fbl", 
                    "Ref": "T", 
                    "Total depth": 12, 
                    "HF1_sampledepth": "0,3", 
                    "HF3genotype": "./.", 
                    "NF2_sampledepth": "0,4", 
                    "MUT info": ".", 
                    "NF1genotype": "C/C", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "0,0", 
                    "HF2genotype": "C/C", 
                    "HF2_sampledepth": "0,3", 
                    "QUAL": 351.57, 
                    "NF3_sampledepth": "0,0", 
                    "GENE(in or nearby)": "gene-fbl", 
                    "NF1_sampledepth": "0,2", 
                    "NF3genotype": "./.", 
                    "type": "snp", 
                    "Alt": "C", 
                    "MUT type": "."
                }, 
                {
                    "End": 12518, 
                    "HF1genotype": "G/G", 
                    "Gene description": "fibrillarin", 
                    "NF2genotype": "G/T", 
                    "Anno": "UTR3", 
                    "Start": 12518, 
                    "Gene name": "fbl", 
                    "Ref": "G", 
                    "Total depth": 1516, 
                    "HF1_sampledepth": "363,0", 
                    "HF3genotype": "G/G", 
                    "NF2_sampledepth": "184,172", 
                    "MUT info": ".", 
                    "NF1genotype": "G/G", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "376,0", 
                    "HF2genotype": "G/T", 
                    "HF2_sampledepth": "181,146", 
                    "QUAL": 11085.12, 
                    "NF3_sampledepth": "46,0", 
                    "GENE(in or nearby)": "gene-fbl", 
                    "NF1_sampledepth": "46,0", 
                    "NF3genotype": "G/G", 
                    "type": "snp", 
                    "Alt": "T", 
                    "MUT type": "."
                }, 
                {
                    "End": 13501, 
                    "HF1genotype": "./.", 
                    "Gene description": "dual-specificity tyrosine-(Y)-phosphorylation regulated kinase 1B, transcript variant X3;;fibrillarin", 
                    "NF2genotype": "./.", 
                    "Anno": "upstream;downstream", 
                    "Start": 13501, 
                    "Gene name": "dyrk1b;;fbl", 
                    "Ref": "C", 
                    "Total depth": 4, 
                    "HF1_sampledepth": "0,0", 
                    "HF3genotype": "A/A", 
                    "NF2_sampledepth": "0,0", 
                    "MUT info": ".", 
                    "NF1genotype": "./.", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "0,2", 
                    "HF2genotype": "./.", 
                    "HF2_sampledepth": "0,0", 
                    "QUAL": 64.9, 
                    "NF3_sampledepth": "2,0", 
                    "GENE(in or nearby)": "gene-dyrk1b;gene-fbl", 
                    "NF1_sampledepth": "0,0", 
                    "NF3genotype": "C/C", 
                    "type": "snp", 
                    "Alt": "A", 
                    "MUT type": "."
                }, 
                {
                    "End": 13690, 
                    "HF1genotype": "A/A", 
                    "Gene description": "dual-specificity tyrosine-(Y)-phosphorylation regulated kinase 1B, transcript variant X3", 
                    "NF2genotype": "A/A", 
                    "Anno": "UTR5", 
                    "Start": 13690, 
                    "Gene name": "dyrk1b", 
                    "Ref": "A", 
                    "Total depth": 29, 
                    "HF1_sampledepth": "7,0", 
                    "HF3genotype": "A/A", 
                    "NF2_sampledepth": "6,0", 
                    "MUT info": ".", 
                    "NF1genotype": "A/A", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "7,0", 
                    "HF2genotype": "A/G", 
                    "HF2_sampledepth": "1,2", 
                    "QUAL": 48.69, 
                    "NF3_sampledepth": "4,0", 
                    "GENE(in or nearby)": "gene-dyrk1b", 
                    "NF1_sampledepth": "2,0", 
                    "NF3genotype": "A/A", 
                    "type": "snp", 
                    "Alt": "G", 
                    "MUT type": "."
                }, 
                {
                    "End": 14100, 
                    "HF1genotype": "T/T", 
                    "Gene description": "dual-specificity tyrosine-(Y)-phosphorylation regulated kinase 1B, transcript variant X3", 
                    "NF2genotype": "T/A", 
                    "Anno": "UTR5", 
                    "Start": 14100, 
                    "Gene name": "dyrk1b", 
                    "Ref": "T", 
                    "Total depth": 97, 
                    "HF1_sampledepth": "16,0", 
                    "HF3genotype": "T/A", 
                    "NF2_sampledepth": "9,13", 
                    "MUT info": ".", 
                    "NF1genotype": "A/A", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "11,2", 
                    "HF2genotype": "T/T", 
                    "HF2_sampledepth": "18,0", 
                    "QUAL": 1235.98, 
                    "NF3_sampledepth": "8,7", 
                    "GENE(in or nearby)": "gene-dyrk1b", 
                    "NF1_sampledepth": "0,13", 
                    "NF3genotype": "T/A", 
                    "type": "snp", 
                    "Alt": "A", 
                    "MUT type": "."
                }, 
                {
                    "End": 14377, 
                    "HF1genotype": "G/G", 
                    "Gene description": "dual-specificity tyrosine-(Y)-phosphorylation regulated kinase 1B, transcript variant X3", 
                    "NF2genotype": "G/G", 
                    "Anno": "UTR5", 
                    "Start": 14377, 
                    "Gene name": "dyrk1b", 
                    "Ref": "A", 
                    "Total depth": 175, 
                    "HF1_sampledepth": "0,24", 
                    "HF3genotype": "G/G", 
                    "NF2_sampledepth": "0,25", 
                    "MUT info": ".", 
                    "NF1genotype": "G/G", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "0,38", 
                    "HF2genotype": "A/G", 
                    "HF2_sampledepth": "17,9", 
                    "QUAL": 5778.76, 
                    "NF3_sampledepth": "14,16", 
                    "GENE(in or nearby)": "gene-dyrk1b", 
                    "NF1_sampledepth": "0,32", 
                    "NF3genotype": "A/G", 
                    "type": "snp", 
                    "Alt": "G", 
                    "MUT type": "."
                }, 
                {
                    "End": 33855, 
                    "HF1genotype": "A/A", 
                    "Gene description": "dual-specificity tyrosine-(Y)-phosphorylation regulated kinase 1B, transcript variant X3", 
                    "NF2genotype": "A/G", 
                    "Anno": "UTR5", 
                    "Start": 33855, 
                    "Gene name": "dyrk1b", 
                    "Ref": "A", 
                    "Total depth": 235, 
                    "HF1_sampledepth": "30,0", 
                    "HF3genotype": "A/A", 
                    "NF2_sampledepth": "33,27", 
                    "MUT info": ".", 
                    "NF1genotype": "G/G", 
                    "Chrom": "NC_061515.1", 
                    "HF3_sampledepth": "39,0", 
                    "HF2genotype": "A/A", 
                    "HF2_sampledepth": "35,0", 
                    "QUAL": 2962.01, 
                    "NF3_sampledepth": "19,17", 
                    "GENE(in or nearby)": "gene-dyrk1b", 
                    "NF1_sampledepth": "0,35", 
                    "NF3genotype": "A/G", 
                    "type": "snp", 
                    "Alt": "G", 
                    "MUT type": "."
                }
            ]
        }, 
        "table_append_02": {
            "table_header": [
                {
                    "field": "format", 
                    "label": "结果文件格式"
                }, 
                {
                    "field": "summary", 
                    "label": "结果文件说明"
                }, 
                {
                    "field": "use", 
                    "label": "结果文件查看方式"
                }
            ], 
            "table": [
                {
                    "use": "unix/Linux/Mac用户使用display命令打开。\nwindows用户可以使用图片浏览器打开，如photoshop等。", 
                    "summary": "结果图像文件，位图，无损压缩。", 
                    "format": "PNG"
                }, 
                {
                    "use": "unix/Linux/Mac用户使用display命令打开。\nwindows用户可以使用图片浏览器打开如photoshop等。", 
                    "summary": "结果图像文件，位图，有损压缩。", 
                    "format": "JPEG"
                }, 
                {
                    "use": "unix/Linux/Mac用户使用display命令打开。\nwindows用户可以使用图片浏览器打开，如photoshop等。", 
                    "summary": "结果图像文件，矢量图，可放大、缩小不失真，方便用户查看和编辑处理，可使用Adobe Illustrator进行编辑，用于文章发表等。", 
                    "format": "SVG"
                }, 
                {
                    "use": "unix/Linux/Mac用户使用 less 或 more 命令查看. \nwindows用户使用高级文本编辑器Editplus/Notepad++等，也可以用MicrosoftExcel打开。", 
                    "summary": "结果数据表格结果，文件以制表符 <Tab> 分隔", 
                    "format": "xls，CSV"
                }, 
                {
                    "use": "unix/Linux用户使用evince命令打开。windows/Mac用户可以使用Adobe Reader/福昕阅读器/网页浏览器等打开。", 
                    "summary": "结果图像文件，矢量图，可放大、缩小不失真，方便用户查看和编辑处理，可使用Adobe Illustrator进行编辑，用于文章发表等。", 
                    "format": "PDF"
                }
            ]
        }, 
        "table_7209": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "HF_vs_NF", 
                    "label": "HF_vs_NF"
                }, 
                {
                    "field": "sum", 
                    "label": "sum"
                }
            ], 
            "table": [
                {
                    "Gene id": "304", 
                    "sum": 304, 
                    "HF_vs_NF": "304"
                }, 
                {
                    "Gene id": "gene-tnni3k", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|up"
                }, 
                {
                    "Gene id": "gene-arr3b", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|up"
                }, 
                {
                    "Gene id": "gene-nt5c1aa", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|up"
                }, 
                {
                    "Gene id": "gene-LOC118283715", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|down"
                }, 
                {
                    "Gene id": "gene-LOC118284959", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|down"
                }, 
                {
                    "Gene id": "gene-LOC118314679", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|down"
                }, 
                {
                    "Gene id": "gene-LOC118309379", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|up"
                }, 
                {
                    "Gene id": "gene-LOC124850505", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|up"
                }, 
                {
                    "Gene id": "gene-rnf207a", 
                    "sum": 1, 
                    "HF_vs_NF": "yes|up"
                }
            ]
        }, 
        "table_7207": {
            "table_header": [
                {
                    "field": "Gene id", 
                    "label": "Gene id"
                }, 
                {
                    "field": "Gene name", 
                    "label": "Gene name"
                }, 
                {
                    "field": "Gene description", 
                    "label": "Gene description"
                }, 
                {
                    "field": "length", 
                    "label": "length"
                }, 
                {
                    "field": "HF1_count", 
                    "label": "HF1_count"
                }, 
                {
                    "field": "HF2_count", 
                    "label": "HF2_count"
                }, 
                {
                    "field": "HF3_count", 
                    "label": "HF3_count"
                }, 
                {
                    "field": "NF1_count", 
                    "label": "NF1_count"
                }, 
                {
                    "field": "NF2_count", 
                    "label": "NF2_count"
                }, 
                {
                    "field": "NF3_count", 
                    "label": "NF3_count"
                }, 
                {
                    "field": "HF1_tpm", 
                    "label": "HF1_tpm"
                }, 
                {
                    "field": "HF2_tpm", 
                    "label": "HF2_tpm"
                }, 
                {
                    "field": "HF3_tpm", 
                    "label": "HF3_tpm"
                }, 
                {
                    "field": "NF1_tpm", 
                    "label": "NF1_tpm"
                }, 
                {
                    "field": "NF2_tpm", 
                    "label": "NF2_tpm"
                }, 
                {
                    "field": "NF3_tpm", 
                    "label": "NF3_tpm"
                }, 
                {
                    "field": "HF_tpm", 
                    "label": "HF_tpm"
                }, 
                {
                    "field": "NF_tpm", 
                    "label": "NF_tpm"
                }, 
                {
                    "field": "fc", 
                    "label": "fc"
                }, 
                {
                    "field": "log2fc", 
                    "label": "log2fc"
                }, 
                {
                    "field": "pvalue", 
                    "label": "pvalue"
                }, 
                {
                    "field": "padjust", 
                    "label": "padjust"
                }, 
                {
                    "field": "significant", 
                    "label": "significant"
                }, 
                {
                    "field": "regulate", 
                    "label": "regulate"
                }, 
                {
                    "field": "nr", 
                    "label": "nr"
                }, 
                {
                    "field": "go", 
                    "label": "go"
                }, 
                {
                    "field": "KO_id", 
                    "label": "KO_id"
                }, 
                {
                    "field": "KO_name", 
                    "label": "KO_name"
                }, 
                {
                    "field": "paths", 
                    "label": "paths"
                }, 
                {
                    "field": "cog", 
                    "label": "cog"
                }, 
                {
                    "field": "cog_description", 
                    "label": "cog_description"
                }, 
                {
                    "field": "pfam", 
                    "label": "pfam"
                }, 
                {
                    "field": "swissprot", 
                    "label": "swissprot"
                }, 
                {
                    "field": "entrez", 
                    "label": "entrez"
                }
            ], 
            "table": [
                {
                    "cog_description": "ENOG410YA63(doublecortin-like kinase)", 
                    "padjust": 0.9133315456129999, 
                    "Gene description": "serine_threonine-protein kinase Nek8, transcript variant X8", 
                    "swissprot": "sp|Q90XC2|NEK8_DANRE(Serine/threonine-protein kinase Nek8 OS=Danio rerio OX=7955 GN=nek8 PE=2 SV=1)", 
                    "NF3_tpm": 24.36, 
                    "HF2_count": 401.0, 
                    "KO_id": "", 
                    "log2fc": -0.244453850051, 
                    "go": "", 
                    "regulate": "down", 
                    "KO_name": "", 
                    "paths": "", 
                    "NF2_count": 611.0, 
                    "HF_tpm": 18.0733333333, 
                    "HF1_count": 486.0, 
                    "HF2_tpm": 14.39, 
                    "NF_tpm": 23.05, 
                    "nr": "XP_035499186.2(serine/threonine-protein kinase Nek8 [Scophthalmus maximus])", 
                    "NF2_tpm": 23.7, 
                    "HF3_tpm": 22.49, 
                    "HF1_tpm": 17.34, 
                    "NF3_count": 591.0, 
                    "fc": 0.8441352934469999, 
                    "significant": "no", 
                    "HF3_count": 655.0, 
                    "entrez": 118315752.0, 
                    "pfam": "PF00069.28(Pkinase:Protein kinase domain); PF07714.20(PK_Tyr_Ser-Thr:Protein tyrosine and serine/threonine kinase); PF17667.4(Pkinase_fungal:Fungal protein kinase)", 
                    "NF1_count": 625.0, 
                    "NF1_tpm": 21.09, 
                    "length": 2343, 
                    "cog": "ENOG410YA63(T:Signal transduction mechanisms)", 
                    "Gene id": "gene-zmp_0000000881", 
                    "pvalue": 0.145582095474, 
                    "Gene name": "zmp_0000000881"
                }, 
                {
                    "cog_description": "ENOG410YUKT(Immunoglobulin V-set domain)", 
                    "padjust": 0.962881334135, 
                    "Gene description": "uncharacterized LOC118299272, transcript variant X1", 
                    "swissprot": "", 
                    "NF3_tpm": 3.8, 
                    "HF2_count": 78.21, 
                    "KO_id": "K06549;K06749", 
                    "log2fc": 0.35584753275200004, 
                    "go": "", 
                    "regulate": "up", 
                    "KO_name": "SIGLEC5, CD170;SIGLEC10", 
                    "paths": "", 
                    "NF2_count": 63.07, 
                    "HF_tpm": 3.72666666667, 
                    "HF1_count": 117.28, 
                    "HF2_tpm": 3.19, 
                    "NF_tpm": 3.07333333333, 
                    "nr": "XP_035478752.2(uncharacterized protein LOC118299272 [Scophthalmus maximus])", 
                    "NF2_tpm": 2.7, 
                    "HF3_tpm": 3.32, 
                    "HF1_tpm": 4.67, 
                    "NF3_count": 87.41, 
                    "fc": 1.2797371612000001, 
                    "significant": "no", 
                    "HF3_count": 87.26, 
                    "entrez": 118299272.0, 
                    "pfam": "", 
                    "NF1_count": 72.02, 
                    "NF1_tpm": 2.72, 
                    "length": 1924, 
                    "cog": "ENOG410YUKT(S:Function unknown)", 
                    "Gene id": "gene-LOC118299272", 
                    "pvalue": 0.276176613828, 
                    "Gene name": "LOC118299272"
                }, 
                {
                    "cog_description": "ENOG4111F9I(Transcriptional adaptor 1)", 
                    "padjust": 0.998783873922, 
                    "Gene description": "transcriptional adaptor 1", 
                    "swissprot": "sp|Q6NWA8|TADA1_DANRE(Transcriptional adapter 1 OS=Danio rerio OX=7955 GN=tada1 PE=2 SV=1)", 
                    "NF3_tpm": 9.47, 
                    "HF2_count": 197.0, 
                    "KO_id": "K11317", 
                    "log2fc": -0.0726364616351, 
                    "go": "GO:0070461(cellular_component:SAGA-type complex)", 
                    "regulate": "down", 
                    "KO_name": "TADA1, STAF42", 
                    "paths": "", 
                    "NF2_count": 195.0, 
                    "HF_tpm": 8.5, 
                    "HF1_count": 205.96, 
                    "HF2_tpm": 8.13, 
                    "NF_tpm": 9.65333333333, 
                    "nr": "XP_035489925.1(transcriptional adapter 1 [Scophthalmus maximus])", 
                    "NF2_tpm": 8.69, 
                    "HF3_tpm": 9.05, 
                    "HF1_tpm": 8.32, 
                    "NF3_count": 201.0, 
                    "fc": 0.950898683811, 
                    "significant": "no", 
                    "HF3_count": 231.0, 
                    "entrez": 118310770.0, 
                    "pfam": "PF12767.10(SAGA-Tad1:Transcriptional regulator of RNA polII, SAGA, subunit)", 
                    "NF1_count": 283.0, 
                    "NF1_tpm": 10.8, 
                    "length": 1908, 
                    "cog": "ENOG4111F9I(K:Transcription)", 
                    "Gene id": "gene-tada1", 
                    "pvalue": 0.7214720924089999, 
                    "Gene name": "tada1"
                }, 
                {
                    "cog_description": "COG5648(high mobility group)", 
                    "padjust": 0.9415404628540001, 
                    "Gene description": "upstream binding transcription factor, transcript variant X2", 
                    "swissprot": "sp|P25977|UBF1_RAT(Nucleolar transcription factor 1 OS=Rattus norvegicus OX=10116 GN=Ubtf PE=1 SV=1)", 
                    "NF3_tpm": 48.84, 
                    "HF2_count": 4008.0, 
                    "KO_id": "K09273", 
                    "log2fc": 0.17242684472300002, 
                    "go": "GO:0000124(cellular_component:SAGA complex); GO:0006325(biological_process:chromatin organization); GO:0005634(cellular_component:nucleus); GO:0003713(molecular_function:transcription coactivator activity); GO:0071819(cellular_component:DUBm complex); GO:0008270(molecular_function:zinc ion binding); GO:0003677(molecular_function:DNA binding); GO:0016578(biological_process:histone deubiquitination)", 
                    "regulate": "up", 
                    "KO_name": "UBTF", 
                    "paths": "", 
                    "NF2_count": 3401.0, 
                    "HF_tpm": 47.7466666667, 
                    "HF1_count": 3930.0, 
                    "HF2_tpm": 46.82, 
                    "NF_tpm": 46.2433333333, 
                    "nr": "XP_047184055.1(nucleolar transcription factor 1 isoform X2 [Scophthalmus maximus])", 
                    "NF2_tpm": 42.88, 
                    "HF3_tpm": 50.96, 
                    "HF1_tpm": 45.46, 
                    "NF3_count": 3578.0, 
                    "fc": 1.12695260638, 
                    "significant": "no", 
                    "HF3_count": 4531.0, 
                    "entrez": 118288328.0, 
                    "pfam": "PF00505.22(HMG_box:HMG (high mobility group) box); PF14887.9(HMG_box_5:HMG (high mobility group) box 5); PF09011.13(HMG_box_2:HMG-box domain)", 
                    "NF1_count": 4258.0, 
                    "NF1_tpm": 47.01, 
                    "length": 5451, 
                    "cog": "COG5648(B:Chromatin structure and dynamics)", 
                    "Gene id": "gene-ubtf", 
                    "pvalue": 0.18589964299000003, 
                    "Gene name": "ubtf"
                }, 
                {
                    "cog_description": "COG5048(Zinc finger protein)", 
                    "padjust": 0.9757711927410001, 
                    "Gene description": "sp2 transcription factor, transcript variant X1", 
                    "swissprot": "sp|Q9D2H6|SP2_MOUSE(Transcription factor Sp2 OS=Mus musculus OX=10090 GN=Sp2 PE=2 SV=2)", 
                    "NF3_tpm": 8.15, 
                    "HF2_count": 594.0, 
                    "KO_id": "K09192", 
                    "log2fc": 0.17069419804699998, 
                    "go": "GO:0016021(cellular_component:integral component of membrane); GO:0140359(molecular_function:ABC-type transmembrane transporter activity); GO:0005524(molecular_function:ATP binding); GO:0035264(biological_process:multicellular organism growth)", 
                    "regulate": "up", 
                    "KO_name": "SP2", 
                    "paths": "", 
                    "NF2_count": 473.0, 
                    "HF_tpm": 7.793333333330001, 
                    "HF1_count": 505.0, 
                    "HF2_tpm": 8.31, 
                    "NF_tpm": 7.54, 
                    "nr": "XP_035491971.1(transcription factor Sp2 isoform X1 [Scophthalmus maximus])", 
                    "NF2_tpm": 7.0, 
                    "HF3_tpm": 8.25, 
                    "HF1_tpm": 6.82, 
                    "NF3_count": 514.0, 
                    "fc": 1.12559997219, 
                    "significant": "no", 
                    "HF3_count": 615.0, 
                    "entrez": 118311921.0, 
                    "pfam": "PF13465.9(zf-H2C2_2:Zinc-finger double domain); PF00096.29(zf-C2H2:Zinc finger, C2H2 type); PF13894.9(zf-C2H2_4:C2H2-type zinc finger); PF07238.17(PilZ:PilZ domain)", 
                    "NF1_count": 560.0, 
                    "NF1_tpm": 7.47, 
                    "length": 5122, 
                    "cog": "COG5048(S:Function unknown)", 
                    "Gene id": "gene-sp2", 
                    "pvalue": 0.331759774818, 
                    "Gene name": "sp2"
                }, 
                {
                    "cog_description": "ENOG410Y3SD(WD repeat domain 13)", 
                    "padjust": 0.9969899877130001, 
                    "Gene description": "WD repeat domain 13", 
                    "swissprot": "sp|Q6DKP5|WDR13_PANTR(WD repeat-containing protein 13 OS=Pan troglodytes OX=9598 GN=WDR13 PE=3 SV=1)", 
                    "NF3_tpm": 16.04, 
                    "HF2_count": 362.0, 
                    "KO_id": "K24739", 
                    "log2fc": -0.0975513639105, 
                    "go": "", 
                    "regulate": "down", 
                    "KO_name": "WDR13", 
                    "paths": "", 
                    "NF2_count": 379.0, 
                    "HF_tpm": 14.02, 
                    "HF1_count": 348.0, 
                    "HF2_tpm": 12.93, 
                    "NF_tpm": 16.4433333333, 
                    "nr": "KAG7519896.1(WD repeat-containing protein 13 [Solea senegalensis])", 
                    "NF2_tpm": 14.89, 
                    "HF3_tpm": 17.11, 
                    "HF1_tpm": 12.02, 
                    "NF3_count": 390.0, 
                    "fc": 0.9346179406239999, 
                    "significant": "no", 
                    "HF3_count": 500.0, 
                    "entrez": 118317439.0, 
                    "pfam": "PF00400.35(WD40:WD domain, G-beta repeat); PF12894.10(ANAPC4_WD40:Anaphase-promoting complex subunit 4 WD40 domain); PF20426.1(NBCH_WD40:Neurobeachin beta propeller domain)", 
                    "NF1_count": 541.0, 
                    "NF1_tpm": 18.4, 
                    "length": 2190, 
                    "cog": "ENOG410Y3SD(S:Function unknown)", 
                    "Gene id": "gene-wdr13", 
                    "pvalue": 0.612368556108, 
                    "Gene name": "wdr13"
                }, 
                {
                    "cog_description": "ENOG410ZTQY(basic, immunoglobulin-like variable motif containing)", 
                    "padjust": 0.9704305090209999, 
                    "Gene description": "basic immunoglobulin-like variable motif-containing protein", 
                    "swissprot": "sp|Q0V9T8|BIVM_XENTR(Basic immunoglobulin-like variable motif-containing protein OS=Xenopus tropicalis OX=8364 GN=bivm PE=2 SV=1)", 
                    "NF3_tpm": 12.63, 
                    "HF2_count": 526.4, 
                    "KO_id": "", 
                    "log2fc": 0.198095144876, 
                    "go": "", 
                    "regulate": "up", 
                    "KO_name": "", 
                    "paths": "", 
                    "NF2_count": 471.85, 
                    "HF_tpm": 11.146666666700002, 
                    "HF1_count": 530.3, 
                    "HF2_tpm": 10.87, 
                    "NF_tpm": 10.46, 
                    "nr": "XP_035502955.2(basic immunoglobulin-like variable motif-containing protein [Scophthalmus maximus])", 
                    "NF2_tpm": 9.92, 
                    "HF3_tpm": 11.69, 
                    "HF1_tpm": 10.88, 
                    "NF3_count": 521.84, 
                    "fc": 1.1471826777399998, 
                    "significant": "no", 
                    "HF3_count": 574.07, 
                    "entrez": 118317921.0, 
                    "pfam": "", 
                    "NF1_count": 438.47, 
                    "NF1_tpm": 8.83, 
                    "length": 3142, 
                    "cog": "ENOG410ZTQY(S:Function unknown)", 
                    "Gene id": "gene-LOC118317921", 
                    "pvalue": 0.291452823096, 
                    "Gene name": "LOC118317921"
                }, 
                {
                    "cog_description": "ENOG410YFY9(family with sequence similarity 213, member)", 
                    "padjust": 0.981983142439, 
                    "Gene description": "peroxiredoxin-like 2A, transcript variant X1", 
                    "swissprot": "sp|Q6PBP3|PXL2A_DANRE(Peroxiredoxin-like 2A OS=Danio rerio OX=7955 GN=prxl2a PE=2 SV=2)", 
                    "NF3_tpm": 38.01, 
                    "HF2_count": 648.52, 
                    "KO_id": "", 
                    "log2fc": -0.14941749992, 
                    "go": "", 
                    "regulate": "down", 
                    "KO_name": "", 
                    "paths": "", 
                    "NF2_count": 703.0, 
                    "HF_tpm": 31.7166666667, 
                    "HF1_count": 523.83, 
                    "HF2_tpm": 34.46, 
                    "NF_tpm": 38.1133333333, 
                    "nr": "XP_035461090.1(peroxiredoxin-like 2A isoform X1 [Scophthalmus maximus])", 
                    "NF2_tpm": 40.89, 
                    "HF3_tpm": 33.13, 
                    "HF1_tpm": 27.56, 
                    "NF3_count": 634.5, 
                    "fc": 0.9016144234260001, 
                    "significant": "no", 
                    "HF3_count": 649.0, 
                    "entrez": 118283339.0, 
                    "pfam": "PF13911.9(AhpC-TSA_2:AhpC/TSA antioxidant enzyme); PF00578.24(AhpC-TSA:AhpC/TSA family)", 
                    "NF1_count": 720.67, 
                    "NF1_tpm": 35.44, 
                    "length": 1817, 
                    "cog": "ENOG410YFY9(O:Posttranslational modification, protein turnover, chaperones)", 
                    "Gene id": "gene-LOC118283339", 
                    "pvalue": 0.383452850285, 
                    "Gene name": "LOC118283339"
                }, 
                {
                    "cog_description": "COG4886(leucine Rich Repeat)", 
                    "padjust": 1.0, 
                    "Gene description": "reticulon-4 receptor-like 1", 
                    "swissprot": "sp|Q86UN2|R4RL1_HUMAN(Reticulon-4 receptor-like 1 OS=Homo sapiens OX=9606 GN=RTN4RL1 PE=1 SV=1)", 
                    "NF3_tpm": 0.07, 
                    "HF2_count": 7.0, 
                    "KO_id": "K16660", 
                    "log2fc": 0.459549226558, 
                    "go": "", 
                    "regulate": "up", 
                    "KO_name": "RTN4RL1, NGR3", 
                    "paths": "", 
                    "NF2_count": 7.0, 
                    "HF_tpm": 0.103333333333, 
                    "HF1_count": 9.0, 
                    "HF2_tpm": 0.11, 
                    "NF_tpm": 0.08333333333330001, 
                    "nr": "XP_035481529.2(reticulon-4 receptor-like 1 [Scophthalmus maximus])", 
                    "NF2_tpm": 0.12, 
                    "HF3_tpm": 0.06, 
                    "HF1_tpm": 0.14, 
                    "NF3_count": 4.0, 
                    "fc": 1.3751120940200001, 
                    "significant": "no", 
                    "HF3_count": 4.0, 
                    "entrez": 118300823.0, 
                    "pfam": "PF13855.9(LRR_8:Leucine rich repeat); PF12799.10(LRR_4:Leucine Rich repeats (2 copies)); PF13306.9(LRR_5:BspA type Leucine rich repeat region (6 copies)); PF14580.9(LRR_9:Leucine-rich repeat)", 
                    "NF1_count": 4.0, 
                    "NF1_tpm": 0.06, 
                    "length": 4558, 
                    "cog": "COG4886(S:Function unknown)", 
                    "Gene id": "gene-LOC118300823", 
                    "pvalue": 0.621231749651, 
                    "Gene name": "LOC118300823"
                }, 
                {
                    "cog_description": "ENOG410ZNZF(multiple endocrine neoplasia I)", 
                    "padjust": 0.998783873922, 
                    "Gene description": "multiple endocrine neoplasia I, transcript variant X6", 
                    "swissprot": "sp|O88559|MEN1_MOUSE(Menin OS=Mus musculus OX=10090 GN=Men1 PE=1 SV=2)", 
                    "NF3_tpm": 4.98, 
                    "HF2_count": 159.0, 
                    "KO_id": "K14970", 
                    "log2fc": -0.0765063263819, 
                    "go": "GO:0005634(cellular_component:nucleus); GO:0045892(biological_process:negative regulation of transcription, DNA-templated); GO:0003677(molecular_function:DNA binding)", 
                    "regulate": "down", 
                    "KO_name": "MEN1, MNN1", 
                    "paths": "map04934(Cushing syndrome); map05202(Transcriptional misregulation in cancer)", 
                    "NF2_count": 233.0, 
                    "HF_tpm": 4.06, 
                    "HF1_count": 191.0, 
                    "HF2_tpm": 3.41, 
                    "NF_tpm": 4.67666666667, 
                    "nr": "XP_035464188.2(menin [Scophthalmus maximus])", 
                    "NF2_tpm": 5.45, 
                    "HF3_tpm": 4.73, 
                    "HF1_tpm": 4.04, 
                    "NF3_count": 199.0, 
                    "fc": 0.948351424541, 
                    "significant": "no", 
                    "HF3_count": 228.0, 
                    "entrez": 118284993.0, 
                    "pfam": "PF05053.16(Menin:Menin)", 
                    "NF1_count": 179.0, 
                    "NF1_tpm": 3.6, 
                    "length": 3423, 
                    "cog": "ENOG410ZNZF(K:Transcription)", 
                    "Gene id": "gene-men1", 
                    "pvalue": 0.727449142715, 
                    "Gene name": "men1"
                }
            ]
        }, 
        "table_5657": {
            "table_header": [
                {
                    "field": "Sample", 
                    "label": "Sample"
                }, 
                {
                    "field": "Total_reads", 
                    "label": "Total_reads"
                }, 
                {
                    "field": "Total_mapped", 
                    "label": "Total_mapped"
                }, 
                {
                    "field": "Multiple_mapped", 
                    "label": "Multiple_mapped"
                }, 
                {
                    "field": "Unique_mapped", 
                    "label": "Unique_mapped"
                }
            ], 
            "table": [
                {
                    "Sample": "HF1", 
                    "Total_mapped": "43658107(95.6%)", 
                    "Total_reads": 45665400, 
                    "Unique_mapped": "41978723(91.93%)", 
                    "Multiple_mapped": "1679384(3.68%)"
                }, 
                {
                    "Sample": "HF2", 
                    "Total_mapped": "38972342(95.64%)", 
                    "Total_reads": 40748810, 
                    "Unique_mapped": "37528178(92.1%)", 
                    "Multiple_mapped": "1444164(3.54%)"
                }, 
                {
                    "Sample": "HF3", 
                    "Total_mapped": "46847348(95.26%)", 
                    "Total_reads": 49176156, 
                    "Unique_mapped": "44992423(91.49%)", 
                    "Multiple_mapped": "1854925(3.77%)"
                }, 
                {
                    "Sample": "NF1", 
                    "Total_mapped": "47049589(94.95%)", 
                    "Total_reads": 49551692, 
                    "Unique_mapped": "45150133(91.12%)", 
                    "Multiple_mapped": "1899456(3.83%)"
                }, 
                {
                    "Sample": "NF2", 
                    "Total_mapped": "43574785(95.23%)", 
                    "Total_reads": 45758398, 
                    "Unique_mapped": "41953504(91.68%)", 
                    "Multiple_mapped": "1621281(3.54%)"
                }, 
                {
                    "Sample": "NF3", 
                    "Total_mapped": "39039938(94.97%)", 
                    "Total_reads": 41108390, 
                    "Unique_mapped": "37516916(91.26%)", 
                    "Multiple_mapped": "1523022(3.7%)"
                }
            ]
        }, 
        "table_5547": {
            "table_header": [
                {
                    "field": "Depth", 
                    "label": "Depth"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": 124753, 
                    "HF3": 137550, 
                    "HF2": 120746, 
                    "Depth": "<=30", 
                    "NF3": 121864, 
                    "NF2": 160226, 
                    "NF1": 124984
                }, 
                {
                    "HF1": 40407, 
                    "HF3": 41400, 
                    "HF2": 37739, 
                    "Depth": "31-100", 
                    "NF3": 37251, 
                    "NF2": 39887, 
                    "NF1": 39463
                }, 
                {
                    "HF1": 10165, 
                    "HF3": 11854, 
                    "HF2": 9299, 
                    "Depth": "101-200", 
                    "NF3": 9400, 
                    "NF2": 10229, 
                    "NF1": 11431
                }, 
                {
                    "HF1": 2857, 
                    "HF3": 3488, 
                    "HF2": 2586, 
                    "Depth": "201-300", 
                    "NF3": 2734, 
                    "NF2": 3146, 
                    "NF1": 3403
                }, 
                {
                    "HF1": 1196, 
                    "HF3": 1619, 
                    "HF2": 1093, 
                    "Depth": "301-400", 
                    "NF3": 1175, 
                    "NF2": 1319, 
                    "NF1": 1545
                }, 
                {
                    "HF1": 598, 
                    "HF3": 826, 
                    "HF2": 570, 
                    "Depth": "401-500", 
                    "NF3": 636, 
                    "NF2": 686, 
                    "NF1": 772
                }, 
                {
                    "HF1": 1483, 
                    "HF3": 1880, 
                    "HF2": 1316, 
                    "Depth": ">500", 
                    "NF3": 1480, 
                    "NF2": 1577, 
                    "NF1": 1935
                }
            ]
        }, 
        "table_5545": {
            "table_header": [
                {
                    "field": "Region", 
                    "label": "Region"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": 0, 
                    "Region": ".", 
                    "HF2": 0, 
                    "NF3": 0, 
                    "NF2": 0, 
                    "NF1": 0, 
                    "HF3": 0
                }, 
                {
                    "HF1": 47234, 
                    "Region": "UTR3", 
                    "HF2": 44426, 
                    "NF3": 44379, 
                    "NF2": 44961, 
                    "NF1": 45424, 
                    "HF3": 45691
                }, 
                {
                    "HF1": 9362, 
                    "Region": "UTR5", 
                    "HF2": 8771, 
                    "NF3": 8863, 
                    "NF2": 9845, 
                    "NF1": 9319, 
                    "HF3": 9688
                }, 
                {
                    "HF1": 48, 
                    "Region": "UTR5;UTR3", 
                    "HF2": 32, 
                    "NF3": 39, 
                    "NF2": 40, 
                    "NF1": 36, 
                    "HF3": 33
                }, 
                {
                    "HF1": 5178, 
                    "Region": "downstream", 
                    "HF2": 4690, 
                    "NF3": 4856, 
                    "NF2": 5241, 
                    "NF1": 5352, 
                    "HF3": 5323
                }, 
                {
                    "HF1": 38291, 
                    "Region": "exonic", 
                    "HF2": 35906, 
                    "NF3": 36179, 
                    "NF2": 37313, 
                    "NF1": 36791, 
                    "HF3": 37292
                }, 
                {
                    "HF1": 5, 
                    "Region": "exonic;splicing", 
                    "HF2": 4, 
                    "NF3": 10, 
                    "NF2": 6, 
                    "NF1": 9, 
                    "HF3": 9
                }, 
                {
                    "HF1": 3667, 
                    "Region": "intergenic", 
                    "HF2": 3181, 
                    "NF3": 3222, 
                    "NF2": 4303, 
                    "NF1": 3565, 
                    "HF3": 3754
                }, 
                {
                    "HF1": 42535, 
                    "Region": "intronic", 
                    "HF2": 43290, 
                    "NF3": 43480, 
                    "NF2": 74443, 
                    "NF1": 47088, 
                    "HF3": 59195
                }, 
                {
                    "HF1": 754, 
                    "Region": "ncRNA_UTR3", 
                    "HF2": 689, 
                    "NF3": 698, 
                    "NF2": 693, 
                    "NF1": 698, 
                    "HF3": 748
                }, 
                {
                    "HF1": 209, 
                    "Region": "ncRNA_UTR5", 
                    "HF2": 198, 
                    "NF3": 212, 
                    "NF2": 225, 
                    "NF1": 196, 
                    "HF3": 209
                }, 
                {
                    "HF1": 2650, 
                    "Region": "ncRNA_exonic", 
                    "HF2": 2385, 
                    "NF3": 2344, 
                    "NF2": 2765, 
                    "NF1": 2568, 
                    "HF3": 2800
                }, 
                {
                    "HF1": 1769, 
                    "Region": "ncRNA_intronic", 
                    "HF2": 1663, 
                    "NF3": 1721, 
                    "NF2": 2898, 
                    "NF1": 1958, 
                    "HF3": 2297
                }, 
                {
                    "HF1": 1, 
                    "Region": "ncRNA_splicing", 
                    "HF2": 2, 
                    "NF3": 1, 
                    "NF2": 2, 
                    "NF1": 3, 
                    "HF3": 4
                }, 
                {
                    "HF1": 61, 
                    "Region": "splicing", 
                    "HF2": 35, 
                    "NF3": 55, 
                    "NF2": 67, 
                    "NF1": 59, 
                    "HF3": 57
                }, 
                {
                    "HF1": 1138, 
                    "Region": "upstream", 
                    "HF2": 1013, 
                    "NF3": 1109, 
                    "NF2": 1399, 
                    "NF1": 1180, 
                    "HF3": 1350
                }, 
                {
                    "HF1": 873, 
                    "Region": "upstream;downstream", 
                    "HF2": 767, 
                    "NF3": 833, 
                    "NF2": 924, 
                    "NF1": 881, 
                    "HF3": 892
                }, 
                {
                    "HF1": 153775, 
                    "Region": "total", 
                    "HF2": 147052, 
                    "NF3": 148001, 
                    "NF2": 185125, 
                    "NF1": 155127, 
                    "HF3": 169342
                }
            ]
        }, 
        "table_5543": {
            "table_header": [
                {
                    "field": "type", 
                    "label": "type"
                }, 
                {
                    "field": "HF1", 
                    "label": "HF1"
                }, 
                {
                    "field": "HF2", 
                    "label": "HF2"
                }, 
                {
                    "field": "HF3", 
                    "label": "HF3"
                }, 
                {
                    "field": "NF1", 
                    "label": "NF1"
                }, 
                {
                    "field": "NF2", 
                    "label": "NF2"
                }, 
                {
                    "field": "NF3", 
                    "label": "NF3"
                }
            ], 
            "table": [
                {
                    "HF1": 20357, 
                    "HF3": 22564, 
                    "HF2": 19487, 
                    "NF3": 19617, 
                    "NF2": 24502, 
                    "NF1": 20710, 
                    "type": "A/G"
                }, 
                {
                    "HF1": 9037, 
                    "HF3": 9983, 
                    "HF2": 8715, 
                    "NF3": 8824, 
                    "NF2": 11078, 
                    "NF1": 9285, 
                    "type": "A/C"
                }, 
                {
                    "HF1": 21028, 
                    "HF3": 22880, 
                    "HF2": 19950, 
                    "NF3": 20297, 
                    "NF2": 24808, 
                    "NF1": 21047, 
                    "type": "C/T"
                }, 
                {
                    "HF1": 21104, 
                    "HF3": 22854, 
                    "HF2": 20179, 
                    "NF3": 20097, 
                    "NF2": 24852, 
                    "NF1": 21055, 
                    "type": "G/A"
                }, 
                {
                    "HF1": 6797, 
                    "HF3": 7440, 
                    "HF2": 6524, 
                    "NF3": 6510, 
                    "NF2": 8145, 
                    "NF1": 6890, 
                    "type": "G/C"
                }, 
                {
                    "HF1": 9468, 
                    "HF3": 10321, 
                    "HF2": 9075, 
                    "NF3": 9136, 
                    "NF2": 11435, 
                    "NF1": 9586, 
                    "type": "C/A"
                }, 
                {
                    "HF1": 10056, 
                    "HF3": 11464, 
                    "HF2": 9688, 
                    "NF3": 9813, 
                    "NF2": 12465, 
                    "NF1": 10035, 
                    "type": "A/T"
                }, 
                {
                    "HF1": 6885, 
                    "HF3": 7585, 
                    "HF2": 6645, 
                    "NF3": 6538, 
                    "NF2": 8203, 
                    "NF1": 6982, 
                    "type": "C/G"
                }, 
                {
                    "HF1": 9566, 
                    "HF3": 10644, 
                    "HF2": 9131, 
                    "NF3": 9258, 
                    "NF2": 11559, 
                    "NF1": 9621, 
                    "type": "G/T"
                }, 
                {
                    "HF1": 20181, 
                    "HF3": 22211, 
                    "HF2": 19184, 
                    "NF3": 19372, 
                    "NF2": 24265, 
                    "NF1": 20354, 
                    "type": "T/C"
                }
            ]
        }, 
        "table_5629": {
            "table_header": [
                {
                    "field": "Class code", 
                    "label": "Class code"
                }, 
                {
                    "field": "Description", 
                    "label": "Description"
                }, 
                {
                    "field": "Number", 
                    "label": "Number"
                }
            ], 
            "table": [
                {
                    "Number": 58889, 
                    "Class code": "=", 
                    "Description": "Complete match of intron chain"
                }, 
                {
                    "Number": 1, 
                    "Class code": "c", 
                    "Description": "Contained"
                }, 
                {
                    "Number": 0, 
                    "Class code": "e", 
                    "Description": "Single exon transfrag overlapping a reference exon and at least 10 bp of a reference intron,indiction a possible pre-mRNA fragment"
                }, 
                {
                    "Number": 205, 
                    "Class code": "i", 
                    "Description": "Transfrag falling entirely within a reference intron"
                }, 
                {
                    "Number": 11708, 
                    "Class code": "j", 
                    "Description": "Potentially novel isoform (fragment):at least one splice junction is shared with a reference transcript"
                }, 
                {
                    "Number": 287, 
                    "Class code": "o", 
                    "Description": "Generic exonic overlap with a referfence transcript"
                }, 
                {
                    "Number": 0, 
                    "Class code": "p", 
                    "Description": "Possible polymerase run-on fragment(within 2Kbases of a reference transcript"
                }, 
                {
                    "Number": 0, 
                    "Class code": "s", 
                    "Description": "An intron of the transfrag overlaps a reference intron on the opposite strand(likely due to read mapping errors"
                }, 
                {
                    "Number": 372, 
                    "Class code": "u", 
                    "Description": "Unknown,intergenic transcript"
                }, 
                {
                    "Number": 206, 
                    "Class code": "x", 
                    "Description": "Exonic overlap with reference on the opposite strand"
                }, 
                {
                    "Number": 0, 
                    "Class code": "r", 
                    "Description": "Repeat. Currently determined by looking at the soft-masked reference sequence and applied to transcripts where at least 50% of the bases are lower case"
                }, 
                {
                    "Number": 0, 
                    "Class code": ".", 
                    "Description": "Tracking file only,indicates multiple classifications"
                }
            ]
        }, 
        "table_5623": {
            "table_header": [
                {
                    "field": "Species Latin Name", 
                    "label": "Species Latin Name"
                }, 
                {
                    "field": "Sample Productive Name", 
                    "label": "Sample Productive Name"
                }, 
                {
                    "field": "Sample Name", 
                    "label": "Sample Name"
                }, 
                {
                    "field": "Group Name", 
                    "label": "Group Name"
                }
            ], 
            "table": [
                {
                    "Group Name": "NF", 
                    "Sample Name": "NF1", 
                    "Sample Productive Name": "NF1", 
                    "Species Latin Name": "Scophthalmus_maximus"
                }, 
                {
                    "Group Name": "NF", 
                    "Sample Name": "NF2", 
                    "Sample Productive Name": "NF2", 
                    "Species Latin Name": "Scophthalmus_maximus"
                }, 
                {
                    "Group Name": "NF", 
                    "Sample Name": "NF3", 
                    "Sample Productive Name": "NF3", 
                    "Species Latin Name": "Scophthalmus_maximus"
                }, 
                {
                    "Group Name": "HF", 
                    "Sample Name": "HF1", 
                    "Sample Productive Name": "HF1", 
                    "Species Latin Name": "Scophthalmus_maximus"
                }, 
                {
                    "Group Name": "HF", 
                    "Sample Name": "HF2", 
                    "Sample Productive Name": "HF2", 
                    "Species Latin Name": "Scophthalmus_maximus"
                }, 
                {
                    "Group Name": "HF", 
                    "Sample Name": "HF3", 
                    "Sample Productive Name": "HF3", 
                    "Species Latin Name": "Scophthalmus_maximus"
                }
            ]
        }, 
        "table_5621": {
            "table_header": [
                {
                    "field": "Chromosome", 
                    "label": "Chromosome"
                }, 
                {
                    "field": "Length(MB)", 
                    "label": "Length(MB)"
                }, 
                {
                    "field": "GC%", 
                    "label": "GC%"
                }, 
                {
                    "field": "Gene", 
                    "label": "Gene"
                }, 
                {
                    "field": "ProteinCoding", 
                    "label": "ProteinCoding"
                }, 
                {
                    "field": "OtherRNA", 
                    "label": "OtherRNA"
                }, 
                {
                    "field": "Pseudogene", 
                    "label": "Pseudogene"
                }
            ], 
            "table": [
                {
                    "Pseudogene": 0, 
                    "GC%": 43.9, 
                    "Length(MB)": 31.67, 
                    "OtherRNA": 206, 
                    "ProteinCoding": 1372, 
                    "Gene": 1578, 
                    "Chromosome": "NC_061515.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.25, 
                    "Length(MB)": 31.51, 
                    "OtherRNA": 275, 
                    "ProteinCoding": 1313, 
                    "Gene": 1588, 
                    "Chromosome": "NC_061516.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.85, 
                    "Length(MB)": 30.53, 
                    "OtherRNA": 172, 
                    "ProteinCoding": 1282, 
                    "Gene": 1454, 
                    "Chromosome": "NC_061517.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 42.79, 
                    "Length(MB)": 29.16, 
                    "OtherRNA": 317, 
                    "ProteinCoding": 890, 
                    "Gene": 1207, 
                    "Chromosome": "NC_061518.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.38, 
                    "Length(MB)": 28.26, 
                    "OtherRNA": 198, 
                    "ProteinCoding": 1203, 
                    "Gene": 1401, 
                    "Chromosome": "NC_061519.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.28, 
                    "Length(MB)": 27.71, 
                    "OtherRNA": 183, 
                    "ProteinCoding": 1132, 
                    "Gene": 1315, 
                    "Chromosome": "NC_061520.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.37, 
                    "Length(MB)": 27.1, 
                    "OtherRNA": 605, 
                    "ProteinCoding": 1078, 
                    "Gene": 1683, 
                    "Chromosome": "NC_061521.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.32, 
                    "Length(MB)": 26.12, 
                    "OtherRNA": 149, 
                    "ProteinCoding": 1118, 
                    "Gene": 1267, 
                    "Chromosome": "NC_061522.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.22, 
                    "Length(MB)": 25.91, 
                    "OtherRNA": 440, 
                    "ProteinCoding": 850, 
                    "Gene": 1290, 
                    "Chromosome": "NC_061523.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.58, 
                    "Length(MB)": 25.76, 
                    "OtherRNA": 167, 
                    "ProteinCoding": 960, 
                    "Gene": 1127, 
                    "Chromosome": "NC_061524.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.44, 
                    "Length(MB)": 25.34, 
                    "OtherRNA": 172, 
                    "ProteinCoding": 948, 
                    "Gene": 1120, 
                    "Chromosome": "NC_061525.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 44.22, 
                    "Length(MB)": 25.08, 
                    "OtherRNA": 237, 
                    "ProteinCoding": 1017, 
                    "Gene": 1254, 
                    "Chromosome": "NC_061526.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.49, 
                    "Length(MB)": 25.0, 
                    "OtherRNA": 178, 
                    "ProteinCoding": 947, 
                    "Gene": 1125, 
                    "Chromosome": "NC_061527.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.34, 
                    "Length(MB)": 23.0, 
                    "OtherRNA": 129, 
                    "ProteinCoding": 860, 
                    "Gene": 989, 
                    "Chromosome": "NC_061528.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.86, 
                    "Length(MB)": 22.73, 
                    "OtherRNA": 229, 
                    "ProteinCoding": 928, 
                    "Gene": 1157, 
                    "Chromosome": "NC_061529.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.63, 
                    "Length(MB)": 21.45, 
                    "OtherRNA": 130, 
                    "ProteinCoding": 932, 
                    "Gene": 1062, 
                    "Chromosome": "NC_061530.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 44.13, 
                    "Length(MB)": 20.76, 
                    "OtherRNA": 272, 
                    "ProteinCoding": 1080, 
                    "Gene": 1352, 
                    "Chromosome": "NC_061531.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.65, 
                    "Length(MB)": 20.51, 
                    "OtherRNA": 250, 
                    "ProteinCoding": 797, 
                    "Gene": 1047, 
                    "Chromosome": "NC_061532.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.17, 
                    "Length(MB)": 20.25, 
                    "OtherRNA": 97, 
                    "ProteinCoding": 897, 
                    "Gene": 994, 
                    "Chromosome": "NC_061533.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.4, 
                    "Length(MB)": 18.47, 
                    "OtherRNA": 95, 
                    "ProteinCoding": 748, 
                    "Gene": 843, 
                    "Chromosome": "NC_061534.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 44.05, 
                    "Length(MB)": 16.03, 
                    "OtherRNA": 108, 
                    "ProteinCoding": 539, 
                    "Gene": 647, 
                    "Chromosome": "NC_061535.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.91, 
                    "Length(MB)": 15.41, 
                    "OtherRNA": 136, 
                    "ProteinCoding": 693, 
                    "Gene": 829, 
                    "Chromosome": "NC_061536.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 44.31, 
                    "Length(MB)": 0.2, 
                    "OtherRNA": 11, 
                    "ProteinCoding": 12, 
                    "Gene": 23, 
                    "Chromosome": "NW_025917010.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 45.6, 
                    "Length(MB)": 0.15, 
                    "OtherRNA": 2, 
                    "ProteinCoding": 6, 
                    "Gene": 8, 
                    "Chromosome": "NW_025917011.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 46.72, 
                    "Length(MB)": 0.11, 
                    "OtherRNA": 2, 
                    "ProteinCoding": 4, 
                    "Gene": 6, 
                    "Chromosome": "NW_025917012.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 43.0, 
                    "Length(MB)": 0.0, 
                    "OtherRNA": 1, 
                    "ProteinCoding": 0, 
                    "Gene": 1, 
                    "Chromosome": "NW_025917013.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 48.9, 
                    "Length(MB)": 0.0, 
                    "OtherRNA": 1, 
                    "ProteinCoding": 0, 
                    "Gene": 1, 
                    "Chromosome": "NW_025917014.1"
                }, 
                {
                    "Pseudogene": 0, 
                    "GC%": 44.22, 
                    "Length(MB)": 0.02, 
                    "OtherRNA": 24, 
                    "ProteinCoding": 13, 
                    "Gene": 37, 
                    "Chromosome": "NC_013183.1"
                }
            ]
        }
    }
}